"""Frozen paired integration experiment; generated worlds are not independent review."""
import hashlib
import json
import random
from datetime import datetime, timezone
from pathlib import Path
from expanding_cycle import ExpandingCycle
from uncertain_runtime import UncertainRuntime, UncertainWorld
from stress_protocol import external_metrics


class LazyWideControl(ExpandingCycle):
    """Same grammar from outset; cached predictions and early rejection of models.

    Shared storage/executor and author. Not an independent architecture.
    Search enumeration is counted, not charged as fictitious physical expenditure.
    """
    def predict_model(self, model, probe):
        if not hasattr(self, '_prediction_cache'):
            self._prediction_cache = {}
        key = (tuple(model), probe, self.state()['context'] if probe.startswith('U') else None)
        if key not in self._prediction_cache:
            self._prediction_cache[key] = super().predict_model(model, probe)
        return self._prediction_cache[key]


def build_cases():
    rng = random.Random(261026091)
    cases = []
    for family in ('u3', 'v2', 'u4'):
        for radius in (0, 1):
            for budget in (5, 16):
                for repeat in range(2):
                    cases.append(dict(family=family, radius=radius, budget=budget,
                                      base=[rng.randrange(4), rng.randint(1, 4), rng.randrange(3)],
                                      coefficient=rng.randint(1, 2), bias=rng.choice([-radius, radius])))
    return cases


def run(root):
    root.mkdir(parents=True, exist_ok=False)
    cases = build_cases()
    protocol = dict(seed=261026091, cases=cases, stages=['base', 'changed', 'transfer', 'return'],
                    initial_resource=240, reserve=5, evaluator_points=[[4,1],[1,4],[3,3]],
                    policies=['adaptive','wide_cached','fixed','local'],
                    search_limit=1120, restart_after_every_step=True,
                    metrics=['actual reward', 'actual resource', 'action prediction mismatches',
                             'reserve breach', 'external extrapolation', 'search evaluations'],
                    limits='Developer-generated prospective cases, not independent/blind evaluation. '
                           'Evaluator-only points do not reach the agent. Search operations separately counted, '
                           'not claimed to be physical cost or elapsed-compute parity. No consciousness test.')
    (root/'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    src=root/'source'; src.mkdir(); manifest={}
    for path in Path(__file__).parent.glob('*.py'):
        data=path.read_bytes(); (src/path.name).write_bytes(data)
        manifest[path.name]=hashlib.sha256(data).hexdigest()
    (root/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    rows=[]
    for policy in protocol['policies']:
        for index, c in enumerate(cases):
            for stage, context in enumerate((0, 1, 2, 0)):
                b,a,q=c['base']; coefficient=c['coefficient']; family=c['family']
                def law(u,v,b=b,a=a,q=q,coefficient=coefficient,family=family,stage=stage):
                    extra={'u3':u**3, 'v2':v**2, 'u4':u**4}[family]
                    return b+a*u+q*u*v+(coefficient*extra if stage else 0)
                wp=root/f'{policy}-{index}-world.db'; ap=root/f'{policy}-{index}-agent.db'
                w=UncertainWorld(wp,law,context,initial=240,error_bound=c['radius'],sensor_bias=c['bias'])
                cls=UncertainRuntime if policy=='local' else LazyWideControl if policy=='wide_cached' else ExpandingCycle
                r=cls(ap)
                try:
                    before=w.balance(); n=w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]
                    if policy=='local': r.start_uncertain(w,budget=c['budget'])
                    else:r.start_cycle(w,budget=c['budget'],strategy='wide' if policy=='wide_cached' else policy)
                    for step in range(40):
                        s=r.step(w)
                        # Persisted state must survive a process-object restart at every step.
                        r.close(); r=cls(ap)
                        if r.state()!=json.loads(json.dumps(s)):raise AssertionError('state not recovered')
                        if s['phase'] in ('DONE','HALT'):break
                    else:raise AssertionError('step bound exceeded')
                    requests=[json.loads(x[0])[0] for x in w.db.execute('SELECT request FROM receipts ORDER BY rowid')][n:]
                    extrapolation=None
                    if policy!='local' and s['verified']:
                        ms=r.candidates(s)
                        def cost(m,u,v):
                            return m[0]+m[1]*u+m[2]*u*v+(m[3]*u**m[4]*v**m[5] if len(m)==6 else 0)
                        extrapolation=bool(ms) and all(all(cost(m,u,v)==law(u,v) for m in ms)
                                                       for u,v in protocol['evaluator_points'])
                    row=dict(policy=policy,case=index,stage=stage,phase=s['phase'],reason=s.get('reason'),
                             probes=len(s['evidence']),expansions=s.get('expansions',0),
                             search_used=s.get('search_used',0),verified=s.get('verified',False),
                             extrapolation_exact=extrapolation,transferred=s.get('transferred',False),
                             **external_metrics(before,w.balance(),requests,law,context))
                    rows.append(row)
                    with (root/'progress.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
                finally:r.close();w.close()
    summary={}
    for policy in protocol['policies']:
        part=[x for x in rows if x['policy']==policy]
        summary[policy]=dict(episodes=len(part),actions=sum(x['reward']>0 for x in part),
                            reward=sum(x['reward'] for x in part),probes=sum(x['probes'] for x in part),
                            resource_spent=sum(x['resource_spent'] for x in part),
                            breaches=sum(x['reserve_breach'] for x in part),
                            mismatches=sum(x['reason']=='EXECUTION_MISMATCH' for x in part),
                            exact_extrapolations=sum(x['extrapolation_exact'] is True for x in part),
                            nonexact_verified=sum(x['extrapolation_exact'] is False for x in part),
                            expansions=sum(x['expansions'] for x in part),
                            search_used=sum(x['search_used'] for x in part))
    (root/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    (root/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return summary


if __name__=='__main__':
    root=Path(__file__).parent/'runs'/datetime.now(timezone.utc).strftime('expansion-%Y%m%dT%H%M%S%fZ')
    print(root,flush=True)
    print(json.dumps(run(root),indent=2),flush=True)
