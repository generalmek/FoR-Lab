import tempfile
import unittest
from pathlib import Path
from native_incubator import NativeIncubator,NativeWorld,synthesize

class NativeTests(unittest.TestCase):
    def test_own_synthesis_transfer_and_revision(self):
        r=NativeIncubator(':memory:');w=NativeWorld(':memory:',lambda u,v:2+3*u+4*u*v,1)
        try:
            r.start_native(16,1);self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertTrue(r.state()['native_stored'])
            self.assertIsNone(r.db.execute("SELECT name FROM sqlite_master WHERE name='external_proposals'").fetchone())
            w.context=3;r.start_native(32,3);self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(len(r.state()['evidence']),1)
            w.law=lambda u,v:1+5*u+2*u*v
            r.start_native(23,3);self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertTrue(r.state()['native_gap']);self.assertTrue(r.state()['native_stored'])
        finally:r.close();w.close()

    def test_restart_mid_learning_and_after_effect(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'agent.sqlite';wp=Path(tmp)/'world.sqlite'
            w=NativeWorld(wp,lambda u,v:2+3*u+4*u*v,1);r=NativeIncubator(p)
            r.start_native(16,1)
            for _ in range(3):r.step(w)
            r.close();r=NativeIncubator(p)
            try:
                while len(r.state()['evidence'])<10:r.step(w)
                with self.assertRaises(RuntimeError):r.step(w,fail_at='after_effect')
                r.close();r=NativeIncubator(p)
                self.assertEqual(r.step(w)['phase'],'DONE')
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
            finally:r.close();w.close()

    def test_unknown_law_does_not_store_or_act(self):
        r=NativeIncubator(':memory:');w=NativeWorld(':memory:',lambda u,v:1+u*u*u+v,1)
        try:
            r.start_native(10,1);self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertEqual(r.db.execute('SELECT COUNT(*) FROM native_models').fetchone()[0],0)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()
