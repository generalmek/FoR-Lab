import json
import os
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
p=root/'runs/full-cycle-design-20261025T103514109588Z'
s=json.loads((p/'summary.json').read_text(encoding='utf-8'))
tests=(p/'tests.txt').read_text(encoding='utf-16' if (p/'tests.txt').read_bytes().startswith(b'\xff\xfe') else 'utf-8-sig')
assert '128 tests' in tests and 'OK' in tests
if os.name=='nt':
    import ctypes
    ctypes.windll.kernel32.SetConsoleTitleW('FoR-Lab | SELF-CHECKED FULL CYCLES')
    h=ctypes.windll.kernel32.GetStdHandle(-11)
    mode=ctypes.c_ulong()
    if ctypes.windll.kernel32.GetConsoleMode(h,ctypes.byref(mode)):
        ctypes.windll.kernel32.SetConsoleMode(h,mode.value|4)
C='\033[96m';G='\033[92m';Y='\033[93m';W='\033[0m'
print('\n'+C+'  '+'='*72)
print('  FoR-Lab     FULL CYCLE / SELF-CHECKED RESULTS 25 OCT 2026')
print('  '+'='*72+W)
print('\n  Unknown world -> hypotheses -> selected test -> checked knowledge')
print('  -> constrained action -> transfer -> contradiction -> revision')
print('  -> transfer again\n')
print(G+'  THREE DATASETS: 18 / 18 bounded four-task cycles completed'+W)
print(G+'  REGRESSION SUITE: 128 tests passed'+W)
print('\n  HOLDOUT DATASET          ACTIONS   PROBES   REVISIONS   CYCLES')
print('  '+'-'*68)
for k,label in [('full','Integrated cycle'),('B2_design','Separate design planner'),('no_core','Inquiry disabled'),('no_memory','Memory disabled')]:
    r=s[k]
    print(f"  {label:<25}{r['done']:>3}/24 {r['probes']:>8} {r['revisions']:>10} {r['complete_cycles']:>9}/6")
print('\n  Tight resource test: constraint selects affordable alternative.')
print('  Measurement error, persistence and model revision are included.')
print(Y+'\n  LIMITS: supplied grammar and norms; no full Reason/consciousness proof.')
print('  Separate planner ties; shared infrastructure. No superiority shown.'+W)
print('\n  Source: full-cycle-design-20261025T103514109588Z')
print(C+'  '+'='*72+W,flush=True)
if '--no-wait' not in sys.argv:input('\n  Enter to close... ')
