import tempfile
import unittest
from pathlib import Path
from funded_runtime import FundedWorld,FundedRuntime,ResourceDenied


class FundedTests(unittest.TestCase):
    def test_unfinishable_model_does_not_consume_resource(self):
        w=FundedWorld(':memory:',lambda u,v:2*u,0,initial=20,local_price=2,sample_price=2)
        r=FundedRuntime(':memory:')
        try:
            r.start_funded(w,'model_and_action')
            self.assertEqual(r.run(w)['reason'],'INSUFFICIENT_RESOURCE_TO_COMPLETE')
            self.assertEqual(w.balance(),20)
            r.start_funded(w,'action')
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(w.balance(),14)
        finally:r.close();w.close()

    def test_inquiry_and_action_share_resource(self):
        w=FundedWorld(':memory:',lambda u,v:2*u,0,initial=12,local_price=2)
        r=FundedRuntime(':memory:')
        try:
            r.start_funded(w);self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(w.balance(),6)  # 12 - measurement 2 - action 4
            r.start_funded(w);self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertEqual(w.balance(),6)
        finally:r.close();w.close()

    def test_measurement_crash_does_not_double_charge(self):
        class FaultWorld(FundedWorld):
            fail=True
            def measure(self,p):
                value=super().measure(p)
                if self.fail:self.fail=False;raise RuntimeError('after measurement commit')
                return value
        with tempfile.TemporaryDirectory() as tmp:
            ap=Path(tmp)/'agent.sqlite';wp=Path(tmp)/'world.sqlite'
            w=FaultWorld(wp,lambda u,v:2*u,0,initial=7,local_price=2)
            r=FundedRuntime(ap);r.start_funded(w)
            with self.assertRaises(RuntimeError):r.step(w)
            self.assertEqual(w.balance(),5);r.close();w.close()
            w=FundedWorld(wp,lambda u,v:2*u,0,initial=999,local_price=2);r=FundedRuntime(ap)
            try:
                self.assertEqual(r.run(w)['phase'],'HALT')
                self.assertEqual(w.balance(),5)
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM measurements').fetchone()[0],1)
                self.assertEqual(len(r.state()['evidence']),1)
            finally:r.close();w.close()

    def test_actual_cost_drift_is_caught_by_receiver_not_credited_to_agent(self):
        w=FundedWorld(':memory:',lambda u,v:2*u,0,initial=12);r=FundedRuntime(':memory:')
        try:
            r.start_funded(w);r.step(w)
            w.law=lambda u,v:20*u
            s=r.step(w)
            self.assertEqual(s['phase'],'HALT');self.assertEqual(s['reason'],'RESOURCE_INTERLOCK')
            self.assertEqual(w.balance(),11)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()

    def test_action_recovery_accounts_effect_once(self):
        w=FundedWorld(':memory:',lambda u,v:2*u,0,initial=12);r=FundedRuntime(':memory:')
        try:
            r.start_funded(w);r.step(w)
            with self.assertRaises(RuntimeError):r.step(w,fail_at='after_effect')
            self.assertEqual(w.balance(),7)
            self.assertEqual(r.step(w)['phase'],'DONE');self.assertEqual(w.balance(),7)
        finally:r.close();w.close()
