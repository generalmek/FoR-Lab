
import unittest
from core_revision import Knowledge, Agent, experiment


class CoreRevisionTests(unittest.TestCase):
    def test_forr_addressed_dependencies(self):
        r = experiment('FoR')
        self.assertEqual(r['recomputed'], ('heat_only', 'combined'))
        self.assertEqual(r['wrong'], ())
        self.assertEqual(r['cost'], 5)  # three initial + two updates

    def test_strong_b2_ties(self):
        f, b = experiment('FoR'), experiment('B2')
        self.assertEqual((f['recomputed'], f['wrong'], f['cost']),
                         (b['recomputed'], b['wrong'], b['cost']))

    def test_ablation_leaves_stale_predictions(self):
        r = experiment('FoR', propagate=False)
        self.assertEqual(r['recomputed'], ())
        self.assertEqual(r['wrong'], ('heat_only', 'combined'))

    def test_unobserved_drift_cannot_be_detected(self):
        for mode in ('FoR', 'B2'):
            r = experiment(mode, drift_observed=False)
            self.assertEqual(r['recomputed'], ())
            self.assertEqual(r['wrong'], ('heat_only', 'combined'))

    def test_unrelated_cause_is_not_invalidated(self):
        k = Knowledge()
        a = Agent('FoR', k)
        a.evaluate()
        a.incorporate_measurement('pressure', 5)
        updated = a.evaluate()
        self.assertEqual(tuple(x.name for x in updated if x.recomputed),
                         ('pressure_only', 'combined'))

    def test_unchanged_measurement_does_not_invalidate(self):
        k = Knowledge()
        a = Agent('FoR', k)
        a.evaluate()
        a.incorporate_measurement('heat', 2)
        self.assertFalse(any(x.recomputed for x in a.evaluate()))
        self.assertEqual(a.invalidations, 0)

    def test_two_revisions_before_evaluation(self):
        for mode in ('FoR', 'B2'):
            a = Agent(mode, Knowledge())
            a.evaluate()
            a.incorporate_measurement('heat', 4)
            a.incorporate_measurement('pressure', 7)
            result = a.evaluate()
            self.assertEqual([x.predicted for x in result], [4, 7, 11])
            self.assertTrue(all(x.recomputed for x in result))
            self.assertFalse(any(x.recomputed for x in a.evaluate()))

    def test_foR_propagation_is_not_b2_signature_check(self):
        f, b = experiment('FoR'), experiment('B2')
        self.assertEqual(f['signature_edge_checks'], 0)
        self.assertGreater(b['signature_edge_checks'], 0)
        self.assertEqual(f['invalidation_visits'], 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
