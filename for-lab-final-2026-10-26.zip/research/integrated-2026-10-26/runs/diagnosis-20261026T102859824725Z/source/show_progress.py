"""Capture a genuine cross-process memory experiment, without modifying the agent."""
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime

root = Path(__file__).resolve().parent
run = root / 'runs' / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
run.mkdir(parents=True)
episode = '''
import json,sys
from incubator import Knowledge,Agent,World,Runner
k=Knowledge(sys.argv[1])
r=Runner(Agent('FoR',k),World('interaction',2,'workshop',int(sys.argv[2]),'task')).run()
r['candidates']=k.state('workshop')[1]
k.close()
print(json.dumps(r))
'''
results = []
for target, db in [(4, 'memory.sqlite'), (8, 'memory.sqlite'), (8, 'fresh.sqlite')]:
    completed = subprocess.run([sys.executable, '-c', episode, str(run/db), str(target)],
                               cwd=root, capture_output=True, text=True, check=True)
    results.append({'target': target, 'database': db, **json.loads(completed.stdout)})
(run/'results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
lines = ['FoR-Lab | Actual experiment output',
         'Three separate Python processes. No LLM.', '']
for label, r in zip(['1. Learn: target 4', '2. Restart + new target 8', '3. Fresh memory: target 8'], results):
    lines += [label, f"   success={r['success']}   probes={r['tests']}   harm={r['harm']}",
              '   model=' + str(r['candidates']), '']
lines += ['Observed: saved knowledge reused for a different target.',
          'Limit: finite predefined models; not evidence of consciousness.',
          'FoR and B2 currently share the same decision algorithm.',
          'Core advantage is NOT demonstrated.']
(run/'terminal.txt').write_text('\n'.join(lines), encoding='utf-8')
print('\n'.join(lines))
print('ARTIFACT_DIR=' + str(run))
