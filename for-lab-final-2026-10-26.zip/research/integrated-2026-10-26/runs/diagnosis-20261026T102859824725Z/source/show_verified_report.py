"""Read verified artifacts and display a console report; no experiment rerun."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
print('\nFoR-Lab | VERIFIED RESEARCH REPORT\n'+'='*68)
latest=sorted((root/'runs').glob('verification-*'))[-1]
print('\n'.join((latest/'tests.txt').read_text(encoding='utf-8').splitlines()[-4:]))
run=sorted((root/'runs').glob('long-*'))[-1]
result=json.loads((run/'results.json').read_text(encoding='utf-8'))
print('\nLONG SEQUENCE: 120 tasks per policy, persistent memory\n')
for name,v in result['summary'].items():
    print(name)
    print('  research completed: {research_completed} | actions: {action_successes}'.format(**v))
    print('  expected stops: {negative_halts} | harm: {harm} | clean failures: {clean_failures}'.format(**v))
print('\nChecks: changed sensors/laws/costs, restart, faulty observations.')
print('Controls tie on outcomes. FoR advantage NOT established.')
print('Known sensor semantics, bounded model language; no consciousness claim.')
print('\nСТАТУС: исследовательский прототип; создание Разума не установлено.')
print('Проверено: пересмотр формулы, память, выбор и перестройка измерений.')
semantic=sorted((root/'runs').glob('semantic-*'))
if semantic:
    print('\nПРОВЕРКА ПРЕДЛОЖЕНИЯ НЕЙРОСЕТИ (внешний ChatGPT / Сол):')
    checks=json.loads((semantic[-1]/'results.json').read_text(encoding='utf-8'))
    for row in checks['rows']:
        print(' ',row['case'],':',row['status'],'| наблюдений:',row['observations'])
    print('Успех проверки не равен созданию сознания или доказательству всей теории.')
print('\nArtifacts:',run)
input('\nPress Enter to close this report...')
