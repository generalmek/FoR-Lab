import json
import subprocess
import sys
import sqlite3
import tempfile
import unittest
from pathlib import Path
from incubator_runtime import Runtime, Workshop


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'runtime.sqlite'
        self.r=Runtime(self.path)
        self.addCleanup(self.r.close)

    def learn(self):
        self.r.start(1)
        self.assertEqual(self.r.run(Workshop())['phase'],'DONE')

    def test_cold_loop_and_all_hidden_changes(self):
        self.learn()
        for gain,bias in ((2,0),(2,1),(3,-1)):
            self.r.start(gain)
            result=self.r.run(Workshop(gain,bias))
            self.assertEqual(result['phase'],'DONE')
            self.assertEqual(self.r.beliefs()['process'][0],gain)
            self.assertEqual(self.r.beliefs()['sensor'][0],bias)
        events=[json.loads(x[0])['kind'] for x in self.r.db.execute('SELECT body FROM events')]
        self.assertEqual(events.count('CONTRADICTION'),2)
        self.assertIn('RECHECK_INFEASIBLE_GOAL',events)

    def test_sensor_revision_preserves_process_version(self):
        self.learn(); before=self.r.beliefs()['process']
        self.r.start(1); self.r.run(Workshop(1,1))
        self.assertEqual(self.r.beliefs()['process'],before)
        self.assertEqual(self.r.db.execute("SELECT valid FROM forecasts WHERE name='physical'").fetchone()[0],1)

    def test_transaction_rolls_back_state_and_history(self):
        self.r.start(2); w=Workshop(2,1)
        while self.r.state()['phase']!='REVISE': self.r.step(w)
        before=(self.r.state(),self.r.beliefs(),list(self.r.db.execute('SELECT * FROM events')))
        with self.assertRaises(RuntimeError): self.r.step(w,fail_revision=True)
        self.assertEqual((self.r.state(),self.r.beliefs(),list(self.r.db.execute('SELECT * FROM events'))),before)
        self.assertEqual(self.r.db.execute('SELECT COUNT(*) FROM runtime_revisions').fetchone()[0],0)
        self.assertEqual(self.r.run(w)['phase'],'DONE')

    def test_scope_and_stale_task_permission_rejected(self):
        self.learn(); self.r.start(2); self.r.step(Workshop())
        permit=self.r.permit(2)
        self.assertIsNotNone(permit)
        self.assertIsNone(self.r.permit(3))
        self.r.step(Workshop())
        self.r.start(1); self.r.step(Workshop())
        w=Workshop()
        with self.assertRaises(ValueError): self.r.execute(w,permit)
        self.assertEqual(w.actions,[])

    def test_unknown_calibration_and_budget_stop(self):
        self.r.start(1,trusted=False)
        w=Workshop(); self.assertEqual(self.r.run(w)['reason'],'UNTRUSTED_CAL')
        self.assertEqual(w.actions,[])
        self.r.start(1,budget=1)
        self.assertEqual(self.r.run(w)['reason'],'BUDGET_LIMIT')
        self.assertEqual(w.actions,[])

    def test_unknown_law_and_false_calibration_stop(self):
        for name,w in [('nonlinear',Workshop(nonlinear=True)),('badcal',Workshop(bad_cal=True))]:
            r=Runtime(Path(self.tmp.name)/(name+'.sqlite'))
            try:
                r.start(1)
                self.assertEqual(r.run(w)['reason'],'OUT_OF_CLASS')
                self.assertEqual(w.actions,[])
            finally: r.close()

    def test_subprocess_resume_and_transfer(self):
        self.r.start(2); self.r.run(Workshop(2,1),steps=2)
        script=str(Path(__file__).with_name('incubator_runtime.py'))
        def call(*extra):
            return json.loads(subprocess.check_output([sys.executable,script,'--db',str(self.path),'--gain','2','--bias','1',*extra],text=True))
        self.assertEqual(call()['state']['phase'],'DONE')
        before=self.r.db.execute('SELECT COUNT(*) FROM events WHERE body LIKE ?',('%"PROBE"%',)).fetchone()[0]
        result=call('--target','4')
        self.assertEqual(result['state']['phase'],'DONE')
        after=self.r.db.execute('SELECT COUNT(*) FROM events WHERE body LIKE ?',('%"PROBE"%',)).fetchone()[0]
        self.assertEqual(before,after)

    def test_diagnosis_and_revision_ablations(self):
        self.learn(); self.r.diagnosis=False
        self.r.start(2)
        self.assertEqual(self.r.run(Workshop(2,0))['reason'],'DIAGNOSIS_DISABLED')
        self.r.diagnosis=True; self.r.revision=False
        self.r.start(2)
        self.assertEqual(self.r.run(Workshop(2,0))['reason'],'REVISION_DISABLED')

    def test_unreachable_goal_no_action(self):
        self.learn(); self.r.start(3)
        w=Workshop()
        self.assertEqual(self.r.run(w)['reason'],'NO_SCOPED_ACTION')
        self.assertEqual(w.actions,[])

    def test_compensating_drift_is_explicit_negative_case(self):
        self.learn(); self.r.start(1)
        w=Workshop(2,-1)  # observed U1 remains 1; physical output is now 2
        self.assertEqual(self.r.run(w)['phase'],'DONE')
        self.assertEqual(w.actions[0]['harm'],1)
        # DONE means no observed mismatch, not evaluator-certified physical success.
        self.assertEqual(self.r.beliefs()['process'][0],1)

    def test_incompatible_database_unchanged(self):
        path=Path(self.tmp.name)/'old.sqlite'
        db=sqlite3.connect(path)
        db.execute('CREATE TABLE old_model(value INTEGER)'); db.commit(); db.close()
        before=path.read_bytes()
        with self.assertRaises(ValueError): Runtime(path)
        self.assertEqual(path.read_bytes(),before)
