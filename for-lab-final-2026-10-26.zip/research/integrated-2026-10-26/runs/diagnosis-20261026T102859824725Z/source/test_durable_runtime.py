import tempfile
import unittest
from pathlib import Path
from durable_runtime import DurableRuntime,ReceiptWorkshop

class DurableTests(unittest.TestCase):
    def scenario(self,point):
        with tempfile.TemporaryDirectory() as tmp:
            agent=Path(tmp)/'agent.sqlite'; env=Path(tmp)/'receiver.sqlite'
            r=DurableRuntime(agent);w=ReceiptWorkshop(env);r.start_decision(2)
            try:
                for _ in range(10):r.step(w,fail_at=point)
                self.fail('injected failure did not occur')
            except RuntimeError as e:self.assertIn('injected',str(e))
            budget=r.state()['budget'];r.close();w.close()
            r=DurableRuntime(agent);w=ReceiptWorkshop(env)
            try:
                if point=='after_intent':
                    self.assertEqual(r.step(w)['reason'],'REVALIDATION_REQUIRED')
                    self.assertEqual(r.state()['budget'],budget)
                    self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
                    task_id=r.state()['task_id']
                    self.assertEqual(r.run(w)['phase'],'DONE')
                    self.assertEqual(r.state()['task_id'],task_id)
                    self.assertLess(r.state()['budget'],budget)
                else:
                    self.assertEqual(r.step(w)['phase'],'DONE')
                    self.assertEqual(r.state()['budget'],budget-1)
                for _ in range(3):r.step(w)
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
                self.assertEqual(r.db.execute("SELECT COUNT(*) FROM intents WHERE status='pending'").fetchone()[0],0)
            finally:r.close();w.close()
    def test_failure_before_effect(self):self.scenario('after_intent')
    def test_failure_after_effect(self):self.scenario('after_effect')
    def test_receiver_rejects_changed_request(self):
        w=ReceiptWorkshop(':memory:')
        try:
            w.apply_once('same',1,2)
            with self.assertRaises(ValueError):w.apply_once('same',2,4)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
        finally:w.close()

    def test_other_receiver_cannot_receive_pending_action(self):
        r=DurableRuntime(':memory:');w=ReceiptWorkshop(':memory:');other=ReceiptWorkshop(':memory:')
        try:
            r.start_decision(2)
            with self.assertRaises(RuntimeError):
                for _ in range(10):r.step(w,fail_at='after_effect')
            self.assertEqual(r.step(other)['reason'],'RECEIVER_IDENTITY_MISMATCH')
            self.assertEqual(other.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
            self.assertEqual(r.step(w)['phase'],'DONE')
        finally:r.close();w.close();other.close()

    def test_world_changed_during_outage_researched_before_action(self):
        r=DurableRuntime(':memory:');w=ReceiptWorkshop(':memory:')
        try:
            r.start_decision(2)
            with self.assertRaises(RuntimeError):
                for _ in range(10):r.step(w,fail_at='after_intent')
            w.gain=1
            self.assertEqual(r.run(w)['phase'],'DONE')
            import json
            receipt=json.loads(w.db.execute('SELECT result FROM receipts').fetchone()[0])
            self.assertEqual(receipt['harm'],0)
            request=json.loads(w.db.execute('SELECT request FROM receipts').fetchone()[0])
            self.assertEqual(request,[2,2])
        finally:r.close();w.close()

    def test_revalidation_cannot_refill_budget(self):
        r=DurableRuntime(':memory:');w=ReceiptWorkshop(':memory:')
        try:
            r.start_decision(2,budget=3)
            with self.assertRaises(RuntimeError):
                for _ in range(10):r.step(w,fail_at='after_intent')
            remaining=r.state()['budget']
            self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertLessEqual(r.state()['budget'],remaining)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()
