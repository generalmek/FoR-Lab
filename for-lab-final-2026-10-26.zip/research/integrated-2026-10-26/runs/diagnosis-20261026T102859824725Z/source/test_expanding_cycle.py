import tempfile
import unittest
from pathlib import Path
from expanding_cycle import ExpandingCycle, extensions
from uncertain_runtime import UncertainWorld


class ExpansionTests(unittest.TestCase):
    def test_composition_search_is_finite_unique(self):
        items = list(extensions())
        self.assertEqual(len(items), 1120)
        self.assertEqual(len(set(items)), 1120)

    def test_trigger_cannot_certify_its_own_evidence(self):
        w = UncertainWorld(':memory:', lambda u,v: 1+2*u+u**3, 1, error_bound=0)
        r = ExpandingCycle(':memory:')
        try:
            r.start_cycle(w)
            for _ in range(15):
                s = r.step(w)
                if s['expansions']:
                    self.assertFalse(s['verified'])
                    self.assertIsNone(s['validation_probe'])
                    self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0], 0)
                    break
            else:
                self.fail('contradiction not reached')
            s = r.run(w)
            self.assertEqual(s['phase'], 'DONE')
            self.assertTrue(s['verified'])
        finally:
            r.close(); w.close()

    def test_incomplete_search_is_not_out_of_class(self):
        w = UncertainWorld(':memory:', lambda u,v: 1+2*u+u**3, 1, error_bound=0)
        r = ExpandingCycle(':memory:')
        try:
            r.start_cycle(w, search_limit=1)
            s = r.run(w)
            self.assertEqual(s['reason'], 'SEARCH_BUDGET_EXHAUSTED')
            self.assertEqual(s['search_used'], 1)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0], 0)
        finally:
            r.close(); w.close()

    def test_restart_preserves_inquiry_and_no_duplicate_effect(self):
        with tempfile.TemporaryDirectory() as td:
            w = UncertainWorld(Path(td)/'w.db', lambda u,v: 1+2*u+u**3, 1, error_bound=0)
            r = ExpandingCycle(Path(td)/'a.db')
            r.start_cycle(w)
            try:
                for _ in range(25):
                    before = r.state()
                    r.close(); r = ExpandingCycle(Path(td)/'a.db')
                    self.assertEqual(r.state(), before)
                    s = r.step(w)
                    if s['phase'] in ('HALT', 'DONE'):
                        break
                self.assertEqual(s['phase'], 'DONE')
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0], 1)
            finally:
                r.close(); w.close()
