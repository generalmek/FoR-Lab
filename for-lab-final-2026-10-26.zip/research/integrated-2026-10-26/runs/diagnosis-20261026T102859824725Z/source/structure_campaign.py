"""Open structural-revision series. Evaluator function is never given to agent."""
import json
from pathlib import Path
from datetime import datetime,timezone
from structure_runtime import StructureRuntime
from durable_runtime import ReceiptWorkshop

class FunctionWorkshop(ReceiptWorkshop):
    def __init__(self,path,fn,bias):
        super().__init__(path,bias=bias);self.fn=fn
    def physical(self,u):return self.fn(u)

def main():
    out=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('structure-%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True);rows=[]
    for expand in (False,True):
        for a in (3,7):
            for q in (1,2):
                for bias in (-2,4):
                    name=f'{expand}-{a}-{q}-{bias}'
                    path=out/(name+'.sqlite');wp=out/(name+'-world.sqlite')
                    r=StructureRuntime(path,expand=expand)
                    w=FunctionWorkshop(wp,lambda u:a*u,bias)
                    for stage,target,budget in [('train_linear',2*a,6),('changed_law',2*a+4*q,6),('transfer',a+q,3)]:
                        if stage=='changed_law':w.fn=lambda u:a*u+q*u*u
                        r.close();r=StructureRuntime(path,expand=expand)
                        r.start_decision(target,budget=budget)
                        before=w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]
                        state=r.run(w)
                        effects=[json.loads(row[0]) for row in w.db.execute('SELECT result FROM receipts ORDER BY rowid')][before:]
                        events=[json.loads(row[0]) for row in r.db.execute('SELECT body FROM events')]
                        rows.append(dict(expand=expand,a=a,q=q,bias=bias,stage=stage,target=target,
                                         status=state['phase'],probes=len(state['evidence']),evidence=state['evidence'],
                                         success=bool(effects) and all(x['physical']==target for x in effects),
                                         harm=sum(x['harm'] for x in effects),model=r.remembered(),
                                         class_gap=any(e['kind']=='AFFINE_CLASS_GAP' and e['task_id']==state['task_id'] for e in events)))
                    r.close();w.close()
    summary={str(expand):{stage:dict(tasks=len(rr),successes=sum(x['success'] for x in rr),
                                    harm=sum(x['harm'] for x in rr),probes=sum(x['probes'] for x in rr),
                                    class_gaps=sum(x['class_gap'] for x in rr))
                         for stage in ('train_linear','changed_law','transfer')
                         for rr in [[x for x in rows if x['expand']==expand and x['stage']==stage]]}
             for expand in (False,True)}
    (out/'results.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2),encoding='utf-8')
    print(json.dumps(summary));print(out)
if __name__=='__main__':main()
