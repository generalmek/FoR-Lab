import tempfile
import unittest
from pathlib import Path
from decision_runtime import DecisionRuntime,select
from conflict_diagnosis import HYPOTHESES
from incubator_runtime import Workshop

class DecisionRuntimeTests(unittest.TestCase):
    def test_restart_preserves_pending_inquiry(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'decision.sqlite'
            r=DecisionRuntime(path); r.start_decision(2); w=Workshop(2,-1)
            r.step(w); before=r.state(); r.close()
            r=DecisionRuntime(path)
            try:
                self.assertEqual(r.state(),before)
                self.assertEqual(r.run(w)['phase'],'DONE')
                self.assertFalse(r.state()['certified'])
                self.assertEqual(r.beliefs()['process'],(1,0))
            finally:r.close()

    def test_budget_one_never_executes_uncertain_action(self):
        r=DecisionRuntime(':memory:'); w=Workshop(2,-1)
        try:
            r.start_decision(1,budget=1)
            self.assertEqual(r.run(w)['phase'],'HALT'); self.assertEqual(w.actions,[])
        finally:r.close()

    def test_low_value_task_can_decline_measurement(self):
        action,_=select(HYPOTHESES,2,(1,2),(),6,{p:'1' for p in ('CAL','U1','U2')},'1/10')
        self.assertEqual(action[0],'HALT')

    def test_unknown_class_halts_before_action(self):
        r=DecisionRuntime(':memory:'); w=Workshop(9,0)
        try:
            r.start_decision(2)
            self.assertEqual(r.run(w)['phase'],'HALT');self.assertEqual(w.actions,[])
        finally:r.close()
