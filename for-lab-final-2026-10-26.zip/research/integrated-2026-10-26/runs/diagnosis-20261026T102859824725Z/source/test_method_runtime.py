import json
import tempfile
import unittest
from pathlib import Path
from method_runtime import MethodRuntime,normalize,compile_program

OPS=[dict(name='delta12',vector=[0,1,3],cost=1),
     dict(name='delta23',vector=[0,1,5],cost=1),
     dict(name='sample2',vector=[1,2,4],cost=2),
     dict(name='sample4',vector=[1,4,16],cost=2),
     dict(name='sample5',vector=[1,5,25],cost=3)]

class SensorWorld:
    def __init__(self,ops,model=(4,3,2),corrupt=None):
        self.ops={o['name']:o for o in ops};self.model=model;self.corrupt=corrupt
    def measure_operation(self,name):
        # Independent straightforward measurement simulator; no actuator API.
        return sum(int(v)*m for v,m in zip(self.ops[name]['vector'],self.model))+(1 if name==self.corrupt else 0)

class MethodTests(unittest.TestCase):
    def test_restart_renaming_and_structure_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'agent.sqlite';r=MethodRuntime(p);w=SensorWorld(OPS)
            r.start_research(OPS);r.step(w);r.close();r=MethodRuntime(p)
            try:
                self.assertEqual(r.run(w)['phase'],'DONE')
                self.assertEqual(r.remembered(),('4','3','2'))
                renamed=[dict(o,name='new_'+o['name']) for o in OPS]
                r.start_research(renamed);self.assertEqual(r.run(SensorWorld(renamed))['phase'],'DONE')
                self.assertTrue(r.state()['research']['cache_hit'])
                changed=[dict(o,cost=o['cost']+1) for o in renamed]
                r.start_research(changed,budget=20);r.run(SensorWorld(changed))
                self.assertFalse(r.state()['research']['cache_hit'])
            finally:r.close()

    def test_prior_contradiction_rebuilds_program(self):
        r=MethodRuntime(':memory:')
        try:
            r.start_research(OPS);r.run(SensorWorld(OPS))
            r.start_research(OPS);s=r.run(SensorWorld(OPS,model=(4,3,5)))
            self.assertEqual(s['phase'],'DONE');self.assertTrue(s['research']['prior_refuted'])
            self.assertEqual(r.remembered(),('4','3','5'))
            self.assertFalse(s['certified'])
        finally:r.close()

    def test_check_corruption_halts_and_preserves_model(self):
        r=MethodRuntime(':memory:')
        try:
            ops=normalize(OPS);plan,_=compile_program(ops)
            r.start_research(OPS);s=r.run(SensorWorld(OPS,corrupt=ops[plan['check']]['name']))
            self.assertEqual(s['phase'],'HALT');self.assertIsNone(r.remembered())
            self.assertIn('precheck_model',s['research'])
        finally:r.close()

    def test_low_budget_and_rank_deficiency(self):
        bad=[dict(name=str(i),vector=[0,i,i],cost=1) for i in range(1,5)]
        for ops,budget in ((OPS,1),(bad,12)):
            r=MethodRuntime(':memory:')
            try:
                r.start_research(ops,budget);s=r.run(SensorWorld(ops))
                self.assertEqual(s['phase'],'HALT');self.assertEqual(s['research']['observed'],{})
            finally:r.close()

    def test_replanning_cannot_discard_contradictory_observation(self):
        r=MethodRuntime(':memory:')
        try:
            r.start_research(OPS);r.run(SensorWorld(OPS))
            ops=normalize(OPS);plan,_=compile_program(ops)
            r.start_research(OPS,budget=20)
            s=r.run(SensorWorld(OPS,corrupt=ops[plan['check']]['name']))
            self.assertEqual(s['phase'],'HALT')
            self.assertEqual(r.remembered(),('4','3','2'))
        finally:r.close()

    def test_independent_enumerators_choose_same_cost(self):
        ops=normalize(OPS)
        a,na=compile_program(ops,solver='combinations');b,nb=compile_program(ops,solver='permutations')
        self.assertEqual(a,b);self.assertGreater(nb,na)

    def test_research_model_used_by_existing_action_loop(self):
        from durable_runtime import ReceiptWorkshop
        class World(ReceiptWorkshop):
            def physical(self,u):return 3*u+2*u*u
        r=MethodRuntime(':memory:');w=World(':memory:',bias=4)
        try:
            r.start_research(OPS);r.run(SensorWorld(OPS))
            r.start_decision(14,budget=3)
            self.assertEqual(r.run(w)['phase'],'DONE')
            receipt=json.loads(w.db.execute('SELECT result FROM receipts').fetchone()[0])
            self.assertEqual(receipt['harm'],0)
        finally:r.close();w.close()
