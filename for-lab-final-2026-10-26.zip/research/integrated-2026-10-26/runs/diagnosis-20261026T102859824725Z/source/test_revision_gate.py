import tempfile
import unittest
from pathlib import Path
from conflict_diagnosis import predicted
from revision_gate import assess_revision,RevisionStore

def measurements(model):
    return [{'probe':p,'value':predicted(model,p)} for p in ('CAL','U1','U2')]

class GateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store=RevisionStore(Path(self.tmp.name)/'gate.sqlite')
        self.addCleanup(self.store.close)
        self.store.add_forecast('physical-result',['process'])
        self.store.add_forecast('sensor-zero',['sensor'])
        self.store.add_forecast('measured-result',['process','sensor'])

    def test_sensor_revision_preserves_process(self):
        r=self.store.apply(measurements((1,1)),True)
        self.assertEqual(r['status'],'REVISE_SENSOR')
        self.assertEqual(self.store.state()['process'],(1,0))
        self.assertEqual(set(r['affected']),{'sensor-zero','measured-result'})

    def test_process_revision_preserves_sensor(self):
        r=self.store.apply(measurements((2,0)),True)
        self.assertEqual(r['status'],'REVISE_PROCESS')
        self.assertEqual(self.store.state()['sensor'],(0,0))
        self.assertNotIn('sensor-zero',r['affected'])

    def test_unknown_calibration_cannot_authorize_revision(self):
        before=self.store.state()
        r=self.store.apply(measurements((2,1)),False)
        self.assertEqual(r['status'],'INSUFFICIENT_EVIDENCE')
        self.assertEqual(self.store.state(),before)

    def test_bad_calibration_conflicts_with_other_measurements(self):
        evidence=measurements((1,0))
        evidence[0]['value']=1
        r=self.store.apply(evidence,True)
        self.assertEqual(r['status'],'OUT_OF_CLASS')
        self.assertEqual(self.store.state()['sensor'],(0,0))

    def test_transaction_failure_rolls_back_everything(self):
        before=self.store.state()
        with self.assertRaises(RuntimeError):
            self.store.apply(measurements((2,1)),True,fail_after_update=True)
        self.assertEqual(self.store.state(),before)
        self.assertEqual(self.store.db.execute('SELECT COUNT(*) FROM history').fetchone()[0],0)
        self.assertEqual(self.store.db.execute('SELECT SUM(valid) FROM forecasts').fetchone()[0],3)

    def test_aliasing_unknown_law_never_authorizes_U3(self):
        # A nonlinear law may match these measurements yet diverge elsewhere.
        r=assess_revision((1,0),measurements((2,0)),True)
        self.assertEqual(r['status'],'REVISE_PROCESS')
        self.assertNotIn('U3',r['scope'])
        self.assertIn('CONSISTENT_WITH_TESTED_CLASS',r['qualification'])

    def test_repeated_evidence_does_not_increment_versions(self):
        self.store.apply(measurements((2,1)),True)
        before=self.store.state()
        r=self.store.apply(measurements((2,1)),True)
        self.assertEqual(r['status'],'NO_CHANGE')
        self.assertEqual(self.store.state(),before)
        self.assertEqual(r['affected'],[])
