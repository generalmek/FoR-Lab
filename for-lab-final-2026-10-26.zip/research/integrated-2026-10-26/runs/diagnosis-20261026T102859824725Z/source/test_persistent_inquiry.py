import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from persistent_inquiry import Store,run
from basis_inquiry import Task

class PersistentTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/'memory.sqlite'

    def test_actual_process_restart_and_new_target_for_both_agents(self):
        for mode in ('FoR','B2'):
            path=self.db.with_name(mode+'.sqlite')
            def process(target):
                cmd=[sys.executable,str(Path(__file__).with_name('persistent_inquiry.py')),'--db',str(path),
                     '--target',str(target),'--truth','1','2','--mode',mode]
                return json.loads(subprocess.run(cmd,capture_output=True,text=True,check=True).stdout)
            first,second=process(1),process(2)
            self.assertTrue(first['success'] and second['success'])
            self.assertEqual((first['measurements'],second['measurements']),(1,0))
            self.assertGreater(second['version'],first['version'])

    def test_contradiction_persists_and_prevents_repeated_action(self):
        run(self.db,'FoR',Task((1,0),1),(1,2))
        failed=run(self.db,'FoR',Task((1,0),2),(2,2))
        self.assertFalse(failed['success'])
        self.assertEqual(failed['harm'],1)
        later=run(self.db,'FoR',Task((1,0),2),(2,2))
        self.assertIsNone(later['success'])
        self.assertEqual(later['models'],())
        store=Store(self.db)
        try:
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM evidence').fetchone()[0],3)
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM versions').fetchone()[0],4)
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM predictions WHERE valid=1').fetchone()[0],0)
        finally: store.close()

    def test_revision_preserves_unrelated_prediction_and_group(self):
        store=Store(self.db)
        try:
            x=store.save_prediction('g',Task((1,0),1),1)
            y=store.save_prediction('g',Task((0,1),1),1)
            other=store.save_prediction('other',Task((1,0),1),1)
            _,_,affected=store.observe('g',{'kind':'TEST','axis':0,'value':1})
            self.assertEqual(affected,[x])
            valid=dict(store.db.execute('SELECT id,valid FROM predictions'))
            self.assertEqual((valid[y],valid[other]),(1,1))
        finally: store.close()
