
import tempfile
import unittest
from pathlib import Path
from incubator import Knowledge, Agent, Runner, World, Action, Observation, grammar


class IncubatorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'learn.sqlite'

    def run_case(self, name, family='interaction', k=2, group='g', target=4, budget=2):
        db = Knowledge(self.path)
        try:
            agent = Agent(name, db)
            result = Runner(agent, World(family, k, group, target, 'role_new', budget)).run()
            return result, db.state(group), db.evidence(group)
        finally:
            db.close()

    def test_learning_persists_across_restart_and_role_rename(self):
        first, state, evidence = self.run_case('FoR')
        self.assertTrue(first['success'])
        self.assertGreater(first['tests'], 0)
        self.assertEqual(state[0], len(evidence))
        second, _, _ = self.run_case('FoR')
        self.assertTrue(second['success'])
        self.assertEqual(second['tests'], 0)

    def test_equal_conditions_and_symmetric_outcomes(self):
        outcomes = []
        for name in ('FoR', 'B2'):
            self.path = Path(self.tmp.name) / f'{name}.sqlite'
            result, state, evidence = self.run_case(name)
            outcomes.append((result['success'], result['harm'], result['tests'], state, evidence))
        self.assertEqual(outcomes[0], outcomes[1])

    def test_budget_rejection(self):
        result, _, evidence = self.run_case('FoR', budget=0)
        self.assertIsNone(result['success'])
        self.assertEqual(result['tests'], 0)
        self.assertEqual(evidence, [])
        self.assertIn('BUDGET_LIMIT', str(result['trace']))

    def test_out_of_class_is_not_reset(self):
        db = Knowledge(self.path)
        try:
            obs = Observation('g', 'r', 2, ((1, 1),), 2)
            from incubator import Outcome
            db.learn(obs, Outcome('TEST', 1, 1, 999, None, 0, 1, False))
            self.assertEqual(db.state('g')[1], ())
        finally:
            db.close()
        result, state, _ = self.run_case('FoR', budget=2)
        self.assertEqual(state[1], ())
        self.assertIn('OUT_OF_CLASS', str(result['trace']))

    def test_robust_no_inquiry(self):
        # With goal 2, u=2,c=1 is not robust over k=1..3; force equal candidates
        db = Knowledge(self.path)
        try:
            obs = Observation('g', 'r', 2, ((1, 1),), 1)
            from incubator import Outcome
            db.learn(obs, Outcome('TEST', 1, 1, 2, None, 0, 1, False))
            result = Runner(Agent('FoR', db), World('linear', 2, 'g', 2, 'r', 2)).run()
            self.assertTrue(result['success'])
            self.assertEqual(result['tests'], 0)
            self.assertIn('ROBUST_NO_TEST', str(result['trace']))
        finally:
            db.close()

    def test_revision_invalidates_predictions(self):
        db = Knowledge(self.path)
        try:
            from incubator import Outcome
            obs = Observation('g', 'r', 2, ((1, 1),), 2)
            db.learn(obs, Outcome('TEST', 1, 1, 2, None, 0, 1, False))
            db.remember_prediction(obs, Action('PROCESS', 1, 1), 2)
            self.assertEqual(db.db.execute('SELECT COUNT(*) FROM predictions WHERE valid=1').fetchone()[0], 1)
            db.learn(obs, Outcome('TEST', 1, 2, 4, None, 0, 1, False))
            self.assertEqual(db.db.execute('SELECT COUNT(*) FROM predictions WHERE valid=1').fetchone()[0], 0)
            self.assertEqual(db.state('g')[1], (('interaction', 2),))
        finally:
            db.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
