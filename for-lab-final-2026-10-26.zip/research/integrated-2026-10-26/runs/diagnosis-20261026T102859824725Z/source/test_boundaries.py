import unittest
import tempfile
from pathlib import Path
from incubator import Agent, Knowledge, Runner, World, Action, Observation, Outcome, demo


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'memory.sqlite'
        self.k = Knowledge(self.path)
        self.addCleanup(self.k.close)

    def run_world(self, family='interaction', k=2, target=4, budget=2):
        return Runner(Agent('FoR', self.k), World(family, k, 'g', target, 'r', budget)).run()

    def test_unreachable_is_not_unidentifiable(self):
        result = self.run_world(target=999)
        self.assertIn('NO_FEASIBLE_ACTION', str(result['trace']))
        self.assertEqual(result['tests'], 0)
        self.assertIsNone(result['success'])

    def test_hidden_drift_first_failure_is_preserved_then_abstention(self):
        self.assertTrue(self.run_world()['success'])
        failed = self.run_world(family='linear', k=1, target=8)
        self.assertFalse(failed['success'])
        self.assertEqual(failed['harm'], 1)
        self.assertIn('MODEL_CONTRADICTION', str(failed['trace']))
        self.assertEqual(self.k.state('g')[1], ())
        subsequent = self.run_world(family='linear', k=1, target=8)
        self.assertIsNone(subsequent['success'])
        self.assertEqual(subsequent['harm'], 0)
        self.assertIn('OUT_OF_CLASS', str(subsequent['trace']))

    def test_versions_and_raw_evidence_survive(self):
        self.run_world()
        count = self.k.db.execute('SELECT COUNT(*) FROM claim_versions WHERE grp="g"').fetchone()[0]
        self.assertEqual(count, self.k.state('g')[0] + 1)
        self.assertEqual(len(self.k.evidence('g')), 2)

    def test_unrelated_predictions_remain_valid(self):
        obs = Observation('other', 'r', 2, ((1, 1),), 2)
        self.k.remember_prediction(obs, Action('PROCESS', 1, 1), 2)
        self.run_world()
        self.assertEqual(self.k.db.execute('SELECT valid FROM predictions WHERE grp="other"').fetchone()[0], 1)

    def test_invalid_action_does_not_consume_budget(self):
        world = World('linear', 2, 'g', 2, 'r', 1)
        with self.assertRaises(ValueError):
            world.step(Action('TEST', 999, 1))
        self.assertEqual(world.budget, 1)
        self.assertFalse(world.terminal)

    def test_constructor_rejects_bad_budget_and_family(self):
        for family, budget in [('unknown', 1), ('linear', -1)]:
            with self.assertRaises(ValueError):
                World(family, 2, 'g', 2, 'r', budget)

    def test_exact_budget_suffices(self):
        result = self.run_world(budget=1)
        self.assertTrue(result['success'])
        self.assertEqual(result['tests'], 1)

    def test_real_outside_class_measurement(self):
        result = self.run_world(family='linear', k=7)
        self.assertIsNone(result['success'])
        self.assertEqual(self.k.state('g')[1], ())
        self.assertIn('OUT_OF_CLASS', str(result['trace']))

    def test_existing_demo_is_never_overwritten(self):
        prefix = Path(self.tmp.name) / 'demo.sqlite'
        demo(prefix)
        file = prefix.with_name('demo_FoR.sqlite')
        before = file.read_bytes()
        with self.assertRaises(FileExistsError):
            demo(prefix)
        self.assertEqual(file.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
