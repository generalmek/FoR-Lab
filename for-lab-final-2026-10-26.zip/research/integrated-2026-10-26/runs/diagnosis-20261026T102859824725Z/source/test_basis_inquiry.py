import unittest
from basis_inquiry import Agent,Task,episode

class BasisTests(unittest.TestCase):
    def test_irrelevant_cue_is_not_followed(self):
        task=Task((1,0),1,cue=1)
        for mode in ('FoR','B2'):
            r=episode(mode,task,(1,2))
            self.assertTrue(r['success'])
            self.assertEqual(next(x['axis'] for x in r['trace'] if 'test' in x),0)
        self.assertIsNone(episode('cue_only',task,(1,2))['success'])

    def test_relabeling_preserves_choice_and_outcome(self):
        for mode in ('FoR','B2'):
            a=episode(mode,Task((0,1),2,cue=0),(1,2))
            b=episode(mode,Task((0,1),2,('alpha','omega'),0),(1,2))
            self.assertEqual((a['success'],a['measurements']),(b['success'],b['measurements']))
            self.assertEqual(next(x['axis'] for x in b['trace'] if 'test' in x),1)

    def test_budget_and_pending_evidence_enforced(self):
        a=Agent('FoR',Task((1,0),1))
        self.assertEqual(a.decide(),('TEST',0))
        with self.assertRaises(RuntimeError): a.decide()
        with self.assertRaises(ValueError): a.receive(1,1)
        a.receive(0,1)
        self.assertEqual(a.budget,0)
        self.assertEqual(a.decide(),('PROCESS',1))

    def test_outside_class_observation_stops(self):
        r=episode('FoR',Task((1,0),1),(7,1))
        self.assertIsNone(r['success'])
        self.assertEqual(r['final_models'],())
        self.assertEqual(r['trace'][-1]['stop'],'CONTRADICTION')

    def test_one_measurement_can_leave_critical_uncertainty(self):
        r=episode('FoR',Task((1,1),2),(1,7))
        self.assertIsNone(r['success'])
        self.assertEqual(r['harm'],0)

    def test_swapping_roles_follows_dependency(self):
        for mode in ('FoR','B2'):
            first=episode(mode,Task((1,0),1,cue=1),(1,2))
            swapped=episode(mode,Task((0,1),1,cue=0),(2,1))
            self.assertEqual(first['success'],swapped['success'])
            self.assertEqual(next(x['axis'] for x in first['trace'] if 'test' in x),0)
            self.assertEqual(next(x['axis'] for x in swapped['trace'] if 'test' in x),1)

    def test_zero_budget_cannot_measure(self):
        r=episode('FoR',Task((1,0),1),(1,2),0)
        self.assertEqual(r['measurements'],0)
        self.assertIsNone(r['success'])
