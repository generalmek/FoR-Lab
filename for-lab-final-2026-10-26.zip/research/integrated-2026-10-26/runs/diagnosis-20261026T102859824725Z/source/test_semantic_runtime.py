import json
import unittest
from semantic_runtime import SemanticRuntime,parse_proposal,evaluate_ast
from semantic_campaign import ROOT,TwoInputWorld,controls

class SemanticTests(unittest.TestCase):
    def setUp(self):
        self.raw=(ROOT/'received/sol-semantic-proposal-2026-10-25.json').read_text(encoding='utf-8')
        self.protocol=json.loads((ROOT/'semantic_protocol.json').read_text(encoding='utf-8-sig'))

    def test_real_candidate_and_adversarial_controls(self):
        expected=['CHECKED','FALSIFIED','REJECTED','INCOMPLETE','FALSIFIED']
        for case,status in zip(controls(self.raw),expected):
            name,raw,budget,changed=case
            with self.subTest(name=name):
                r=SemanticRuntime(':memory:')
                try:
                    r.start_proposal(raw,{'provider':'test'},self.protocol['training'],self.protocol['validation'],budget)
                    r.run(TwoInputWorld(changed))
                    self.assertEqual(r.db.execute('SELECT status FROM external_proposals').fetchone()[0],status)
                    self.assertEqual(r.db.execute('SELECT COUNT(*) FROM semantic_models').fetchone()[0],int(status=='CHECKED'))
                    self.assertIsNone(r.permit(1))
                finally:r.close()

    def test_strict_language_rejects_code_duplicates_unknown_vars(self):
        bad=['{"expression":{"var":"secret"},"claim":"hypothesis"}',
             '{"expression":{"const":true},"claim":"hypothesis"}',
             '{"expression":{"const":1,"const":2},"claim":"hypothesis"}',
             '{"expression":{"const":21},"claim":"hypothesis"}',
             '__import__("os").system("echo unsafe")']
        for raw in bad:
            with self.subTest(raw=raw),self.assertRaises(ValueError):parse_proposal(raw)

    def test_training_fit_does_not_imply_validation(self):
        overfit=controls(self.raw)[1][1];ast=parse_proposal(overfit)
        self.assertTrue(all(evaluate_ast(ast,{'u':p['u'],'v':p['v']})==p['y'] for p in self.protocol['training']))
        point=self.protocol['validation'][0]
        self.assertNotEqual(evaluate_ast(ast,point),TwoInputWorld().observe(point))

    def test_checked_points_must_not_repeat_training(self):
        r=SemanticRuntime(':memory:')
        try:
            with self.assertRaises(ValueError):r.start_proposal(self.raw,{},self.protocol['training'],[{'u':0,'v':0},{'u':1,'v':0}])
        finally:r.close()
