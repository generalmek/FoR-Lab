"""Reproducible local checks; unique outputs, no third-party dependencies."""
import io
import json
import tempfile
import unittest
from pathlib import Path
from datetime import datetime, timezone
from incubator import Agent, Knowledge, Runner, World, grammar, ACTIONS, predict

root = Path(__file__).resolve().parent
temp = root / '.test-tmp'
temp.mkdir(exist_ok=True)
tempfile.tempdir = str(temp)
run = root / 'runs' / datetime.now(timezone.utc).strftime('verification-%Y%m%dT%H%M%S%fZ')
run.mkdir(parents=True)
buffer = io.StringIO()
suite = unittest.defaultTestLoader.discover(str(root), pattern='test_*.py')
result = unittest.TextTestRunner(stream=buffer, verbosity=2).run(suite)
(run / 'tests.txt').write_text(buffer.getvalue(), encoding='utf-8')
rows = []
for family, k in grammar():
    for target in range(1, 14):
        for budget in (0, 1, 2):
            for name in ('FoR', 'B2'):
                memory = Knowledge(':memory:')
                answer = Runner(Agent(name, memory), World(family, k, 'g', target, 'r', budget)).run()
                rows.append(dict(family=family, k=k, target=target, budget=budget, agent=name,
                                 feasible=any(predict((family,k),u,c)==target for u,c in ACTIONS), **answer))
                memory.close()
summary = dict(tests_run=result.testsRun, tests_ok=result.wasSuccessful(), episodes=len(rows),
               successes=sum(r['success'] is True for r in rows),
               harms=sum(r['harm'] for r in rows),
               abstentions=sum(r['success'] is None for r in rows),
               paired_outcomes_equal=all(tuple(rows[i][x] for x in ('success','harm','tests')) ==
                                        tuple(rows[i+1][x] for x in ('success','harm','tests'))
                                        for i in range(0,len(rows),2)))
summary['by_budget'] = {str(b): {
    'episodes': sum(r['budget']==b for r in rows),
    'feasible': sum(r['budget']==b and r['feasible'] for r in rows),
    'successes': sum(r['budget']==b and r['success'] is True for r in rows),
} for b in (0,1,2)}
memory = Knowledge(run/'drift.sqlite')
drift = []
for family,k,target in [('interaction',2,4),('linear',1,8),('linear',1,8)]:
    answer = Runner(Agent('FoR',memory),World(family,k,'g',target,'r')).run()
    drift.append(dict(family=family,k=k,target=target,**answer))
memory.close()
(run/'negative-drift.json').write_text(json.dumps(drift,indent=2),encoding='utf-8')
(run / 'episodes.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
(run / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(buffer.getvalue())
print(json.dumps(summary, indent=2))
print('ARTIFACT_DIR=' + str(run))
raise SystemExit(0 if result.wasSuccessful() else 1)
