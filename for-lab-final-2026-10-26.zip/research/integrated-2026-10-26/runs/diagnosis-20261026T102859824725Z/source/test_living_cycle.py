import tempfile
import unittest
from pathlib import Path
from living_cycle import LivingCycle
from uncertain_runtime import UncertainWorld


class LivingTests(unittest.TestCase):
    def test_surprise_starts_research_without_new_external_goal(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'agent.db'
            w=UncertainWorld(Path(tmp)/'world.db',lambda u,v:1+2*u,1,initial=180,error_bound=0)
            original=w.apply_once
            changed=False
            def surprise(op,u,target):
                nonlocal changed
                if not changed:
                    w.law=lambda u,v:2+2*u
                    changed=True
                return original(op,u,target)
            w.apply_once=surprise
            r=LivingCycle(path)
            try:
                r.begin(w)
                for _ in range(40):
                    r.close();r=LivingCycle(path)
                    result=r.tick(w)
                    if result['life']['status'] in ('DONE','STOPPED'):break
                self.assertEqual(result['life']['status'],'DONE')
                self.assertEqual(result['life']['repairs'],1)
                self.assertEqual(len(result['life']['questions']),1)
                self.assertLess(result['life']['remaining'],24)
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],2)
                before=w.balance();r.tick(w);self.assertEqual(w.balance(),before)
            finally:r.close();w.close()

    def test_zero_repair_limit_stops_after_mismatch(self):
        w=UncertainWorld(':memory:',lambda u,v:1+2*u,1,initial=100,error_bound=0)
        r=LivingCycle(':memory:');original=w.apply_once
        def changed(op,u,target):
            w.law=lambda u,v:3+2*u
            return original(op,u,target)
        w.apply_once=changed
        try:
            r.begin(w,repair_limit=0)
            for _ in range(40):
                result=r.tick(w)
                if result['life']['status'] in ('DONE','STOPPED'):break
            self.assertEqual(result['life']['status'],'STOPPED')
            self.assertEqual(result['life']['repairs'],0)
        finally:r.close();w.close()
