import unittest
from research_choice import ResearchChoice
from continuous_campaign import ResourceWorld


class ResearchChoiceTests(unittest.TestCase):
    def test_switch_deliverable_without_calling_local_record_a_model(self):
        r=ResearchChoice(':memory:');w=ResourceWorld(':memory:',lambda u,v:1+2*u+u*v,1)
        try:
            r.start_choice(1,80,5)
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(r.state()['research_method'],'direct')
            self.assertEqual(r.db.execute('SELECT COUNT(*) FROM native_models').fetchone()[0],0)
            r.start_choice(1,w.balance(),5,deliverable='model_and_action')
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertTrue(r.state()['native_stored'])
            self.assertEqual(r.state()['research_method'],'model')
        finally:r.close();w.close()

    def test_short_budget_does_not_relax_model_requirement(self):
        r=ResearchChoice(':memory:');w=ResourceWorld(':memory:',lambda u,v:1+u,0)
        try:
            r.start_choice(0,80,5,deliverable='model_and_action',budget=3)
            self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertEqual(w.balance(),80)
            self.assertFalse(r.state()['native_stored'])
        finally:r.close();w.close()

    def test_unrepresentable_model_is_not_substituted_by_action(self):
        r=ResearchChoice(':memory:');w=ResourceWorld(':memory:',lambda u,v:1+u**3+v,1)
        try:
            r.start_choice(1,80,5,deliverable='model_and_action')
            self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertFalse(r.state()['native_stored'])
            self.assertEqual(w.balance(),80)
        finally:r.close();w.close()
