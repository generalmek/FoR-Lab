"""Open development integration series; keeps per-case SQLite and raw evaluator traces."""
import json
from pathlib import Path
from datetime import datetime, timezone
from incubator_runtime import Runtime, Workshop

root=Path(__file__).resolve().parent
out=root/'runs'/datetime.now(timezone.utc).strftime('integration-%Y%m%dT%H%M%S%fZ')
out.mkdir(parents=True)
rows=[]
for mode in ('FoR','B2'):
    for g in (1,2,3):
        for b in (-1,0,1):
            r=Runtime(out/f'{mode}-{g}-{b}.sqlite',mode)
            r.start(1); r.run(Workshop())
            r.start(g)
            world=Workshop(g,b)
            result=r.run(world)
            rows.append(dict(mode=mode,g=g,b=b,phase=result['phase'],reason=result['reason'],
                             actions=world.actions,beliefs=r.beliefs()))
            r.close()
(out/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
summary=dict(episodes=len(rows),model_consistent_completions=sum(x['phase']=='DONE' for x in rows),
             evaluator_final_successes=sum(bool(x['actions']) and x['actions'][-1]['harm']==0 for x in rows),
             episodes_without_harm=sum(not any(a['harm'] for a in x['actions']) for x in rows),
             harms=sum(a['harm'] for x in rows for a in x['actions']),
             paired_equal=all({k:v for k,v in rows[i].items() if k!='mode'}==
                              {k:v for k,v in rows[i+9].items() if k!='mode'} for i in range(9)),
             claim='Open finite-class integration, not independent validation or FoR advantage')
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
neg=Runtime(out/'negative-compensating-drift.sqlite')
neg.start(1); neg.run(Workshop())
neg.start(1); alias=Workshop(2,-1); observed=neg.run(alias)
(out/'negative-compensating-drift.json').write_text(json.dumps(dict(state=observed,
    evaluator_actions=alias.actions,meaning='DONE is not proof of physical success; drift can mask itself'),indent=2),encoding='utf8')
neg.close()
summary['compensating_drift_control']=dict(model_consistent_completion=observed['phase']=='DONE',
                                         evaluator_success=alias.actions[-1]['harm']==0,
                                         harm=sum(a['harm'] for a in alias.actions))
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(summary,indent=2)); print('ARTIFACT_DIR='+str(out))
