"""One actual external ChatGPT candidate plus labelled synthetic negative controls."""
import json
from pathlib import Path
from datetime import datetime,timezone
from semantic_runtime import SemanticRuntime

ROOT=Path(__file__).resolve().parent

class TwoInputWorld:
    def __init__(self,changed=False):self.changed=changed
    def observe(self,p):
        u,v=p['u'],p['v']
        return 2+3*u+4*u*v+(u if self.changed and v>=3 else 0)

def controls(raw):
    base=json.loads(raw)
    def mul(a,b):return dict(op='mul',left=a,right=b)
    def add(a,b):return dict(op='add',left=a,right=b)
    u={'var':'u'}
    extra=mul(u,mul(add(u,{'const':-1}),add(u,{'const':-2})))
    overfit=json.dumps(dict(expression=add(base['expression'],extra),claim='hypothesis'))
    return [('sol_actual',raw,6,False),('synthetic_training_overfit',overfit,6,False),
            ('synthetic_code_request','{"expression":{"call":"os.system"},"claim":"hypothesis"}',6,False),
            ('budget_shortfall',raw,2,False),('changed_world',raw,6,True)]

def main():
    out=ROOT/'runs'/datetime.now(timezone.utc).strftime('semantic-%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
    protocol=json.loads((ROOT/'semantic_protocol.json').read_text(encoding='utf-8-sig'))
    raw=(ROOT/'received/sol-semantic-proposal-2026-10-25.json').read_text(encoding='utf-8').strip()
    rows=[]
    for name,candidate,budget,changed in controls(raw):
        p=out/(name+'.sqlite');r=SemanticRuntime(p)
        source=dict(provider='ChatGPT browser / Sol' if name=='sol_actual' else 'labelled control',
                    chat='6ad8f171-9ac8-83ed-b24f-4cd4771131df' if name=='sol_actual' else None)
        r.start_proposal(candidate,source,protocol['training'],protocol['validation'],budget)
        world=TwoInputWorld(changed)
        for _ in range(12):
            state=r.step(world);r.close();r=SemanticRuntime(p)
            if state['phase'] in ('DONE','HALT'):break
        else:raise AssertionError('validation did not stop')
        status=r.db.execute('SELECT status FROM external_proposals ORDER BY id DESC LIMIT 1').fetchone()[0]
        stored=r.db.execute('SELECT COUNT(*) FROM semantic_models').fetchone()[0]
        rows.append(dict(case=name,status=status,phase=state['phase'],reason=state['reason'],
                         observations=len(state['evidence']),stored_models=stored,evidence=state['evidence']))
        r.close()
    (out/'results.json').write_text(json.dumps(dict(rows=rows),indent=2),encoding='utf-8')
    print(json.dumps([{k:v for k,v in x.items() if k!='evidence'} for x in rows]));print(out)
if __name__=='__main__':main()
