import unittest
from outcome_revision import OutcomeRevisionCycle
from uncertain_runtime import UncertainWorld


class OutcomeRevisionTests(unittest.TestCase):
    def test_real_outcome_revokes_transferred_model_and_next_task_researches(self):
        w=UncertainWorld(':memory:',lambda u,v:1+2*u,1,initial=160,error_bound=0)
        r=OutcomeRevisionCycle(':memory:')
        try:
            r.start_cycle(w);s=r.run(w)
            self.assertEqual(s['phase'],'DONE')
            # Change after fresh action measurement, immediately before execution.
            r.start_cycle(w)
            r.step(w)
            original=w.apply_once
            def changed(op,u,target):
                w.law=lambda u,v:2+2*u
                return original(op,u,target)
            w.apply_once=changed
            s=r.run(w)
            self.assertEqual(s['reason'],'EXECUTION_MISMATCH')
            self.assertFalse(s['verified'])
            self.assertIsNone(r.permit(2))
            self.assertEqual(r.db.execute('SELECT COUNT(*) FROM model_revocations').fetchone()[0],1)
            r.step(w)
            self.assertEqual(r.db.execute('SELECT COUNT(*) FROM model_revocations').fetchone()[0],1)
            r.start_cycle(w)
            self.assertFalse(r.state()['transferred'])
            self.assertFalse(r.state()['verified'])
        finally:r.close();w.close()
