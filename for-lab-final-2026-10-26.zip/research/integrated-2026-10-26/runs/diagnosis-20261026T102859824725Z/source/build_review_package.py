"""Create a local, allowlisted review copy. Never alters the source lab or uploads."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

LAB = Path(__file__).resolve().parent
REPORTS = ['EXPANSION_RESULTS_RU.md', 'INITIATIVE_RESULTS_RU.md',
           'PROTOTYPE_AUDIT_2026-10-26_RU.md']
RUNS = ['expansion-20261026T083936522806Z', 'expansion-20261026T083946911762Z',
        'outcome-replay-20261026T084259190649Z', 'initiative-20261026T090726418668Z',
        'initiative-audit-20261026T090935408776Z']

README = '''# FoR-Lab — review snapshot / пакет проверки

Research project by Mihail Tkalic. Code, experiment design and review developed with AI assistance. AI-assisted review is not independent validation.
Исследовательский проект Михаила Ткалича. Код, протоколы и разбор результатов подготовлены с применением ИИ. Это не независимая экспертиза.

## Verdict / Вердикт

A bounded integrated prototype runs: opportunity selection → inquiry → model revision → validation → action → outcome → next selection. It does not establish artificial Reason, consciousness, autonomous goal creation, or architectural superiority.
Ограниченный интегрированный прототип работает. Создание Разума, сознание, самостоятельное порождение целей и превосходство архитектуры не установлены.

Prospective developer evaluation: 24 campaigns per policy. Learned selection: reward 2164, expenditure 2086, 188 actions. Maximum-reward selection: reward 2186, expenditure 2259, 177 actions. The simple control earns more total reward. Resource savings are a separate outcome. See the dated audit report for errors, controls and scope.
Новая серия: 24 кампании на политику. Выбор по опыту: награда 2164, расход 2086, 188 действий. Максимальная награда: 2186, 2259, 177 соответственно. Простой контроль лучше по суммарной награде. Экономия ресурса — отдельный результат.

## Run / Запуск

Tested on Python 3.13. Standard library only; no downloads, neural model, API keys or paid services needed. From this directory:
Проверено на Python 3.13, только стандартная библиотека. Из этого каталога:

```
python verify_package.py
python -m unittest discover -v
python initiative_experiment.py --audit
```

The experiment writes a NEW timestamped directory in runs/. It does not overwrite the supplied data. Compare its summary.json with runs/initiative-audit-20261026T090935408776Z/summary.json. Reproduction of the same seed confirms reproducibility only, not independent generalization.
Опыт создаёт НОВУЮ папку в runs/. Сравните summary.json с сохранённой серией. Повтор одного seed проверяет воспроизводимость, не независимое обобщение.

## Contents / Состав

- Python modules and tests, including historical experimental branches. Only initiative_experiment.py --audit is the current integrated acceptance entrypoint.
- Five original run directories with pre-run source snapshots, protocols, hashes, SQLite databases and traces. The first expansion run was aborted by a harness state-comparison error and is retained as an unsuccessful run, not a result.
- Three current reports. Earlier branches are not asserted to be one unified system.
- package-manifest.json records the files present at packaging. New test/run output is outside that manifest.

Исключены личные переписки, снимки браузера, окружения, кэши и старые демонстрационные экраны с фиксированными числами. Передача или публикация пакета не выполнялась.

Limits: supplied grammar, semantics, utility and opportunity menu; shared author/executor for controls; simulated resource interlock; no independent replication. Full crash recovery of the campaign scheduler is not established. See PROTOTYPE_AUDIT_2026-10-26_RU.md.
'''

VERIFIER = '''import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'package-manifest.json').read_text(encoding='utf-8'))
errors=[]
for name,digest in manifest['files'].items():
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest: errors.append(name)
if errors: raise SystemExit('MISSING OR MODIFIED: '+repr(errors))
print('Package hashes match:',len(manifest['files']),'files. This checks integrity, not scientific validity.')
'''


def build():
    out=LAB.parent/'review-packages'/('for-lab-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    out.mkdir(parents=True,exist_ok=False)
    excluded={'show_cycle_terminal.py','show_verified_report.py','show_progress.py','build_review_package.py'}
    for p in LAB.glob('*.py'):
        if p.name not in excluded:shutil.copy2(p,out/p.name)
    for name in REPORTS:shutil.copy2(LAB/name,out/name)
    shutil.copy2(LAB/'semantic_protocol.json',out/'semantic_protocol.json')
    (out/'received').mkdir()
    shutil.copy2(LAB/'received'/'sol-semantic-proposal-2026-10-25.json',
                 out/'received'/'sol-semantic-proposal-2026-10-25.json')
    for name in RUNS:
        shutil.copytree(LAB/'runs'/name,out/'runs'/name,
                        ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (out/'README.md').write_text(README,encoding='utf-8')
    (out/'verify_package.py').write_text(VERIFIER,encoding='utf-8')
    files={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
           for p in sorted(out.rglob('*')) if p.is_file()}
    (out/'package-manifest.json').write_text(json.dumps(dict(files=files),indent=2),encoding='utf-8')
    print(out)


if __name__=='__main__':build()
