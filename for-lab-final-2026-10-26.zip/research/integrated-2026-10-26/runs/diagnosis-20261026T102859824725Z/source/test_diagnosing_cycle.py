import json
import tempfile
import unittest
from pathlib import Path
from diagnosing_cycle import DiagnosingCycle,ReferenceWorld


def finish(agent,world,limit=80):
    for _ in range(limit):
        result=agent.tick(world)
        if result['life']['status'] in ('DONE','STOPPED'):return result
    raise AssertionError('cycle did not terminate')


class DiagnosingTests(unittest.TestCase):
    def test_sensor_drift_keeps_process_and_rebinds_permission(self):
        with tempfile.TemporaryDirectory() as tmp:
            ap=Path(tmp)/'agent.db'
            w=ReferenceWorld(Path(tmp)/'world.db',lambda u,v:1+2*u,1,initial=300,error_bound=0)
            r=DiagnosingCycle(ap)
            try:
                r.begin(w,budget=80)
                for _ in range(40):
                    s=r.state()
                    if any(e['probe'].startswith('U') for e in s['evidence']):break
                    r.tick(w)
                else:self.fail('no pre-action observation')
                before_pool=s['pool'];before_models=r.db.execute('SELECT COUNT(*) FROM worldview_sets').fetchone()[0]
                w.channel_gain=2;w.channel_bias=3
                r.close();r=DiagnosingCycle(ap)
                result=finish(r,w)
                self.assertEqual(result['life']['status'],'DONE')
                self.assertEqual(result['pool'],before_pool)
                self.assertEqual(r.db.execute('SELECT COUNT(*) FROM worldview_sets').fetchone()[0],before_models)
                self.assertEqual(result['life']['repairs'],0)
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
                body=json.loads(r.db.execute('SELECT body FROM intents WHERE status="done"').fetchone()[0])
                self.assertEqual(body['permission']['calibration_epoch'],2)
                self.assertEqual(len(body['permission']['calibration_operations']),3)
                self.assertLess(result['life']['remaining'],80)
            finally:r.close();w.close()

    def test_process_change_still_researches_with_healthy_sensor(self):
        w=ReferenceWorld(':memory:',lambda u,v:1+2*u,1,initial=300,error_bound=0)
        r=DiagnosingCycle(':memory:');original=w.apply_once;changed=False
        def surprise(op,u,target):
            nonlocal changed
            if not changed:w.law=lambda u,v:2+2*u;changed=True
            return original(op,u,target)
        w.apply_once=surprise
        try:
            r.begin(w,budget=100);result=finish(r,w)
            self.assertEqual(result['life']['status'],'DONE')
            self.assertEqual(result['life']['repairs'],1)
            self.assertEqual(result['calibration']['bias'],0)
        finally:r.close();w.close()

    def test_uncertainty_and_budget_do_not_authorize_action(self):
        for config,budget,reason in [({},3,'DIAGNOSTIC_BUDGET_EXHAUSTED'),
              ({'reference_trusted':False},40,'UNTRUSTED_REFERENCE'),
              ({'error_bound':1},40,'UNCERTAIN_CALIBRATION_UNRESOLVED')]:
            w=ReferenceWorld(':memory:',lambda u,v:1+2*u,1,initial=100,**{'error_bound':0,**config})
            r=DiagnosingCycle(':memory:')
            try:
                s=r.begin(w,budget=budget)
                self.assertEqual(s['reason'],reason)
                self.assertIsNone(r.permit(1))
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
            finally:r.close();w.close()

    def test_non_affine_channel_fails_fresh_validation(self):
        w=ReferenceWorld(':memory:',lambda u,v:1+2*u,1,initial=100,error_bound=0)
        w.channel=lambda x:x*x
        r=DiagnosingCycle(':memory:')
        try:
            s=r.begin(w,budget=40)
            self.assertEqual(s['reason'],'SENSOR_OUTSIDE_CONTRACT')
            self.assertEqual(s['budget'],37)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()


if __name__=='__main__':unittest.main()
