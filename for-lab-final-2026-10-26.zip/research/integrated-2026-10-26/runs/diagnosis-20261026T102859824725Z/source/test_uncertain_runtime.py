import tempfile
import unittest
from pathlib import Path
from uncertain_runtime import UncertainRuntime,UncertainWorld


class UncertainTests(unittest.TestCase):
    def test_underestimate_uses_upper_bound_and_selects_alternative(self):
        w=UncertainWorld(':memory:',lambda u,v:3*u,0,initial=11,sensor_bias=-1)
        r=UncertainRuntime(':memory:')
        try:
            r.start_uncertain(w);s=r.run(w)
            self.assertEqual(s['phase'],'DONE');self.assertEqual(s['selected'],1)
            self.assertEqual(w.balance(),6)
        finally:r.close();w.close()

    def test_stale_observation_is_remeasured_before_act(self):
        w=UncertainWorld(':memory:',lambda u,v:3*u,0,initial=20);r=UncertainRuntime(':memory:')
        try:
            r.start_uncertain(w);r.step(w);w.advance(3);w.law=lambda u,v:4*u
            s=r.run(w)
            self.assertEqual(s['phase'],'DONE');self.assertEqual(len(s['evidence']),2)
            self.assertEqual(s['evidence'][-1]['tick'],3);self.assertEqual(w.balance(),10)
        finally:r.close();w.close()

    def test_noncentral_actual_value_inside_interval_is_not_failure(self):
        w=UncertainWorld(':memory:',lambda u,v:3*u,0,initial=20,sensor_bias=1);r=UncertainRuntime(':memory:')
        try:
            r.start_uncertain(w);self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(w.balance(),13)
        finally:r.close();w.close()

    def test_stale_recovered_receipt_keeps_original_timestamp(self):
        class FaultWorld(UncertainWorld):
            def measure(self,probe):
                super().measure(probe)
                raise RuntimeError('crash after measurement commit')
        with tempfile.TemporaryDirectory() as tmp:
            wp=Path(tmp)/'w';ap=Path(tmp)/'a'
            w=FaultWorld(wp,lambda u,v:3*u,0,initial=20);r=UncertainRuntime(ap)
            r.start_uncertain(w)
            with self.assertRaises(RuntimeError):r.step(w)
            r.close();w.close()
            w=UncertainWorld(wp,lambda u,v:3*u,0,initial=20);w.advance(3);r=UncertainRuntime(ap)
            try:
                s=r.run(w);self.assertEqual(s['phase'],'DONE')
                self.assertEqual([e['tick'] for e in s['evidence']],[0,3])
                self.assertEqual(w.balance(),12)
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM measurements').fetchone()[0],2)
            finally:r.close();w.close()

    def test_interval_branch_does_not_claim_exact_model_learning(self):
        w=UncertainWorld(':memory:',lambda u,v:3*u,0);r=UncertainRuntime(':memory:')
        try:
            with self.assertRaises(ValueError):r.start_uncertain(w,deliverable='model_and_action')
        finally:r.close();w.close()

    def test_outside_error_contract_is_detected_after_action_not_predicted(self):
        w=UncertainWorld(':memory:',lambda u,v:3*u,0,initial=30);r=UncertainRuntime(':memory:')
        try:
            r.start_uncertain(w);r.step(w);w.law=lambda u,v:5*u
            s=r.step(w)
            self.assertEqual(s['phase'],'HALT')
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
            self.assertEqual(w.balance(),19)
        finally:r.close();w.close()
