import tempfile
import unittest
from pathlib import Path
from agenda_runtime import AgendaRuntime
from durable_runtime import ReceiptWorkshop

class AgendaTests(unittest.TestCase):
    def test_queue_survives_restart_without_duplicate_tasks(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'agent.sqlite';world=Path(tmp)/'world.sqlite'
            r=AgendaRuntime(path);w=ReceiptWorkshop(world,gain=1)
            r.enqueue('one',1);r.enqueue('two',2);r.enqueue('impossible',5)
            for _ in range(4):r.tick(w)
            r.close();w.close()
            r=AgendaRuntime(path);w=ReceiptWorkshop(world,gain=1)
            try:
                r.recover_agenda()
                for _ in range(40):
                    if r.tick(w).get('agenda')=='EMPTY':break
                self.assertEqual(list(r.db.execute('SELECT status FROM agenda ORDER BY position')),[('DONE',),('DONE',),('HALT',)])
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],2)
                r.enqueue('one',1)
                self.assertEqual(r.db.execute('SELECT COUNT(*) FROM agenda').fetchone()[0],3)
                # Early sufficient task evidence is not a complete model revision.
                self.assertEqual(r.db.execute('SELECT COUNT(*) FROM runtime_revisions').fetchone()[0],0)
            finally:r.close();w.close()

    def test_interrupted_start_recovers_on_tick(self):
        from unittest.mock import patch
        from incubator_runtime import Runtime
        for partial in (False,True):
            with self.subTest(partial=partial),tempfile.TemporaryDirectory() as tmp:
                path=Path(tmp)/'agent.sqlite';wp=Path(tmp)/'world.sqlite'
                r=AgendaRuntime(path);w=ReceiptWorkshop(wp,gain=2)
                r.enqueue('task',2)
                def interrupt(**request):
                    if partial:Runtime.start(r,**request)
                    raise RuntimeError('injected start interruption')
                with patch.object(r,'start_decision',side_effect=interrupt):
                    with self.assertRaises(RuntimeError):r.tick(w)
                r.close();r=AgendaRuntime(path)
                try:
                    for _ in range(20):
                        if r.tick(w).get('agenda')=='EMPTY':break
                    self.assertEqual(r.state()['task_id'],1)
                    self.assertEqual(r.state()['phase'],'DONE')
                    self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
                finally:r.close();w.close()

    def test_complete_evidence_revision_and_partial_nonrevision(self):
        r=AgendaRuntime(':memory:')
        try:
            r.start_decision(2)
            s=r.state();s['evidence']=[dict(probe='CAL',value=-1),dict(probe='U1',value=1)]
            with r.db:r.commit_complete_evidence(s)
            self.assertEqual(r.beliefs()['process'],(1,0))
            s['evidence'].append(dict(probe='U2',value=3))
            with r.db:r.commit_complete_evidence(s)
            self.assertEqual(r.beliefs(),{'process':(2,1),'sensor':(-1,1)})
            self.assertFalse(r.state()['certified'])
            with r.db:r.commit_complete_evidence(s)
            self.assertEqual(r.beliefs()['process'],(2,1))
        finally:r.close()

    def test_revision_invalidates_issued_permission(self):
        r=AgendaRuntime(':memory:')
        try:
            r.start_decision(2)
            s=r.state();s.update(phase='ACT',evidence=[dict(probe='CAL',value=-1),dict(probe='U1',value=1)])
            with r.db:r.save(s)
            permission=r.permit(1)
            self.assertTrue(r.validate_permission(permission))
            s['evidence'].append(dict(probe='U2',value=3))
            with r.db:r.commit_complete_evidence(s);r.save(s)
            self.assertFalse(r.validate_permission(permission))
            self.assertTrue(r.validate_permission(r.permit(1)))
        finally:r.close()
