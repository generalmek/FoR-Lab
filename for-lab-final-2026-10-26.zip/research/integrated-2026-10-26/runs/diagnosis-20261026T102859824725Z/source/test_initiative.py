import tempfile
import unittest
from pathlib import Path
from initiative import Initiative


class InitiativeTests(unittest.TestCase):
    def test_outcomes_change_choice_and_survive_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'choice.db'
            r = Initiative(path)
            offers = [dict(id=str(i), context=i%2, reward=10, order=i) for i in range(4)]
            first = r.choose(offers, 100)
            r.close(); r = Initiative(path)
            self.assertEqual(r.choose(offers, 100), first)
            r.finish(first['id'], 40, False, 'failed')
            self.assertEqual(r.choose(offers, 60)['context'], 1)
            r.close()

    def test_reserve_and_duplicate_outcome(self):
        r = Initiative(':memory:')
        offers = [dict(id='x', context=0, reward=10, order=0)]
        self.assertIsNone(r.choose(offers, 6))
        r.choose(offers, 50)
        r.finish('x', 3, True, 'DONE')
        r.finish('x', 3, True, 'DONE')
        with self.assertRaises(ValueError):r.finish('x', 4, True, 'DONE')
        self.assertIsNone(r.choose(offers, 47))
        r.close()
