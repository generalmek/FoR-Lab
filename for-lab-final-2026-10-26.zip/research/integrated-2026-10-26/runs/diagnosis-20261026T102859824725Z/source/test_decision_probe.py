import unittest
from incubator import Knowledge,Agent,Runner,World,Observation,grammar
from decision_probe import decision_probe

class DecisionProbeTests(unittest.TestCase):
    def test_probe_selection_depends_on_goal(self):
        a=decision_probe(grammar(),Observation('g','r',1,((1,1),(1,2),(2,1),(2,2)),1))
        b=decision_probe(grammar(),Observation('g','r',8,((1,1),(1,2),(2,1),(2,2)),1))
        self.assertNotEqual(a,b)

    def test_previous_failure_resolved_for_both_agents(self):
        for name in ('FoR','B2'):
            db=Knowledge(':memory:')
            try:
                result=Runner(Agent(name,db,decision_probe),World('interaction',1,'g',1,'r',1)).run()
                self.assertTrue(result['success'])
                self.assertEqual(result['tests'],1)
                self.assertEqual(result['harm'],0)
            finally:
                db.close()
