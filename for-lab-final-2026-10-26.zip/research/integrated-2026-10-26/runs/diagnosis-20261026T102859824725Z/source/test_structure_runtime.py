import json
import tempfile
import unittest
from pathlib import Path
from durable_runtime import ReceiptWorkshop
from structure_runtime import StructureRuntime,construct,evaluate

class PolynomialWorkshop(ReceiptWorkshop):
    def __init__(self,*args,a=3,q=2,cubic=0,**kwargs):
        super().__init__(*args,**kwargs);self.a,self.q,self.cubic=a,q,cubic
    def physical(self,u):return self.a*u+self.q*u*u+self.cubic*u*u*u

class StructureTests(unittest.TestCase):
    def test_construct_then_unused_validation_and_restart_transfer(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'agent.sqlite';wp=Path(tmp)/'world.sqlite'
            r=StructureRuntime(p);w=PolynomialWorkshop(wp,a=3,q=0,bias=-2)
            r.start_decision(6);self.assertEqual(r.run(w)['phase'],'DONE')
            w.q=2;r.start_decision(14)
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(r.remembered(),('-2','3','2'))
            record=json.loads(r.db.execute('SELECT body FROM expressions ORDER BY id DESC LIMIT 1').fetchone()[0])
            self.assertEqual(record['fitting_probes'],['CAL','U1','U2'])
            self.assertEqual(record['validation_probe'],'U3')
            r.close();r=StructureRuntime(p)
            try:
                r.start_decision(5,budget=3)
                self.assertEqual(r.run(w)['phase'],'DONE')
                self.assertEqual(len(r.state()['evidence']),2)
            finally:r.close();w.close()

    def test_cubic_fails_unseen_check_without_refitting(self):
        r=StructureRuntime(':memory:');w=PolynomialWorkshop(':memory:',cubic=1)
        try:
            r.start_decision(w.physical(2));self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertIsNone(r.remembered())
            self.assertEqual([e['probe'] for e in r.state()['evidence']],['CAL','U1','U2','U3'])
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()

    def test_disabled_expansion_and_budget_stop(self):
        for expand,budget in ((False,6),(True,4)):
            r=StructureRuntime(':memory:',expand=expand);w=PolynomialWorkshop(':memory:')
            try:
                r.start_decision(14,budget=budget)
                self.assertEqual(r.run(w)['phase'],'HALT')
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
            finally:r.close();w.close()

    def test_pending_effect_reconciles_polynomial_prediction(self):
        r=StructureRuntime(':memory:');w=PolynomialWorkshop(':memory:',bias=4)
        try:
            r.start_decision(14)
            for _ in range(4):r.step(w)
            with self.assertRaises(RuntimeError):r.step(w,fail_at='after_effect')
            self.assertEqual(r.step(w)['phase'],'DONE')
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
        finally:r.close();w.close()

    def test_exact_fit_can_be_wrong_on_new_point(self):
        model=construct([(0,0),(1,1),(2,8)],2)
        self.assertEqual(evaluate(model,2),8)
        self.assertNotEqual(evaluate(model,3),27)
