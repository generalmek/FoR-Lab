import tempfile
import unittest
from pathlib import Path
from full_cycle import FullCycle,ExperimentalDesignControl
from unittest.mock import patch
from uncertain_runtime import UncertainWorld


class FullCycleTests(unittest.TestCase):
    def test_separate_planner_does_not_call_for_planning_methods(self):
        w=UncertainWorld(':memory:',lambda u,v:1+2*u+u*v,1,initial=140)
        r=ExperimentalDesignControl(':memory:')
        try:
            r.start_cycle(w)
            with patch.object(FullCycle,'choose_plan',side_effect=AssertionError('FoR planner called')),patch.object(FullCycle,'choose_probe',side_effect=AssertionError('FoR selector called')):
                self.assertEqual(r.run(w)['phase'],'DONE')
                self.assertTrue(r.state()['worldview_saved'])
        finally:r.close();w.close()

    def test_whole_cycle_persistent_interval_learning_and_revision(self):
        with tempfile.TemporaryDirectory() as tmp:
            states=[]
            for law,context in (((1,2,1),0),((1,2,1),2),((2,5,3),2),((2,5,3),1)):
                b,a,q=law
                w=UncertainWorld(Path(tmp)/'world',lambda u,v:b+a*u+q*u*v,context,initial=140,sensor_bias=-1)
                r=FullCycle(Path(tmp)/'agent')
                try:
                    r.start_cycle(w);s=r.run(w);states.append(s)
                    self.assertEqual(s['phase'],'DONE')
                    self.assertIn(law,[tuple(m) for m in r.candidates(s)])
                    self.assertGreaterEqual(w.balance(),5)
                finally:r.close();w.close()
            self.assertTrue(states[0]['worldview_saved'])
            self.assertTrue(states[1]['transferred']);self.assertEqual(len(states[1]['evidence']),1)
            self.assertTrue(states[2]['revision']);self.assertTrue(states[2]['worldview_saved'])
            self.assertTrue(states[3]['transferred'])

    def test_compass_changes_action_before_receiver_interlock(self):
        for mode in ('full','no_compass'):
            w=UncertainWorld(':memory:',lambda u,v:1+3*u,0,initial=15,error_bound=0)
            r=FullCycle(':memory:')
            try:
                r.start_cycle(w,mode);s=r.run(w)
                if mode=='full':
                    self.assertEqual(s['phase'],'DONE');self.assertEqual(s['selected'],1)
                    self.assertEqual(w.balance(),5)
                else:
                    self.assertEqual(s['reason'],'RESOURCE_INTERLOCK')
                    self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
            finally:r.close();w.close()

    def test_unknown_grammar_does_not_act_or_save_model(self):
        w=UncertainWorld(':memory:',lambda u,v:100+u**3,0,initial=140);r=FullCycle(':memory:')
        try:
            r.start_cycle(w);s=r.run(w);self.assertEqual(s['phase'],'HALT')
            self.assertEqual(r.db.execute('SELECT COUNT(*) FROM worldview_sets').fetchone()[0],0)
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()

    def test_budget_stop_does_not_certify_partial_hypotheses(self):
        w=UncertainWorld(':memory:',lambda u,v:1+2*u,0,initial=140);r=FullCycle(':memory:')
        try:
            r.start_cycle(w,budget=3);s=r.run(w)
            self.assertEqual(s['phase'],'HALT');self.assertFalse(s['verified'])
            self.assertEqual(r.db.execute('SELECT COUNT(*) FROM worldview_sets').fetchone()[0],0)
        finally:r.close();w.close()
