import json
import tempfile
import unittest
from pathlib import Path
from learning_runtime import LearningRuntime
from durable_runtime import ReceiptWorkshop

class LearningTests(unittest.TestCase):
    def test_novel_parameter_and_new_goal_after_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'agent.sqlite';wp=Path(tmp)/'world.sqlite'
            r=LearningRuntime(p);w=ReceiptWorkshop(wp,gain=7,bias=4)
            r.start_decision(7);self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(r.remembered(),[7,4]);r.close()
            r=LearningRuntime(p)
            try:
                r.start_decision(14,budget=3)
                self.assertEqual(r.run(w)['phase'],'DONE')
                self.assertEqual(len(r.state()['evidence']),2)
                self.assertEqual(r.state()['budget'],0)
                self.assertEqual(r.beliefs()['process'],(7,1))
            finally:r.close();w.close()

    def test_control_same_budget_cannot_complete_full_validation(self):
        r=LearningRuntime(':memory:',use_memory=False);w=ReceiptWorkshop(':memory:',gain=7,bias=4)
        try:
            r.start_decision(7);r.run(w)
            r.start_decision(14,budget=3)
            self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],1)
        finally:r.close();w.close()

    def test_hidden_gain_change_revises_without_notification(self):
        r=LearningRuntime(':memory:');w=ReceiptWorkshop(':memory:',gain=7,bias=4)
        try:
            r.start_decision(7);r.run(w)
            w.gain=11
            r.start_decision(14);self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertEqual(r.remembered(),[11,4])
            r.start_decision(22,budget=3);self.assertEqual(r.run(w)['phase'],'DONE')
            effects=[json.loads(x[0]) for x in w.db.execute('SELECT result FROM receipts')]
            self.assertEqual(sum(e['harm'] for e in effects),0)
        finally:r.close();w.close()

    def test_false_calibration_is_preserved_negative_boundary(self):
        class BadReference(ReceiptWorkshop):
            def measure(self,p):
                return super().measure(p)+1 if p=='CAL' else super().measure(p)
        r=LearningRuntime(':memory:');w=BadReference(':memory:',gain=7,bias=4)
        try:
            r.start_decision(7)
            self.assertEqual(r.run(w)['phase'],'HALT')
            self.assertIsNone(r.remembered())
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()

    def test_queue_uses_learning_without_manual_module_calls(self):
        r=LearningRuntime(':memory:');w=ReceiptWorkshop(':memory:',gain=7,bias=4)
        try:
            r.enqueue('learn',7);r.enqueue('transfer',14,budget=3)
            for _ in range(25):
                if r.tick(w).get('agenda')=='EMPTY':break
            self.assertEqual(list(r.db.execute('SELECT status FROM agenda ORDER BY position')),[('DONE',),('DONE',)])
        finally:r.close();w.close()

    def test_strong_control_can_succeed_without_stored_model(self):
        r=LearningRuntime(':memory:',use_memory=False,direct=True);w=ReceiptWorkshop(':memory:',gain=7,bias=4)
        try:
            r.start_decision(7,budget=3)
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(len(r.state()['evidence']),2)
        finally:r.close();w.close()

    def test_change_during_execution_still_defeats_prior_validation(self):
        class DriftOnAction(ReceiptWorkshop):
            drift=False
            def apply_once(self,*args):
                if self.drift:self.gain=11
                return super().apply_once(*args)
        r=LearningRuntime(':memory:');w=DriftOnAction(':memory:',gain=7,bias=4)
        try:
            r.start_decision(7);r.run(w)
            w.drift=True;r.start_decision(14,budget=3)
            self.assertEqual(r.run(w)['phase'],'HALT')
            receipt=json.loads(w.db.execute('SELECT result FROM receipts ORDER BY rowid DESC LIMIT 1').fetchone()[0])
            self.assertEqual(receipt['harm'],1) # detected after effect, not prevented
        finally:r.close();w.close()
