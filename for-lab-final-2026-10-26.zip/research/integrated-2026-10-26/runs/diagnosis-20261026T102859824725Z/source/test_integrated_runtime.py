import tempfile
import unittest
from pathlib import Path
from integrated_runtime import IntegratedRuntime, campaign
from native_incubator import NativeWorld


class IntegratedTests(unittest.TestCase):
    def test_combined_transfer_revision_and_ablations(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = campaign(Path(tmp)/'run')
        full = [r for r in rows if r['policy']=='full']
        self.assertEqual([r['action'] for r in full], [1,2,1])
        self.assertTrue(all(r['phase']=='DONE' and not r['reserve_breach'] for r in full))
        self.assertTrue(full[2]['revised'])
        self.assertLess(full[1]['probes'], full[0]['probes'])
        self.assertTrue(any(r['reserve_breach'] for r in rows if r['policy']=='no_compass'))
        self.assertTrue(all(r['phase']=='HALT' for r in rows if r['policy']=='no_core'))
        self.assertTrue(any(r['phase']=='HALT' for r in rows if r['policy']=='no_alternatives'))

    def test_no_safe_option_and_unknown_model_do_not_act(self):
        for law in (lambda u,v:7+u, lambda u,v:1+u**3+v):
            r=IntegratedRuntime(':memory:'); w=NativeWorld(':memory:',law,1)
            try:
                r.start_integrated(1,10,5)
                self.assertEqual(r.run(w)['phase'],'HALT')
                self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
            finally:
                r.close(); w.close()
