import unittest
from budget_revision_audit import BudgetAwareCycle
from uncertain_runtime import UncertainWorld


class BudgetRevisionTests(unittest.TestCase):
    def test_single_hypothesis_still_requires_new_validation(self):
        w=UncertainWorld(':memory:',lambda u,v:1+2*u,0,initial=80,error_bound=0)
        r=BudgetAwareCycle(':memory:')
        try:
            r.start_cycle(w);s=r.state()
            s.update(pool=[(1,2,0)],evidence=[dict(probe='T0',value=1,tick=0,radius=0)],sensor_bound=0)
            with r.db:r.save(s)
            choice,_=r.choose_plan(s,r.candidates(s))
            self.assertEqual(choice[0],'PROBE');self.assertTrue(choice[1].startswith('V'))
            self.assertFalse(s['verified'])
            self.assertEqual(w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0],0)
        finally:r.close();w.close()
