import unittest
from stress_protocol import external_metrics,FixedResearch,RandomResearch
from uncertain_runtime import UncertainWorld


class StressTests(unittest.TestCase):
    def test_external_metric_has_no_model_or_revision_dependency(self):
        m=external_metrics(20,13,[2],lambda u,v:3*u,0)
        self.assertEqual(m['reward'],10);self.assertEqual(m['opportunity_gap'],0)
        self.assertEqual(m['resource_spent'],7)
        self.assertEqual(external_metrics(20,19,[],lambda u,v:3*u,0)['opportunity_gap'],10)

    def test_replacement_policies_can_learn_and_act(self):
        for cls in (FixedResearch,RandomResearch):
            w=UncertainWorld(':memory:',lambda u,v:1+2*u+u*v,1,initial=140)
            r=cls(':memory:')
            try:
                r.start_cycle(w);s=r.run(w)
                self.assertEqual(s['phase'],'DONE')
                self.assertGreater(len(s['evidence']),0)
            finally:r.close();w.close()
