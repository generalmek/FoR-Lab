import tempfile
import unittest
from pathlib import Path
from epoch_recovery import EpochStore,episode

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'memory.sqlite'
        episode(self.path,'FoR',(1,2),1)
        episode(self.path,'FoR',(2,2),2)

    def test_no_boundary_no_reset(self):
        r=episode(self.path,'FoR',(2,2))
        self.assertIsNone(r['success'])
        self.assertEqual(r['epoch'],0)
        store=EpochStore(self.path)
        try:
            with self.assertRaises(ValueError):
                store.recover('workshop',{'event_id':'guess','kind':'component_replaced','observed':False})
            self.assertEqual(store.current('workshop')[0],0)
        finally: store.close()

    def test_recovery_keeps_old_evidence_and_relearns(self):
        store=EpochStore(self.path)
        old=store.current('workshop')[1]
        before=store.db.execute('SELECT * FROM evidence WHERE grp=?',(old,)).fetchall()
        store.close()
        boundary={'event_id':'replacement-1','kind':'component_replaced','observed':True}
        r=episode(self.path,'FoR',(2,2),boundary=boundary)
        self.assertTrue(r['success'])
        self.assertEqual((r['epoch'],r['measurements']),(1,1))
        later=episode(self.path,'FoR',(2,2),target=4)
        self.assertTrue(later['success'])
        self.assertEqual(later['measurements'],0)
        store=EpochStore(self.path)
        try:
            self.assertEqual(before,store.db.execute('SELECT * FROM evidence WHERE grp=?',(old,)).fetchall())
            self.assertEqual(store.state(old)[1],())
        finally: store.close()

    def test_new_epoch_does_not_make_unknown_model_known(self):
        b={'event_id':'replacement-1','kind':'component_replaced','observed':True}
        r=episode(self.path,'FoR',(7,2),boundary=b)
        self.assertIsNone(r['success'])
        self.assertEqual(r['models'],())
        store=EpochStore(self.path)
        try:
            with self.assertRaises(ValueError): store.recover('workshop',b)
            self.assertEqual(store.current('workshop')[0],1)
        finally: store.close()

    def test_zero_budget_cannot_turn_recovery_into_success(self):
        b={'event_id':'replacement-1','kind':'component_replaced','observed':True}
        r=episode(self.path,'FoR',(2,2),boundary=b,budget=0)
        self.assertIsNone(r['success'])
        self.assertEqual(r['measurements'],0)
