import unittest
import tempfile
from pathlib import Path
from continuous_campaign import ResourceWorld, DirectControl, RejectionCheckedRuntime, run_campaign
from integrated_runtime import IntegratedRuntime


class ContinuousTests(unittest.TestCase):
    def test_old_negative_forecast_is_tested_and_revised(self):
        r=RejectionCheckedRuntime(':memory:');w=ResourceWorld(':memory:',lambda u,v:9*u,0,80)
        try:
            r.start_integrated(0,80,5);self.assertEqual(r.run(w)['phase'],'DONE')
            w.law=lambda u,v:2*u
            r.start_integrated(0,10,5)
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertTrue(r.state()['native_gap'])
            self.assertEqual(r.state()['selected'],2)
        finally:r.close();w.close()

    def test_resource_debit_survives_restart_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'world.sqlite'
            w=ResourceWorld(p,lambda u,v:3*u,0,20)
            w.apply_once('op',2,6);self.assertEqual(w.balance(),14);w.close()
            w=ResourceWorld(p,lambda u,v:3*u,0,999)
            try:
                w.apply_once('op',2,6);self.assertEqual(w.balance(),14)
                with self.assertRaises(ValueError):w.apply_once('op',1,3)
            finally:w.close()

    def test_campaign_runs_both_policies_with_same_cases(self):
        with tempfile.TemporaryDirectory() as tmp:
            result=run_campaign(Path(tmp)/'run',seeds=2,episodes=4)
        self.assertEqual(result['integrated']['episodes'],8)
        self.assertEqual(result['B2_direct']['episodes'],8)
        self.assertEqual(result['integrated']['breaches'],0)
        self.assertEqual(result['B2_direct']['breaches'],0)

    def test_direct_control_selects_safe_lower_reward_alternative(self):
        r=DirectControl(':memory:');w=ResourceWorld(':memory:',lambda u,v:4*u,0,10)
        try:
            r.start_integrated(0,10,5)
            self.assertEqual(r.run(w)['phase'],'DONE')
            self.assertEqual(r.state()['selected'],1)
            self.assertEqual(w.balance(),6)
        finally:r.close();w.close()
