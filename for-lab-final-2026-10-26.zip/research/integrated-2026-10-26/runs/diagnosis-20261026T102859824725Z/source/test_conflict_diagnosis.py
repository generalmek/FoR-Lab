import unittest
from conflict_diagnosis import diagnose,predicted,Diagnosis

class DiagnosisTests(unittest.TestCase):
    def test_process_sensor_and_joint_changes(self):
        for model,status in [((2,0),'PROCESS_CHANGE'),((1,1),'SENSOR_BIAS'),((2,1),'JOINT_CHANGE')]:
            r=diagnose(lambda p:predicted(model,p))
            self.assertEqual(r['status'],status)
            self.assertEqual(r['candidates'],(model,))

    def test_budget_zero_preserves_ambiguity(self):
        r=diagnose(lambda p:predicted((2,0),p),budget=0)
        self.assertEqual(r['status'],'AMBIGUOUS')
        self.assertEqual(r['extra_measurements'],0)

    def test_restricted_measurements_cannot_disambiguate(self):
        r=diagnose(lambda p:predicted((2,0),p),probes=('U1',))
        self.assertEqual(r['status'],'AMBIGUOUS')

    def test_unknown_law_is_not_forced_into_known_explanation(self):
        r=diagnose(lambda p:{'CAL':0,'U1':2,'U2':7}[p])
        self.assertEqual(r['status'],'UNEXPLAINED_BY_CLASS')

    def test_conflicting_repeated_measurement_retains_evidence(self):
        d=Diagnosis()
        d.observe('U1',2)
        d.observe('U1',3)
        self.assertEqual(d.status(),'UNEXPLAINED_BY_CLASS')
        self.assertEqual(len(d.evidence),2)

    def test_pending_probe_prevents_double_spending(self):
        d=Diagnosis(1)
        d.observe('U1',2)
        d.next_probe()
        with self.assertRaises(RuntimeError): d.next_probe()
        self.assertEqual(d.budget,0)
