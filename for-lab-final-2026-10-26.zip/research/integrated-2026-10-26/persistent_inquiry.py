"""Stage 3: addressed inquiry + SQLite evidence/history and dependent predictions."""
import argparse
import json
import sqlite3
from dataclasses import asdict
from basis_inquiry import Agent,Task,MODELS,predict

class Store:
    def __init__(self,path):
        self.db=sqlite3.connect(str(path))
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS states(grp TEXT PRIMARY KEY, version INTEGER, models TEXT);
        CREATE TABLE IF NOT EXISTS versions(grp TEXT,version INTEGER,models TEXT,PRIMARY KEY(grp,version));
        CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY,grp TEXT,version INTEGER,event TEXT);
        CREATE TABLE IF NOT EXISTS predictions(id INTEGER PRIMARY KEY,grp TEXT,version INTEGER,task TEXT,u INTEGER,deps TEXT,valid INTEGER);
        CREATE TABLE IF NOT EXISTS revisions(grp TEXT,version INTEGER,affected TEXT);
        ''')
        self.db.commit()

    def state(self,group):
        row=self.db.execute('SELECT version,models FROM states WHERE grp=?',(group,)).fetchone()
        return (row[0],tuple(map(tuple,json.loads(row[1])))) if row else (0,MODELS)

    def observe(self,group,event):
        version,old=self.state(group)
        if event['kind']=='TEST':
            axis=event['axis']
            if axis not in (0,1): raise ValueError('invalid evidence axis')
            new=tuple(m for m in old if m[axis]==event['value'])
        elif event['kind']=='PROCESS':
            task=Task(**event['task'])
            new=tuple(m for m in old if predict(m,task,event['u'])==event['value'])
        else:
            raise ValueError('invalid evidence kind')
        affected=[]
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO versions VALUES(?,?,?)',(group,version,json.dumps(old)))
            self.db.execute('INSERT INTO versions VALUES(?,?,?)',(group,version+1,json.dumps(new)))
            self.db.execute('INSERT INTO evidence(grp,version,event) VALUES(?,?,?)',(group,version+1,json.dumps(event)))
            self.db.execute('INSERT INTO states VALUES(?,?,?) ON CONFLICT(grp) DO UPDATE SET version=excluded.version,models=excluded.models',
                            (group,version+1,json.dumps(new)))
            for pid,deps in self.db.execute('SELECT id,deps FROM predictions WHERE grp=? AND valid=1',(group,)).fetchall():
                axes=json.loads(deps)
                before={tuple(m[i] for i in axes) for m in old}
                after={tuple(m[i] for i in axes) for m in new}
                if before!=after:
                    affected.append(pid)
                    self.db.execute('UPDATE predictions SET valid=0 WHERE id=?',(pid,))
            self.db.execute('INSERT INTO revisions VALUES(?,?,?)',(group,version+1,json.dumps(affected)))
        return new,version+1,affected

    def save_prediction(self,group,task,u):
        version,_=self.state(group)
        with self.db:
            cursor=self.db.execute('INSERT INTO predictions(grp,version,task,u,deps,valid) VALUES(?,?,?,?,?,1)',
                (group,version,json.dumps(asdict(task)),u,json.dumps([i for i,w in enumerate(task.weights) if w])))
        return cursor.lastrowid

    def close(self): self.db.close()

class PersistentAgent(Agent):
    def __init__(self,mode,task,store,group,budget=1):
        super().__init__(mode,task,budget)
        self.store,self.group=store,group
        version,self.models=store.state(group)
        self.trace.append({'loaded_version':version,'models':self.models})

    def receive(self,axis,value):
        if self.pending!=axis: raise ValueError('unrequested evidence')
        self.models,version,affected=self.store.observe(self.group,{'kind':'TEST','axis':axis,'value':value})
        self.pending=None
        self.trace.append({'evidence':{'axis':axis,'value':value},'revision':version,'affected_predictions':affected})

    def record_prediction(self,u):
        pid=self.store.save_prediction(self.group,self.task,u)
        self.trace.append({'prediction_id':pid,'u':u})

    def process_outcome(self,u,value):
        self.models,version,affected=self.store.observe(self.group,{'kind':'PROCESS','task':asdict(self.task),'u':u,'value':value})
        self.trace.append({'process_evidence':value,'revision':version,'affected_predictions':affected})

def run(path,mode,task,truth,group='stable-workshop',budget=1):
    store=Store(path)
    try:
        agent=PersistentAgent(mode,task,store,group,budget)
        measurements=0
        while True:
            kind,arg=agent.decide()
            if kind=='TEST':
                measurements+=1
                agent.receive(arg,truth[arg])
                continue
            actual=None
            if kind=='PROCESS':
                agent.record_prediction(arg)
                actual=predict(truth,task,arg)
                agent.process_outcome(arg,actual)
            success=(actual==task.target) if actual is not None else None
            version,models=store.state(group)
            return {'mode':mode,'success':success,'harm':int(success is False),'measurements':measurements,
                    'version':version,'models':models,'trace':agent.trace}
    finally:
        store.close()

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--db',required=True)
    p.add_argument('--target',type=int,required=True)
    p.add_argument('--truth',nargs=2,type=int,required=True)
    p.add_argument('--weights',nargs=2,type=int,default=(1,0))
    p.add_argument('--mode',choices=('FoR','B2'),default='FoR')
    args=p.parse_args()
    print(json.dumps(run(args.db,args.mode,Task(tuple(args.weights),args.target),tuple(args.truth)),indent=2))
