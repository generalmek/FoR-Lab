import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime,timezone

root=Path(__file__).resolve().parent
folder=root/'runs'/datetime.now(timezone.utc).strftime('persistence-%Y%m%dT%H%M%S%fZ')
folder.mkdir(parents=True)
rows=[]
for mode in ('FoR','B2'):
    for label,db,target,truth in [('learn','memory',1,(1,2)),('restart-new-goal','memory',2,(1,2)),
                                ('fresh-control','fresh',2,(1,2)),('hidden-drift','memory',2,(2,2)),
                                ('restart-after-conflict','memory',2,(2,2))]:
        cmd=[sys.executable,str(root/'persistent_inquiry.py'),'--db',str(folder/f'{mode}-{db}.sqlite'),
             '--target',str(target),'--truth',str(truth[0]),str(truth[1]),'--mode',mode]
        result=json.loads(subprocess.run(cmd,capture_output=True,text=True,check=True).stdout)
        rows.append({'stage':label,'target':target,**result})
(folder/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
lines=['FoR INCUBATOR | actual subprocess results','Each row runs in a NEW Python process.','']
for r in rows:
    lines.append(f"{r['mode']:3} | {r['stage']:23} | success={str(r['success']):5} | probes={r['measurements']} | harm={r['harm']} | v{r['version']}")
lines+=['','Saved knowledge works on a NEW goal after restart.',
        'Hidden drift: first action fails; later process abstains.',
        'FoR and B2 tie. Finite predefined models; not full Reason.']
(folder/'terminal.txt').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
print('ARTIFACT_DIR='+str(folder))
