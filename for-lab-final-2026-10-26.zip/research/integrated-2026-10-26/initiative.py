"""Persistent choice among public opportunities; supplied utility, not intrinsic goals."""
import json
import sqlite3


class Initiative:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS choices(id TEXT PRIMARY KEY, body TEXT, outcome TEXT)')
        self.db.commit()

    def choose(self, offers, balance, reserve=5, policy='learned'):
        if policy not in ('learned', 'fifo', 'reward'):
            raise ValueError('policy')
        rows = self.db.execute('SELECT id,body,outcome FROM choices ORDER BY rowid').fetchall()
        # An unfinished claim resumes exactly, rather than consuming another offer.
        for key, body, outcome in rows:
            if outcome is None:
                return json.loads(body)
        done = {r[0] for r in rows}
        options = [o for o in offers if o['id'] not in done]
        if balance <= reserve + 1 or not options:
            return None
        history = {}
        for _, body, outcome in rows:
            offer = json.loads(body)
            history.setdefault(offer['context'], []).append(json.loads(outcome))
        scored = []
        for o in options:
            hs = history.get(o['context'], [])[-3:]
            # Transparent empirical estimate, with no hidden law/scenario access.
            cost = sum(h['cost'] for h in hs) / len(hs) if hs else 8.0
            success = (1 + sum(h['acted'] for h in hs)) / (2 + len(hs))
            novelty = 1 / (1 + len(hs))
            utility = o['reward'] * success / max(1, cost) + 0.25 * novelty
            score = -o['order'] if policy == 'fifo' else o['reward'] if policy == 'reward' else utility
            scored.append((score, -o['order'], o, cost, success))
        _, _, chosen, cost, success = max(scored, key=lambda x: x[:2])
        chosen = dict(chosen, estimated_cost=cost, estimated_success=success, policy=policy)
        with self.db:
            self.db.execute('INSERT INTO choices VALUES(?,?,NULL)', (chosen['id'], json.dumps(chosen)))
        return chosen

    def finish(self, key, cost, acted, reason):
        if cost < 0:
            raise ValueError('negative observed cost')
        outcome = json.dumps(dict(cost=cost, acted=bool(acted), reason=reason))
        with self.db:
            row = self.db.execute('SELECT outcome FROM choices WHERE id=?', (key,)).fetchone()
            if row is None:
                raise ValueError('unclaimed opportunity')
            if row[0] is not None and row[0] != outcome:
                raise ValueError('conflicting result')
            self.db.execute('UPDATE choices SET outcome=? WHERE id=?', (outcome, key))

    def close(self):
        self.db.close()
