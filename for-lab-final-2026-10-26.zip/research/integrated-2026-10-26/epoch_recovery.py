"""Conservative recovery after an EXTERNALLY OBSERVED context boundary.

Not autonomous change-point discovery. A supplied boundary is an experimental
input, not cryptographically authenticated proof. Old evidence is never erased.
"""
import argparse
import json
from persistent_inquiry import Store,run
from basis_inquiry import Task

class EpochStore(Store):
    def __init__(self,path):
        super().__init__(path)
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS active_epochs(root TEXT PRIMARY KEY,epoch INTEGER);
        CREATE TABLE IF NOT EXISTS boundaries(event_id TEXT PRIMARY KEY,root TEXT,old_group TEXT,new_group TEXT,reason TEXT);
        ''')
        self.db.commit()

    def current(self,root):
        row=self.db.execute('SELECT epoch FROM active_epochs WHERE root=?',(root,)).fetchone()
        n=row[0] if row else 0
        return n,json.dumps([root,n],separators=(',',':'))

    def recover(self,root,boundary):
        n,old=self.current(root)
        if self.state(old)[1]:
            raise ValueError('recovery requires a recorded contradiction')
        if not isinstance(boundary,dict) or boundary.get('observed') is not True:
            raise ValueError('no observed context boundary; cannot discard conflict')
        if boundary.get('kind')!='component_replaced' or not isinstance(boundary.get('event_id'),str) or not boundary['event_id'].strip():
            raise ValueError('unsupported or missing boundary event')
        if self.db.execute('SELECT 1 FROM boundaries WHERE event_id=?',(boundary['event_id'],)).fetchone():
            raise ValueError('boundary event already used')
        new=json.dumps([root,n+1],separators=(',',':'))
        with self.db:
            self.db.execute('INSERT INTO boundaries VALUES(?,?,?,?,?)',
                            (boundary['event_id'],root,old,new,json.dumps(boundary)))
            self.db.execute('INSERT INTO active_epochs VALUES(?,?) ON CONFLICT(root) DO UPDATE SET epoch=excluded.epoch',(root,n+1))
        return new

def episode(path,mode,truth,target=2,boundary=None,budget=1):
    store=EpochStore(path)
    root='workshop'
    try:
        if boundary is not None:
            group=store.recover(root,boundary)
        else:
            _,group=store.current(root)
        epoch=store.current(root)[0]
    finally:
        store.close()
    result=run(path,mode,Task((1,0),target),truth,group,budget)
    return {'epoch':epoch,'boundary_supplied':boundary is not None,**result}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--db',required=True)
    p.add_argument('--mode',choices=('FoR','B2'),default='FoR')
    p.add_argument('--x',type=int,required=True)
    p.add_argument('--target',type=int,default=2)
    p.add_argument('--boundary')
    args=p.parse_args()
    b={'event_id':args.boundary,'kind':'component_replaced','observed':True} if args.boundary else None
    print(json.dumps(episode(args.db,args.mode,(args.x,2),args.target,b),indent=2))
