import json
import hashlib
from pathlib import Path
from datetime import datetime,timezone
from decision_runtime import DecisionRuntime
from incubator_runtime import Workshop

root=Path(__file__).resolve().parent
out=root/'runs'/datetime.now(timezone.utc).strftime('decision-%Y%m%dT%H%M%S%fZ')
out.mkdir(parents=True)
rows=[]
for mode in ('FoR','B2'):
 for policy in ('decision','information'):
  for actions in ((1,),(2,),(1,2)):
   for target in range(1,7):
    for costs in ({'CAL':'1/10','U1':'1/10','U2':'1/10'},{'CAL':'1/10','U1':'1/10','U2':'3/2'}):
     for penalty in ('1/5','2'):
      for g in (1,2,3):
       for b in (-1,0,1):
        r=DecisionRuntime(':memory:',mode); w=Workshop(g,b)
        r.start_decision(target,actions=actions,costs=costs,penalty=penalty,policy=policy)
        s=r.run(w)
        trace=[json.loads(x[0]) for x in r.db.execute('SELECT body FROM events')]
        probes=[x['probe'] for x in trace if x['kind']=='PROBE']
        rows.append(dict(mode=mode,policy=policy,actions=actions,target=target,costs=costs,
            penalty=penalty,g=g,b=b,phase=s['phase'],feasible=any(g*u==target for u in actions),
            success=bool(w.actions) and w.actions[-1]['harm']==0,harms=sum(a['harm'] for a in w.actions),
            probes=probes,budget=s['budget'],trace=trace))
        r.close()
(out/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
summary={p:dict(episodes=len(rr),successes=sum(x['success'] for x in rr),harms=sum(x['harms'] for x in rr),
    probes=sum(len(x['probes']) for x in rr),halts=sum(x['phase']=='HALT' for x in rr))
    for p in ('decision','information') for rr in [[x for x in rows if x['policy']==p]]}
high=[x for x in rows if x['policy']=='decision' and x['penalty']=='2' and x['costs']['U2']=='1/10']
summary['high_penalty_cheap_probes']=dict(feasible=sum(x['feasible'] for x in high),successes=sum(x['success'] for x in high))
summary['first_choices']=sorted({x['probes'][0] for x in rows if x['policy']=='decision' and x['probes']})
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
(out/'source-hashes.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in
    ('decision_runtime.py','decision_campaign.py','incubator_runtime.py','DECISION_PROTOCOL.md')},indent=2),encoding='utf8')
assert all(x['harms']==0 and x['budget']>=0 for x in rows)
assert all(x['success']==x['feasible'] for x in high)
assert len(summary['first_choices'])>1
print(json.dumps(summary,indent=2)); print('ARTIFACT_DIR='+str(out))
