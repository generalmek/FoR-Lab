"""Addressed inquiry in a finite, known response language. No external effects."""
from dataclasses import dataclass, asdict
from itertools import product

MODELS = tuple(product((1,2), repeat=2))
US = (1,2)

@dataclass(frozen=True)
class Task:
    weights: tuple
    target: int
    labels: tuple = ('tool', 'material')
    cue: int = 0

@dataclass(frozen=True)
class FoundationGap:
    basis_ids: tuple
    reason: str

def predict(model, task, u):
    return u * sum(w*x for w,x in zip(task.weights,model))

def robust(models,task):
    return next((u for u in US if models and all(predict(m,task,u)==task.target for m in models)),None)

def assess(models,task):
    # Address known dependencies, not discover them from measurements.
    axes=tuple(i for i,w in enumerate(task.weights) if w and len({m[i] for m in models})>1)
    return FoundationGap(tuple(task.labels[i] for i in axes),'uncertain decision-relevant basis'),axes

def choose(models,task,axes):
    scored=[]
    for axis in axes:
        values=sorted({m[axis] for m in models})
        if len(values)<2:
            continue
        groups=[tuple(m for m in models if m[axis]==v) for v in values]
        coverage=sum(len(g) for g in groups if robust(g,task) is not None)
        separation=len(models)**2-sum(len(g)**2 for g in groups)
        scored.append((coverage,separation,-axis,axis))
    return max(scored)[-1] if scored else None

class Agent:
    def __init__(self,mode,task,budget=1):
        if mode not in ('FoR','B2','cue_only') or type(budget) is not int or budget<0:
            raise ValueError('invalid mode/budget')
        if len(task.weights)!=2 or len(task.labels)!=2 or len(set(task.labels))!=2 or task.cue not in (0,1):
            raise ValueError('invalid task')
        self.mode,self.task,self.budget=mode,task,budget
        self.models=MODELS
        self.trace=[]
        self.pending=None

    def decide(self):
        if self.pending is not None:
            raise RuntimeError('measurement outcome required')
        if not self.models:
            self.trace.append({'stop':'CONTRADICTION'})
            return ('ABSTAIN',None)
        u=robust(self.models,self.task)
        if u is not None:
            self.trace.append({'action':'PROCESS','u':u})
            return ('PROCESS',u)
        if not any(predict(m,self.task,u)==self.task.target for m in self.models for u in US):
            self.trace.append({'stop':'NO_FEASIBLE_ACTION'})
            return ('ABSTAIN',None)
        if not self.budget:
            self.trace.append({'stop':'BUDGET_LIMIT'})
            return ('ABSTAIN',None)
        if self.mode=='FoR':
            gap,axes=assess(self.models,self.task)
            self.trace.append({'gap':asdict(gap)})
            axis=choose(self.models,self.task,axes)
        elif self.mode=='B2':
            axis=choose(self.models,self.task,(0,1))
        else:
            axis=self.task.cue
        if axis is None:
            self.trace.append({'stop':'NO_DISCRIMINATING_TEST'})
            return ('ABSTAIN',None)
        self.pending=axis
        self.budget-=1
        self.trace.append({'test':self.task.labels[axis],'axis':axis})
        return ('TEST',axis)

    def receive(self,axis,value):
        if self.pending!=axis:
            raise ValueError('unrequested evidence')
        self.models=tuple(m for m in self.models if m[axis]==value)
        self.trace.append({'evidence':{'axis':axis,'value':value},'models':self.models})
        self.pending=None

def episode(mode,task,truth,budget=1):
    # Only evaluator sees truth; agent has public task + measured values.
    agent=Agent(mode,task,budget)
    measurements=0
    while True:
        kind,arg=agent.decide()
        if kind=='TEST':
            measurements+=1
            agent.receive(arg,truth[arg])
            continue
        actual=predict(truth,task,arg) if kind=='PROCESS' else None
        success=(actual==task.target) if actual is not None else None
        return {'mode':mode,'task':asdict(task),'truth':truth,'budget':budget,
                'success':success,'harm':int(success is False),'measurements':measurements,
                'trace':agent.trace,'final_models':agent.models}
