"""One-step decision-focused probing, shared by both agents; finite model counts.

No calibrated probabilities are claimed. Count compatible models equally.
This heuristic is not general multi-step optimal planning or a complete Core.
"""
from collections import defaultdict
from incubator import Action, predict, robust

def decision_probe(candidates, obs):
    scored = []
    for u,c in obs.options:
        partitions = defaultdict(list)
        for model in candidates:
            partitions[predict(model,u,c)].append(model)
        if len(partitions) < 2:
            continue
        # Prefer measurements after which a robust successful action is possible.
        actionable = sum(len(group) for group in partitions.values() if robust(group,obs))
        separated_pairs = sum(len(a)*len(b) for i,a in enumerate(partitions.values())
                              for j,b in enumerate(partitions.values()) if i<j)
        scored.append((actionable,separated_pairs,-u,-c,u,c))
    if not scored:
        return None
    winner = max(scored)
    return Action('TEST',winner[-2],winner[-1])
