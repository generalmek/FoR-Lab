import json
from pathlib import Path
from datetime import datetime,timezone
from conflict_diagnosis import HYPOTHESES,predicted
from revision_gate import RevisionStore

folder=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('gate-%Y%m%dT%H%M%S%fZ')
folder.mkdir(parents=True)
rows=[]
for i,model in enumerate(HYPOTHESES):
    s=RevisionStore(folder/f'case-{i}.sqlite')
    try:
        for name,deps in [('physical',['process']),('sensor',['sensor']),('reading',['process','sensor'])]:
            s.add_forecast(name,deps)
        evidence=[{'probe':p,'value':predicted(model,p)} for p in ('CAL','U1','U2')]
        result=s.apply(evidence,True)
        rows.append({'truth':model,'evidence':evidence,'decision':result,'stored':s.state()})
    finally: s.close()
(folder/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
for row in rows: print(row['truth'],row['decision']['status'],row['decision']['affected'])
print('ARTIFACT_DIR='+str(folder))
