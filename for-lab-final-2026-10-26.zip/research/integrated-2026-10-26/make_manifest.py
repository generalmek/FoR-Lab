"""Record local source hashes. Does not upload or modify experiment data."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
files = {}
for pattern in ('*.py', '*.md', '*.bat'):
    for path in sorted(root.glob(pattern)):
        files[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
for name in ('semantic_protocol.json','received/sol-semantic-proposal-2026-10-25.json'):
    path=root/name
    if path.exists():files[name]=hashlib.sha256(path.read_bytes()).hexdigest()
(root / 'source-manifest.json').write_text(
    json.dumps({'format': 1, 'files': files}, ensure_ascii=False, indent=2),
    encoding='utf-8',
)
print('Saved source-manifest.json')
