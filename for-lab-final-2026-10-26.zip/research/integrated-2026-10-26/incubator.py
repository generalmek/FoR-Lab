"""FoR Incubator 0.4: finite-model workshop; Python stdlib only, no LLM."""
from __future__ import annotations
import argparse
import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path

KS = (1, 2, 3)
US = (1, 2)
CS = (1, 2)
ACTIONS = tuple((u, c) for u in US for c in CS)
TOL = 0.01


def predict(model, u, c):
    family, k = model
    return k * u * (c if family == 'interaction' else 1)


def grammar():
    return tuple((f, k) for f in ('linear', 'interaction') for k in KS)


def label(model):
    return f'{model[0]}:k={model[1]}'


@dataclass(frozen=True)
class Observation:
    group: str
    role: str
    target: int
    options: tuple
    budget_left: int


@dataclass(frozen=True)
class Action:
    kind: str
    u: int = 0
    c: int = 0


@dataclass(frozen=True)
class Outcome:
    kind: str
    u: int
    c: int
    dq: int | None
    success: bool | None
    harm: int
    cost: int
    terminal: bool


class World:
    """Private truth remains with Runner, not with the agent."""
    def __init__(self, family, k, group, target, role, budget=2):
        if family not in ('linear', 'interaction') or type(k) is not int or k <= 0:
            raise ValueError('invalid world model')
        if type(budget) is not int or budget < 0:
            raise ValueError('invalid probe budget')
        self._model = (family, k)
        self.group, self.role, self.target = group, role, target
        self.budget = budget
        self.terminal = False

    def observation(self):
        return Observation(self.group, self.role, self.target, ACTIONS, self.budget)

    def step(self, action):
        if self.terminal:
            raise RuntimeError('episode finished')
        if action.kind == 'ABSTAIN':
            self.terminal = True
            return Outcome('ABSTAIN', 0, 0, None, None, 0, 0, True)
        if action.kind not in ('TEST', 'PROCESS') or (action.u, action.c) not in ACTIONS:
            raise ValueError('invalid action')
        if action.kind == 'TEST':
            if self.budget < 1:
                raise ValueError('insufficient budget')
            self.budget -= 1
        dq = predict(self._model, action.u, action.c)
        done = action.kind == 'PROCESS'
        self.terminal = done
        success = abs(dq - self.target) <= TOL if done else None
        return Outcome(action.kind, action.u, action.c, dq, success,
                       int(done and not success), int(not done), done)


class Knowledge:
    """Versioned candidates and immutable evidence, scoped by public mechanism group."""
    def __init__(self, path):
        self.db = sqlite3.connect(str(path))
        self.db.execute('CREATE TABLE IF NOT EXISTS groups (name TEXT PRIMARY KEY, version INTEGER NOT NULL, candidates TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS evidence (id INTEGER PRIMARY KEY, grp TEXT, role TEXT, u INTEGER, c INTEGER, dq INTEGER, version INTEGER)')
        self.db.execute('CREATE TABLE IF NOT EXISTS supports (grp TEXT, version INTEGER, evidence_id INTEGER, PRIMARY KEY(grp,version,evidence_id))')
        self.db.execute('CREATE TABLE IF NOT EXISTS predictions (grp TEXT, version INTEGER, role TEXT, u INTEGER, c INTEGER, dq INTEGER, valid INTEGER)')
        self.db.execute('CREATE TABLE IF NOT EXISTS methods (grp TEXT PRIMARY KEY, name TEXT, attempts INTEGER NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS claim_versions (grp TEXT, version INTEGER, candidates TEXT, PRIMARY KEY(grp,version))')
        self.db.commit()

    def state(self, group):
        row = self.db.execute('SELECT version,candidates FROM groups WHERE name=?', (group,)).fetchone()
        return (row[0], tuple(tuple(m) for m in json.loads(row[1]))) if row else (0, grammar())

    def evidence(self, group):
        return self.db.execute('SELECT u,c,dq FROM evidence WHERE grp=? ORDER BY id', (group,)).fetchall()

    def learn(self, obs, outcome):
        if outcome.kind not in ('TEST', 'PROCESS') or outcome.dq is None:
            raise ValueError('learning requires a measured outcome')
        version, old = self.state(obs.group)
        compatible = tuple(m for m in old if predict(m, outcome.u, outcome.c) == outcome.dq)
        # Empty candidates are durable: do not silently reset to a known model.
        new_version = version + 1
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO claim_versions VALUES(?,?,?)',
                            (obs.group, version, json.dumps(old)))
            self.db.execute('INSERT INTO claim_versions VALUES(?,?,?)',
                            (obs.group, new_version, json.dumps(compatible)))
            self.db.execute('INSERT INTO evidence(grp,role,u,c,dq,version) VALUES(?,?,?,?,?,?)',
                            (obs.group, obs.role, outcome.u, outcome.c, outcome.dq, new_version))
            evidence_id = self.db.execute('SELECT last_insert_rowid()').fetchone()[0]
            self.db.execute('INSERT INTO groups(name,version,candidates) VALUES(?,?,?) '
                            'ON CONFLICT(name) DO UPDATE SET version=excluded.version,candidates=excluded.candidates',
                            (obs.group, new_version, json.dumps(compatible)))
            self.db.execute('UPDATE predictions SET valid=0 WHERE grp=? AND valid=1', (obs.group,))
            for (eid,) in self.db.execute('SELECT id FROM evidence WHERE grp=?', (obs.group,)):
                self.db.execute('INSERT INTO supports VALUES(?,?,?)', (obs.group, new_version, eid))
            self.db.execute('INSERT INTO methods(grp,name,attempts) VALUES(?,?,1) '
                            'ON CONFLICT(grp) DO UPDATE SET attempts=attempts+1',
                            (obs.group, 'prediction_disagreement'))
        return compatible

    def remember_prediction(self, obs, action, dq):
        version, _ = self.state(obs.group)
        with self.db:
            self.db.execute('INSERT INTO predictions VALUES(?,?,?,?,?,?,1)',
                            (obs.group, version, obs.role, action.u, action.c, dq))

    def close(self):
        self.db.close()


def robust(candidates, obs):
    for u, c in obs.options:
        if candidates and all(abs(predict(m, u, c) - obs.target) <= TOL for m in candidates):
            return Action('PROCESS', u, c)
    return None


def discriminating_probe(candidates, obs):
    """Pick permitted probe with maximum number of pairwise prediction disagreements."""
    choices = []
    for u, c in obs.options:
        outputs = [predict(m, u, c) for m in candidates]
        disagree = sum(outputs[i] != outputs[j] for i in range(len(outputs)) for j in range(i+1, len(outputs)))
        choices.append((disagree, -u, -c, u, c))
    if not choices:
        return None
    winner = max(choices)
    return Action('TEST', winner[3], winner[4]) if winner[0] > 0 else None


class Agent:
    def __init__(self, name, knowledge, probe_selector=discriminating_probe):
        if name not in ('FoR', 'B2'):
            raise ValueError(name)
        self.name, self.knowledge = name, knowledge
        self.probe_selector = probe_selector
        self.trace = []

    def decide(self, obs):
        version, candidates = self.knowledge.state(obs.group)
        if not candidates:
            self.trace.append(('OUT_OF_CLASS', version))
            return Action('ABSTAIN')
        safe = robust(candidates, obs)
        if safe:
            self.trace.append(('ROBUST_NO_TEST', version, len(candidates)))
            self.knowledge.remember_prediction(obs, safe, obs.target)
            return safe
        if not any(abs(predict(m, u, c) - obs.target) <= TOL
                   for m in candidates for u, c in obs.options):
            self.trace.append(('NO_FEASIBLE_ACTION', version, len(candidates)))
            return Action('ABSTAIN')
        if obs.budget_left <= 0:
            self.trace.append(('BUDGET_LIMIT', version, len(candidates)))
            return Action('ABSTAIN')
        probe = self.probe_selector(candidates, obs)
        if probe is None:
            self.trace.append(('UNIDENTIFIABLE_IN_CLASS', version, len(candidates)))
            return Action('ABSTAIN')
        if self.name == 'FoR':
            self.trace.append(('FOUNDATION_GAP', version, tuple(map(label, candidates))))
        else:
            self.trace.append(('ACTIVE_SEARCH', version, len(candidates)))
        return probe

    def receive(self, obs, outcome):
        if outcome.kind == 'TEST':
            self.knowledge.learn(obs, outcome)
            self.trace.append(('EVIDENCE', outcome.u, outcome.c, outcome.dq))
        else:
            if outcome.kind == 'PROCESS':
                remaining = self.knowledge.learn(obs, outcome)
                self.trace.append(('PROCESS_EVIDENCE', outcome.u, outcome.c, outcome.dq))
                if not remaining:
                    self.trace.append(('MODEL_CONTRADICTION', obs.group))
            self.trace.append(('TERMINAL', outcome.kind, outcome.success, outcome.harm))


class Runner:
    def __init__(self, agent, world):
        self.agent, self._world = agent, world

    def run(self):
        while not self._world.terminal:
            obs = self._world.observation()
            action = self.agent.decide(obs)
            outcome = self._world.step(action)
            self.agent.receive(obs, outcome)
        return {'success': outcome.success, 'harm': outcome.harm,
                'tests': sum(x[0] == 'EVIDENCE' for x in self.agent.trace),
                'trace': self.agent.trace}


def demo(path):
    # Refuse an existing output set before creating anything: never erase memories.
    paths = [Path(path).with_name(f'{Path(path).stem}_{name}.sqlite') for name in ('FoR', 'B2')]
    if any(p.exists() for p in paths):
        raise FileExistsError('Demo output exists; choose a new --db prefix.')
    result = {}
    for name in ('FoR', 'B2'):
        dbpath = Path(path).with_name(f'{Path(path).stem}_{name}.sqlite')
        k = Knowledge(dbpath)
        agent = Agent(name, k)
        result[name] = Runner(agent, World('interaction', 2, 'workshop', 4, 'first')).run()
        k.close()
        k = Knowledge(dbpath)  # explicit persistence / reload
        agent = Agent(name, k)
        result[name + '_after_restart'] = Runner(agent, World('interaction', 2, 'workshop', 4, 'renamed')).run()
        k.close()
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--db', default='incubator.sqlite')
    args = p.parse_args()
    print(json.dumps({'no_llm': True, 'results': demo(args.db)}, ensure_ascii=False, indent=2))
