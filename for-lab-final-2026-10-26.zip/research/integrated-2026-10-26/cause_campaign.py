"""Experimental preflight policies; production Runtime remains unchanged."""
import json
from pathlib import Path
from datetime import datetime, timezone
from incubator_runtime import Runtime, Workshop

POLICIES=('baseline','no_diagnosis','no_revision','check_U1','check_CAL','check_U2','fresh_all')

class InterventionRuntime(Runtime):
    def preflight(self,world,policy):
        if policy not in POLICIES: raise ValueError('unknown intervention')
        s=self.state()
        if s['phase']!='ASSESS': raise ValueError('preflight at task boundary only')
        if policy in ('baseline','no_diagnosis','no_revision'): return
        with self.db:
            if policy=='fresh_all':
                s.update(certified=False,scope=[],evidence=[],generation=s['generation']+1,phase='INQUIRE')
                self.event(s,'EXPERIMENTAL_FRESHNESS_POLICY')
            elif s['budget']<1:
                s.update(phase='HALT',reason='PREFLIGHT_BUDGET')
            else:
                probe=policy.removeprefix('check_')
                b=self.beliefs()
                expected=b['sensor'][0] if probe=='CAL' else b['process'][0]*int(probe[1:])+b['sensor'][0]
                value=world.measure(probe); s['budget']-=1
                self.event(s,'PREFLIGHT',probe=probe,value=value,expected=expected)
                if value!=expected:
                    s.update(certified=False,scope=[],generation=s['generation']+1,
                             evidence=[dict(probe=probe,value=value)],phase='DIAGNOSE')
                    self.event(s,'CONTRADICTION',source='preflight',expected=expected,observed=value)
            self.save(s)

def episode(path,policy,g,b,target,mode='FoR'):
    r=InterventionRuntime(path,mode)
    try:
        r.start(1); r.run(Workshop())
        # Disable only after shared initial learning, to isolate later recovery.
        r.diagnosis=policy!='no_diagnosis'; r.revision=policy!='no_revision'
        r.start(target,budget=8)
        w=Workshop(g,b); r.preflight(w,policy); s=r.run(w)
        events=[json.loads(x[0]) for x in r.db.execute('SELECT body FROM events')]
        trace=[x for x in events if x['task_id']==2]
        return dict(policy=policy,mode=mode,g=g,b=b,target=target,phase=s['phase'],reason=s['reason'],
                    feasible=any(g*u==target for u in (1,2)),
                    success=bool(w.actions) and w.actions[-1]['harm']==0,
                    harms=sum(x['harm'] for x in w.actions),
                    probes=sum(x['kind'] in ('PROBE','PREFLIGHT') for x in trace),
                    contradictions=sum(x['kind']=='CONTRADICTION' for x in trace),
                    actions=w.actions,trace=trace,budget_left=s['budget'])
    finally: r.close()

def main():
    root=Path(__file__).resolve().parent
    out=root/'runs'/datetime.now(timezone.utc).strftime('causes-%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True)
    rows=[]
    for mode in ('FoR','B2'):
        for policy in POLICIES:
            for g in (1,2,3):
                for b in (-1,0,1):
                    for target in range(1,7):
                        rows.append(episode(out/f'{mode}-{policy}-{g}-{b}-{target}.sqlite',policy,g,b,target,mode))
    summary={p:dict(episodes=len(rr),successes=sum(x['success'] for x in rr),
                    feasible=sum(x['feasible'] for x in rr),harms=sum(x['harms'] for x in rr),
                    halts=sum(x['phase']=='HALT' for x in rr),probes=sum(x['probes'] for x in rr))
             for p in POLICIES for rr in [[x for x in rows if x['policy']==p]]}
    fixed=[{k:v for k,v in x.items() if k not in ('trace','mode')} for x in rows
           if x['mode']=='FoR' and (x['g'],x['b'],x['target'])==(2,-1,1)]
    (out/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    (out/'fixed-counterexample.json').write_text(json.dumps(fixed,indent=2),encoding='utf8')
    # These checks test the predeclared prediction, not an architectural victory.
    by={x['policy']:x for x in fixed}
    assert by['baseline']['harms']==by['check_U1']['harms']==1
    assert all(by[p]['harms']==0 and not by[p]['success'] for p in ('check_CAL','check_U2','fresh_all'))
    assert summary['fresh_all']['harms']==0
    assert summary['fresh_all']['successes']==summary['fresh_all']['feasible']
    assert all(x['budget_left']>=0 for x in rows)
    print(json.dumps(summary,indent=2)); print('ARTIFACT_DIR='+str(out))

if __name__=='__main__': main()
