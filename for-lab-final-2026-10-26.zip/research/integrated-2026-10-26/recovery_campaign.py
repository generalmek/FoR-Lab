import json
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path

root=Path(__file__).resolve().parent
folder=root/'runs'/datetime.now(timezone.utc).strftime('recovery-%Y%m%dT%H%M%S%fZ')
folder.mkdir(parents=True)
rows=[]
for mode in ('FoR','B2'):
    for label,x,target,boundary in [('learn',1,1,None),('hidden-change',2,2,None),
        ('no-boundary-stop',2,2,None),('observed-replacement',2,2,'replacement-1'),
        ('restart-new-target',2,4,None),('unknown-law-failure',7,2,None),
        ('new-epoch-still-unknown',7,2,'replacement-2')]:
        cmd=[sys.executable,str(root/'epoch_recovery.py'),'--db',str(folder/f'{mode}.sqlite'),
             '--mode',mode,'--x',str(x),'--target',str(target)]
        if boundary: cmd+=['--boundary',boundary]
        r=json.loads(subprocess.run(cmd,capture_output=True,text=True,check=True).stdout)
        rows.append({'stage':label,**r})
(folder/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
lines=['FoR LAB | recovery experiment - actual process output',
       'Boundary means EXTERNALLY OBSERVED replacement; not autonomous discovery.','']
for r in rows:
    lines.append(f"{r['mode']:3} | {r['stage']:23} | success={str(r['success']):5} | probes={r['measurements']} | harm={r['harm']} | epoch={r['epoch']}")
lines+=['','Old contradictory evidence retained. New context requires new measurement.',
        'Outside the known model class: still stops. FoR and B2 tie.']
(folder/'terminal.txt').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
print('ARTIFACT_DIR='+str(folder))
