"""Single development trajectory plus stale-permission counterexample."""
import hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
from procedural_cycle import ProceduralCycle,ProcedureWorld

def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    (out/'source').mkdir()
    hashes={}
    for p in Path(__file__).parent.glob('*.py'):
        shutil.copy2(p,out/'source'/p.name);hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    (out/'protocol.json').write_text(json.dumps(dict(source_sha256=hashes,
        scope='single development trajectory, simulator, not superiority evidence',
        interventions=['sensor drift after local evidence','process change at first execution',
                       'new external goal with new context/cost','unaffordable calibration'],
        budget_per_external_goal=160),indent=2))
    ap=out/'agent.db';w=ProcedureWorld(out/'world.db',lambda u,v:1+2*u,1,initial=1000,error_bound=0)
    r=ProceduralCycle(ap);trace=[];rows=[];shifted=False;changed=False
    original=w.apply_once
    def surprise(op,u,target):
        nonlocal changed
        if not changed:w.law=lambda u,v:2+3*u;changed=True
        return original(op,u,target)
    w.apply_once=surprise
    try:
        for stage in range(3):
            if stage==1:w.context=2;w.probe_prices['T3']=20
            if stage==2:w.sample_price=10000
            s=r.begin(w,budget=160) if stage==0 else r.next_goal(w,budget=160)
            before=w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]
            for _ in range(100):
                trace.append(dict(stage=stage,state=s))
                if s['life']['status'] in ('DONE','STOPPED'):break
                if not shifted and any(e['probe'].startswith('U') for e in s['evidence']):
                    w.channel_gain=2;w.channel_bias=3;shifted=True
                r.close();r=ProceduralCycle(ap)
                s=r.tick(w)
            else:raise AssertionError('did not terminate')
            rows.append(dict(stage=stage,status=s['life']['status'],reason=s.get('reason'),
                remaining=s['budget'],repairs=s['life']['repairs'],balance=w.balance(),
                new_actions=w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]-before))
        assert rows[0]['status']=='DONE' and rows[0]['repairs']==1
        assert rows[1]['status']=='DONE'
        assert rows[2]['status']=='STOPPED' and rows[2]['new_actions']==0
        assert all(x['balance']>=w.reserve for x in rows)
        assert all(trace[i]['state']['budget']>=trace[i+1]['state']['budget']
                   for i in range(len(trace)-1) if trace[i]['stage']==trace[i+1]['stage'])
    finally:
        (out/'trace.json').write_text(json.dumps(trace,indent=2))
        (out/'results.json').write_text(json.dumps(rows,indent=2))
        r.close();w.close()
    return rows

if __name__=='__main__':
    out=Path(__file__).parent/'runs'/('integrated-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    print(out);print(json.dumps(run(out),indent=2))
