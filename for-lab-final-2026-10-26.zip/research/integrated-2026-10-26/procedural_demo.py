"""Small logged development scenario; no independent superiority claim."""
import hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
from procedural_cycle import ProcedureWorld,ProceduralCycle

def main():
    root=Path(__file__).resolve().parent
    out=root/'runs'/('procedure-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    (out/'source').mkdir(parents=True)
    hashes={}
    for p in root.glob('*.py'):
        shutil.copy2(p,out/'source'/p.name);hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    (out/'protocol.json').write_text(json.dumps(dict(source_sha256=hashes,
        scope='development; bounded probe programs; trusted simulator receipt',
        stages=['construct','changed cost and context','reuse','misleading sensor physical failure']),indent=2))
    rows=[];traces=[]
    for negative in (False,True):
        label='negative' if negative else 'positive'
        w=ProcedureWorld(out/(label+'-world.db'),lambda u,v:1+2*u,1,initial=1000,error_bound=0)
        r=ProceduralCycle(out/(label+'-agent.db'))
        if negative:
            original=w.apply_once
            def surprise(op,u,target):
                w.law=lambda u,v:4+2*u;w.channel_bias=-3
                return original(op,u,target)
            w.apply_once=surprise
        try:
            for stage in range(1 if negative else 4):
                s=r.begin(w,budget=100,repair_limit=0) if stage==0 else r.next_goal(w,budget=100)
                for _ in range(80):
                    traces.append(dict(case=label,stage=stage,state=s))
                    if s['life']['status'] in ('DONE','STOPPED'):break
                    s=r.tick(w)
                else:raise RuntimeError('nontermination')
                record=json.loads(r.db.execute('SELECT body FROM procedures ORDER BY id DESC LIMIT 1').fetchone()[0])
                rows.append(dict(case=label,stage=stage,phase=s['phase'],reason=s.get('reason'),
                    status=record['status'],transfer=record['transfer'],search_nodes=record['search_nodes'],
                    fit_order=record['fit_order'],remaining=s['budget']))
                if not negative and stage==0:
                    w.probe_prices[record['fit_order'][0]]=50;w.context=2
                    w.law=lambda u,v:2+3*u
        finally:r.close();w.close()
    for name,data in [('results',rows),('trace',traces)]:
        (out/(name+'.json')).write_text(json.dumps(data,indent=2),encoding='utf-8')
    print(out);print(json.dumps(rows,indent=2))

if __name__=='__main__':main()
