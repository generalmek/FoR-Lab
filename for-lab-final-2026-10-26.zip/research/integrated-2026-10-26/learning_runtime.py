"""Parameter learning and checked transfer in the declared stationary affine family.

Not discovery of that family. CAL is a trusted zero reference; probes are safe.
Memory suggests a short validation route, never grants an unchecked action.
The no-memory control uses the identical estimator and full validation protocol.
"""
import json
from agenda_runtime import AgendaRuntime
from decision_runtime import robust_action
from conflict_diagnosis import predicted,PROBES

class LearningRuntime(AgendaRuntime):
    def __init__(self,*args,use_memory=True,direct=False,**kwargs):
        super().__init__(*args,**kwargs)
        self.use_memory=use_memory
        self.direct=direct
        self.db.execute('CREATE TABLE IF NOT EXISTS learned_models(id INTEGER PRIMARY KEY,body TEXT)')
        self.db.commit()

    def remembered(self):
        if not self.use_memory:return None
        row=self.db.execute('SELECT body FROM learned_models ORDER BY id DESC LIMIT 1').fetchone()
        return json.loads(row[0])['model'] if row else None

    def fitted(self,s):
        e={x['probe']:x['value'] for x in s['evidence']}
        if not set(PROBES)<=set(e):return None
        # Fit CAL/U1; U2 is the independent intervention consistency check.
        gain=e['U1']-e['CAL'];bias=e['CAL']
        if type(gain) is not int or gain<=0:return None
        model=(gain,bias)
        return model if all(predicted(model,x['probe'])==x['value'] for x in s['evidence']) else None

    def candidates(self,s):
        if self.direct:
            e={x['probe']:x['value'] for x in s['evidence']}
            if 'CAL' in e:
                for u in s['actions']:
                    if 'U'+str(u) in e:
                        g=(e['U'+str(u)]-e['CAL'])/u
                        if g>0 and g.is_integer() and all(predicted((int(g),e['CAL']),x['probe'])==x['value'] for x in s['evidence']):
                            return ((int(g),e['CAL']),)
            return ()
        fit=self.fitted(s)
        if fit:return (fit,)
        model=self.remembered();seen={e['probe'] for e in s['evidence']}
        if model and 'CAL' in seen and seen.intersection(('U1','U2')) and all(
                predicted(model,e['probe'])==e['value'] for e in s['evidence']):
            return (tuple(model),)
        return ()

    def choose_plan(self,s,models):
        seen={e['probe'] for e in s['evidence']}
        u=robust_action(models,s['target'],s['actions'],seen)
        if u is not None and s['budget']>=1:return ('ACT',u),'validated-affine-action'
        if set(PROBES)<=seen:return ('HALT',None),'no-validated-feasible-action'
        if s['budget']<2:return ('HALT',None),'insufficient-budget-for-probe-and-action'
        model=self.remembered()
        consistent=model and all(predicted(model,e['probe'])==e['value'] for e in s['evidence'])
        proposed=next((u for u in s['actions'] if model and model[0]*u==s['target']),None)
        if consistent and proposed is not None:
            order=('CAL','U'+str(proposed),*PROBES)
        else:order=PROBES
        return ('PROBE',next(p for p in order if p not in seen)),'validation-policy-not-minimax'

    def commit_complete_evidence(self,s):
        if {e['probe'] for e in s['evidence']}!=set(PROBES):return
        model=self.fitted(s)
        if model is None:
            self.event(s,'LEARNING_REJECTED',reason='AFFINE_FAMILY_CONTRADICTION');return
        if not s['trusted']:return
        before=self.beliefs();changed=[]
        for name,value in zip(('process','sensor'),model):
            if before[name][0]!=value:
                changed.append(name)
                self.db.execute('UPDATE beliefs SET value=?,version=version+1 WHERE name=?',(value,name))
        for name,deps in self.db.execute('SELECT name,deps FROM forecasts').fetchall():
            if set(changed)&set(json.loads(deps)):
                self.db.execute('UPDATE forecasts SET valid=0 WHERE name=?',(name,))
        record=dict(task_id=s['task_id'],model=model,evidence=s['evidence'],
                    family='stationary-affine-positive-integer-gain',scope=['U1','U2'],
                    trusted_calibration_assumed=True)
        self.db.execute('INSERT INTO learned_models(body) VALUES(?)',(json.dumps(record),))
        self.db.execute('INSERT INTO runtime_revisions(body) VALUES(?)',
                        (json.dumps(dict(before=before,changed=changed,**record)),))
        self.event(s,'LEARNED_AFFINE_PARAMETERS',record=record)
