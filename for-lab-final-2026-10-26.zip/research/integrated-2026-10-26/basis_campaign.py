import hashlib
import json
from pathlib import Path
from itertools import product
from datetime import datetime,timezone
from basis_inquiry import MODELS,Task,episode

root=Path(__file__).resolve().parent
run=root/'runs'/datetime.now(timezone.utc).strftime('basis-%Y%m%dT%H%M%S%fZ')
run.mkdir(parents=True)
# Persist contract/source before execution; development sweep, not blinded holdout.
(run/'frozen-input-hashes.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest()
    for name in ('BASIS_PROTOCOL.md','basis_inquiry.py','basis_campaign.py')},indent=2),encoding='utf-8')
rows=[episode(mode,Task(weights,target,cue=cue),truth,budget)
      for weights,target,truth,cue,budget,mode in product(
          ((1,0),(0,1),(1,1),(1,2)),range(1,13),MODELS,(0,1),(0,1),('FoR','B2','cue_only'))]
summary={mode:{'episodes':sum(r['mode']==mode for r in rows),
    'successes':sum(r['mode']==mode and r['success'] is True for r in rows),
    'abstentions':sum(r['mode']==mode and r['success'] is None for r in rows),
    'harms':sum(r['harm'] for r in rows if r['mode']==mode),
    'measurements':sum(r['measurements'] for r in rows if r['mode']==mode)} for mode in ('FoR','B2','cue_only')}
summary['FoR_B2_equal']=all((rows[i]['success'],rows[i]['harm'],rows[i]['measurements'])==
    (rows[i+1]['success'],rows[i+1]['harm'],rows[i+1]['measurements']) for i in range(0,len(rows),3))
(run/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
(run/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print('ARTIFACT_DIR='+str(run))
