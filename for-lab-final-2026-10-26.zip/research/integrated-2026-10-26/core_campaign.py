"""Development sweep; actual truth is held by the evaluator, not Agent."""
import json
from datetime import datetime, timezone
from pathlib import Path
from core_revision import Agent, Knowledge

def run():
    rows = []
    for cause in ('heat', 'pressure'):
        for value in range(1, 6):
            for mode,propagate,observed in [('FoR',True,True),('B2',True,True),
                                          ('FoR',False,True),('FoR',True,False),('B2',True,False)]:
                agent = Agent(mode, Knowledge(), propagate)
                agent.evaluate()
                truth = {'heat':2, 'pressure':3}
                truth[cause] = value
                if observed:
                    agent.incorporate_measurement(cause, value)
                results = agent.evaluate()
                actual = {'heat_only':truth['heat'], 'pressure_only':truth['pressure'],
                          'combined':truth['heat']+truth['pressure']}
                rows.append(dict(cause=cause,value=value,mode=mode,propagate=propagate,observed=observed,
                    predictions={r.name:r.predicted for r in results},actual=actual,
                    wrong=[r.name for r in results if r.predicted!=actual[r.name]],
                    recomputed=[r.name for r in results if r.recomputed],
                    prediction_calculations=agent.calculations,signature_edge_checks=agent.signature_checks,
                    invalidation_visits=agent.invalidations,index_build_edges=agent.index_build_edges,
                    trace=agent.trace))
    path = Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('core-%Y%m%dT%H%M%S%fZ')
    path.mkdir(parents=True)
    (path/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    summary = dict(episodes=len(rows),
        observed_full_errors=sum(len(r['wrong']) for r in rows if r['observed'] and r['propagate']),
        ablation_errors=sum(len(r['wrong']) for r in rows if not r['propagate']),
        unobserved_errors=sum(len(r['wrong']) for r in rows if not r['observed']),
        claim='Dependency maintenance only; no inquiry selection, persistence or superiority claim.')
    (path/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('ARTIFACT_DIR='+str(path))

if __name__=='__main__':
    run()
