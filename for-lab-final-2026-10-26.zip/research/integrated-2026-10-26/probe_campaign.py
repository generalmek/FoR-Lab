import json
from pathlib import Path
from datetime import datetime, timezone
from incubator import Knowledge, Agent, Runner, World, grammar, predict, ACTIONS, discriminating_probe
from decision_probe import decision_probe

def run():
    rows=[]
    for family,k in grammar():
        for target in range(1,14):
            for name in ('FoR','B2'):
                for strategy,selector in [('disagreement',discriminating_probe),('decision',decision_probe)]:
                    db=Knowledge(':memory:')
                    result=Runner(Agent(name,db,selector),World(family,k,'g',target,'r',1)).run()
                    rows.append(dict(family=family,k=k,target=target,agent=name,strategy=strategy,
                        feasible=any(predict((family,k),u,c)==target for u,c in ACTIONS),**result))
                    db.close()
    summary={s:dict(episodes=sum(r['strategy']==s for r in rows),
        successes=sum(r['strategy']==s and r['success'] is True for r in rows),
        harms=sum(r['harm'] for r in rows if r['strategy']==s)) for s in ('disagreement','decision')}
    path=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('probes-%Y%m%dT%H%M%S%fZ')
    path.mkdir(parents=True)
    (path/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    (path/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('ARTIFACT_DIR='+str(path))

if __name__=='__main__':
    run()
