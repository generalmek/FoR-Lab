"""Reproducible engineering demonstration, not an independent experiment."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from diagnosing_cycle import DiagnosingCycle, ReferenceWorld


def main():
    root=Path(__file__).resolve().parent
    out=root/'runs'/('diagnosis-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    out.mkdir(parents=True)
    sources=out/'source';sources.mkdir()
    hashes={}
    for p in root.glob('*.py'):
        shutil.copy2(p,sources/p.name)
        hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    (out/'protocol.json').write_text(json.dumps(dict(
        kind='development demonstration; no statistical superiority claim',
        cases=['sensor drift before action','process change at action','insufficient budget'],
        assumptions=['trusted references','zero noise','affine channel stable within tick'],
        source_sha256=hashes),indent=2),encoding='utf-8')
    results=[]
    for case,budget in [('sensor',80),('process',100),('budget',3)]:
        w=ReferenceWorld(out/(case+'-world.db'),lambda u,v:1+2*u,1,initial=300,error_bound=0)
        r=DiagnosingCycle(out/(case+'-agent.db'))
        changed=False
        if case=='process':
            original=w.apply_once
            def surprise(op,u,target):
                nonlocal changed
                if not changed:w.law=lambda u,v:2+2*u;changed=True
                return original(op,u,target)
            w.apply_once=surprise
        try:
            result=r.begin(w,budget=budget)
            trace=[result]
            for _ in range(80):
                if result['life']['status'] in ('DONE','STOPPED'):break
                if case=='sensor' and not changed and any(e['probe'].startswith('U') for e in result['evidence']):
                    w.channel_gain=2;w.channel_bias=3;changed=True
                    r.close();r=DiagnosingCycle(out/(case+'-agent.db'))
                result=r.tick(w);trace.append(result)
            else:raise RuntimeError('nontermination')
            (out/(case+'-trace.json')).write_text(json.dumps(trace,indent=2),encoding='utf-8')
            results.append(dict(case=case,status=result['life']['status'],reason=result.get('reason'),
                repairs=result['life']['repairs'],remaining=result['life']['remaining'],
                calibration=result.get('calibration'),
                actions=w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]))
        finally:r.close();w.close()
    (out/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(out)
    for x in results:print({k:v for k,v in x.items() if k!='calibration'})


if __name__=='__main__':main()
