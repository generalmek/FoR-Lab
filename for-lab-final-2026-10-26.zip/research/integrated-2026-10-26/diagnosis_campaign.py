import json
from pathlib import Path
from datetime import datetime,timezone
from conflict_diagnosis import diagnose,predicted,HYPOTHESES,explain

folder=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('diagnosis-%Y%m%dT%H%M%S%fZ')
folder.mkdir(parents=True)
rows=[{'actual_model':m,'expected':explain(m),**diagnose(lambda p,m=m:predicted(m,p))} for m in HYPOTHESES]
negative={'unknown_law':diagnose(lambda p:{'CAL':0,'U1':2,'U2':7}[p]),
          'zero_budget':diagnose(lambda p:predicted((2,0),p),budget=0),
          'restricted_probe':diagnose(lambda p:predicted((2,0),p),probes=('U1',))}
(folder/'results.json').write_text(json.dumps({'cases':rows,'negative':negative},indent=2),encoding='utf-8')
summary={'known_cases':len(rows),'correct':sum(r['expected']==r['status'] for r in rows),
         'negative':{k:v['status'] for k,v in negative.items()}}
(folder/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print('ARTIFACT_DIR='+str(folder))
