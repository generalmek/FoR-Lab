import json
from fractions import Fraction
from pathlib import Path
root=Path(__file__).resolve().parent
run=root/'runs'/'decision-20261025T075241948239Z'
rows=json.loads((run/'episodes.json').read_text())
results={}
for p in ('decision','information'):
    rr=[x for x in rows if x['policy']==p]
    results[p]={'weighted_probe_cost':str(sum((sum((Fraction(x['costs'][q]) for q in x['probes']),Fraction()) for x in rr),Fraction())),
                'done':sum(x['phase']=='DONE' for x in rr)}
first={}
for x in rows:
    if x['mode']=='FoR' and x['policy']=='decision' and x['g']==1 and x['b']==0:
        k=(tuple(x['actions']),tuple(x['costs'].items()),x['penalty'])
        first.setdefault(k,[]).append((x['target'],x['probes'][0] if x['probes'] else 'HALT'))
results['goal_change_witnesses']=[{'actions':k[0],'costs':dict(k[1]),'penalty':k[2],'choices':v}
 for k,v in first.items() if len({p for _,p in v if p!='HALT'})>1]
(run/'analysis.json').write_text(json.dumps(results,indent=2),encoding='utf8')
print(json.dumps(results,indent=2))
