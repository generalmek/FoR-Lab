"""Post-run evaluator classification. Private truth never enters the policy."""
import json
import sys
from collections import Counter
from pathlib import Path
from basis_inquiry import Task,MODELS,US,predict,robust

path=Path(sys.argv[1])
rows=json.loads((path/'episodes.json').read_text(encoding='utf-8'))
counts=Counter()
for row in rows:
    task=Task(**row['task'])
    truth=tuple(row['truth'])
    if not any(predict(truth,task,u)==task.target for u in US):
        category='UNREACHABLE_TARGET_IN_ACTUAL_WORLD'
    elif robust(MODELS,task) is not None:
        category='ROBUST_WITHOUT_TEST'
    elif row['budget'] and any(robust(tuple(m for m in MODELS if m[i]==truth[i]),task) is not None for i in (0,1)):
        category='RESOLVABLE_WITH_ONE_TEST_FOR_THIS_TRUTH'
    else:
        category='UNRESOLVABLE_WITH_BUDGET'
    counts[(row['mode'],category)]+=1
report={mode:{category:n for (m,category),n in counts.items() if m==mode} for mode in ('FoR','B2','cue_only')}
(path/'evaluator-categories.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
