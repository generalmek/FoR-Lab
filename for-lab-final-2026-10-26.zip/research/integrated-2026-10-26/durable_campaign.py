"""Real process termination at receiver boundary; retained databases and receipts."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime,timezone
from durable_runtime import DurableRuntime,ReceiptWorkshop

def worker(directory,point):
    class CrashReceiver(ReceiptWorkshop):
        def apply_once(self,*args):
            if point=='before':os._exit(77)
            result=super().apply_once(*args)
            if point=='after':os._exit(77)
            return result
    r=DurableRuntime(directory/'agent.sqlite');w=CrashReceiver(directory/'world.sqlite')
    if r.state()['phase']=='IDLE':r.start_decision(2)
    result=r.run(w)
    revalidated=bool(r.db.execute("SELECT 1 FROM intents WHERE status='cancelled'").fetchone())
    print(json.dumps(dict(state=result,receipts=list(w.db.execute('SELECT * FROM receipts')),
                         intents=list(r.db.execute('SELECT * FROM intents')),revalidated=revalidated)))
    r.close();w.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--worker');p.add_argument('--point',default='none');a=p.parse_args()
    if a.worker:worker(Path(a.worker),a.point)
    else:
        root=Path(__file__).resolve().parent
        out=root/'runs'/datetime.now(timezone.utc).strftime('durable-%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
        rows=[]
        for point in ('before','after'):
            directory=out/point;directory.mkdir()
            cmd=[sys.executable,__file__,'--worker',str(directory)]
            crashed=subprocess.run(cmd+['--point',point],capture_output=True,text=True)
            resumed=subprocess.run(cmd,capture_output=True,text=True)
            repeated=subprocess.run(cmd,capture_output=True,text=True)
            (directory/'resume.txt').write_text(resumed.stdout+resumed.stderr,encoding='utf8')
            (directory/'repeat.txt').write_text(repeated.stdout+repeated.stderr,encoding='utf8')
            result=json.loads(resumed.stdout);again=json.loads(repeated.stdout)
            row=dict(point=point,crash_exit=crashed.returncode,resume_exit=resumed.returncode,
                     phase=result['state']['phase'],receipts=len(result['receipts']),
                     repeat_receipts=len(again['receipts']),budget=result['state']['budget'])
            rows.append(row)
            assert crashed.returncode==77 and resumed.returncode==repeated.returncode==0
            assert row['phase']=='DONE' and row['receipts']==row['repeat_receipts']==1
            assert result['state']==again['state']
        (out/'summary.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
        print(json.dumps(rows,indent=2));print('ARTIFACT_DIR='+str(out))
