"""Nine persistent queues, restart after every tick; evaluator-only world parameters."""
import json
from pathlib import Path
from datetime import datetime,timezone
from agenda_runtime import AgendaRuntime
from durable_runtime import ReceiptWorkshop

def main():
    root=Path(__file__).resolve().parent
    out=root/'runs'/datetime.now(timezone.utc).strftime('agenda-%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True)
    rows=[]
    for g in (1,2,3):
        for b in (-1,0,1):
            path=out/f'agent-{g}-{b}.sqlite';wp=out/f'world-{g}-{b}.sqlite'
            r=AgendaRuntime(path)
            for target in range(1,7):r.enqueue(str(target),target)
            r.close()
            for tick in range(100):
                r=AgendaRuntime(path);w=ReceiptWorkshop(wp,gain=g,bias=b)
                state=r.tick(w)
                r.close();w.close()
                if state.get('agenda')=='EMPTY':break
            else:raise AssertionError('queue failed to terminate')
            r=AgendaRuntime(path);w=ReceiptWorkshop(wp,gain=g,bias=b)
            receipts=[(json.loads(req),json.loads(res)) for req,res in w.db.execute('SELECT request,result FROM receipts')]
            for key,status in r.db.execute('SELECT id,status FROM agenda ORDER BY position'):
                target=int(key);effects=[res for req,res in receipts if req[1]==target]
                rows.append(dict(gain=g,bias=b,target=target,status=status,
                                 feasible=target in (g,2*g),effects=len(effects),
                                 evaluator_success=bool(effects) and all(e['physical']==target for e in effects),
                                 harm=sum(e['harm'] for e in effects)))
            r.close();w.close()
    summary=dict(tasks=len(rows),done=sum(r['status']=='DONE' for r in rows),
                 halted=sum(r['status']=='HALT' for r in rows),
                 evaluator_successes=sum(r['evaluator_success'] for r in rows),
                 harm=sum(r['harm'] for r in rows),duplicates=sum(max(0,r['effects']-1) for r in rows),
                 feasible=sum(r['feasible'] for r in rows))
    (out/'results.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2),encoding='utf-8')
    print(json.dumps(summary));print(out)
if __name__=='__main__':main()
