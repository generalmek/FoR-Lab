
"""Two-basis causal revision pilot; stdlib only. No learned procedures or LLM."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Decision:
    name: str
    terms: tuple[str, ...]
    target: int


@dataclass(frozen=True)
class Result:
    name: str
    predicted: int
    meets_target: bool
    recomputed: bool


class Knowledge:
    def __init__(self):
        self.values = {'heat': 2, 'pressure': 3}
        self.versions = {'heat': 0, 'pressure': 0}
        self.decisions = (
            Decision('heat_only', ('heat',), 2),
            Decision('pressure_only', ('pressure',), 3),
            Decision('combined', ('heat', 'pressure'), 5),
        )
        self.cache = {}

    def update(self, cause, value):
        if cause not in self.values:
            raise KeyError(cause)
        if self.values[cause] != value:
            self.values[cause] = value
            self.versions[cause] += 1

    def predict(self, decision):
        return sum(self.values[k] for k in decision.terms)

    def signature(self, decision):
        return tuple((k, self.versions[k]) for k in decision.terms)


class Agent:
    """FoR: dependency invalidation; B2: version-aware cache checks.

    Both see exactly the same Knowledge and pay one operation per recalculation.
    """
    def __init__(self, mode, knowledge, propagate=True):
        if mode not in ('FoR', 'B2'):
            raise ValueError(mode)
        self.mode, self.k, self.propagate = mode, knowledge, propagate
        self.calculations = 0
        self.signature_checks = 0
        self.invalidations = 0
        self.index_build_edges = 0
        self.dependents = {}
        for decision in self.k.decisions:
            for cause in decision.terms:
                self.dependents.setdefault(cause, set()).add(decision.name)
                self.index_build_edges += 1
        self.dirty = set()
        self.trace = []

    def evaluate(self):
        results = []
        for d in self.k.decisions:
            old = self.k.cache.get(d.name)
            invalid = old is None
            if old is not None:
                if self.mode == 'B2':
                    self.signature_checks += len(d.terms)
                    invalid = old[1] != self.k.signature(d)
                elif self.propagate:
                    invalid = d.name in self.dirty
                else:
                    invalid = False  # ablation: stale dependent forecast
            if invalid:
                value = self.k.predict(d)
                self.k.cache[d.name] = (value, self.k.signature(d))
                self.dirty.discard(d.name)
                self.calculations += 1
                self.trace.append(('RECOMPUTE', d.name))
            else:
                value = old[0]
            results.append(Result(d.name, value, value == d.target, invalid))
        return tuple(results)

    def incorporate_measurement(self, cause, measured):
        """Only actual observed evidence may trigger revision."""
        before = self.k.versions[cause]
        self.k.update(cause, measured)
        changed = self.k.versions[cause] != before
        self.trace.append(('MEASURE', cause, measured, changed))
        if changed and self.mode == 'FoR' and self.propagate:
            affected = self.dependents.get(cause, set())
            self.dirty.update(affected)
            self.invalidations += len(affected)
            self.trace.append(('INVALIDATE', cause, tuple(sorted(affected))))
        return changed


def experiment(mode, propagate=True, drift_observed=True):
    knowledge = Knowledge()
    agent = Agent(mode, knowledge, propagate)
    agent.evaluate()  # populate cache; same start conditions
    if drift_observed:
        agent.incorporate_measurement('heat', 4)
    # physical world is now heat=4, pressure=3 whether detected or not
    evaluations = agent.evaluate()
    actual = {'heat_only': 4, 'pressure_only': 3, 'combined': 7}
    wrong = tuple(r.name for r in evaluations if r.predicted != actual[r.name])
    return {'recomputed': tuple(r.name for r in evaluations if r.recomputed),
            'wrong': wrong, 'cost': agent.calculations,
            'cost_scope': 'prediction recomputations only; not runtime or total work',
            'signature_edge_checks': agent.signature_checks,
            'invalidation_visits': agent.invalidations,
            'index_build_edges': agent.index_build_edges,
            'trace': tuple(agent.trace)}


if __name__ == '__main__':
    for mode, propagate, observed in (
        ('FoR', True, True), ('B2', True, True),
        ('FoR', False, True), ('FoR', True, False)):
        print(mode, 'propagate=', propagate, 'observed=', observed,
              experiment(mode, propagate, observed))
