"""Integrated research-to-action development sequence, equal sensor contracts."""
import json
from datetime import datetime,timezone
from pathlib import Path
from method_runtime import MethodRuntime,normalize,compile_program
from durable_runtime import ReceiptWorkshop

def operations(kind,prefix='',extra_cost=0):
    vectors=([1,1,1],[1,2,4],[1,3,9],[1,4,16],[1,5,25]) if kind=='samples' else (
        [0,1,3],[0,1,5],[1,2,4],[1,4,16],[1,5,25])
    return [dict(name=prefix+str(i),vector=v,cost=(1 if i<2 else 2)+extra_cost) for i,v in enumerate(vectors)]

class SensorWorld:
    def __init__(self,ops,model,corrupt=None):self.ops={o['name']:o for o in ops};self.model=model;self.corrupt=corrupt
    def measure_operation(self,name):
        return sum(int(v)*m for v,m in zip(self.ops[name]['vector'],self.model))+(1 if name==self.corrupt else 0)

class ActionWorld(ReceiptWorkshop):
    def __init__(self,path,model):super().__init__(path,bias=model[0]);self.model=model
    def physical(self,u):return self.model[1]*u+self.model[2]*u*u

def main():
    out=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('methods-%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True);rows=[]
    policies={'method_cache':dict(use_method=True),'model_only':dict(use_method=False),
              'equal_tools_alternative':dict(use_method=True,solver='permutations')}
    for policy,options in policies.items():
        for case,initial in enumerate(((4,3,2),(-2,7,1),(0,5,3))):
            path=out/f'{policy}-{case}.sqlite'
            model=initial
            for stage in ('initial','renamed','different_sensors','changed_law','changed_cost','faulty_sensor'):
                kind='samples' if stage in ('initial','renamed') else 'differences'
                ops=operations(kind,prefix=stage,extra_cost=int(stage=='changed_cost'))
                if stage=='changed_law':model=(model[0],model[1],model[2]+2)
                bad=None
                if stage=='faulty_sensor':
                    canonical=normalize(ops);plan,_=compile_program(canonical);bad=canonical[plan['check']]['name']
                r=MethodRuntime(path,**options);r.start_research(ops,budget=20)
                sensor=SensorWorld(ops,model,bad)
                # Reopen runtime after each tick; no evaluator state is stored in agent DB.
                for _ in range(20):
                    s=r.step(sensor);r.close();r=MethodRuntime(path,**options)
                    if s['phase'] in ('DONE','HALT'):break
                else:raise AssertionError('research did not terminate')
                data=s['research'];correct=tuple(r.remembered() or ())==tuple(map(str,model))
                action_success=None;harm=0
                if s['phase']=='DONE':
                    w=ActionWorld(out/f'{policy}-{case}-{stage}-world.sqlite',model)
                    target=w.physical(2);r.start_decision(target,budget=3);r.run(w)
                    effects=[json.loads(x[0]) for x in w.db.execute('SELECT result FROM receipts')]
                    action_success=bool(effects) and all(x['physical']==target for x in effects)
                    harm=sum(x['harm'] for x in effects);w.close()
                rows.append(dict(policy=policy,case=case,stage=stage,research_status=s['phase'],
                                 model_correct=correct,action_success=action_success,harm=harm,
                                 cost=20-s['budget'],search_nodes=data['search_nodes'],cache_hit=data['cache_hit'],
                                 prior_refuted=data['prior_refuted'],observed=data['observed']))
                r.close()
    summary={p:dict(tasks=len(rr),completed=sum(x['research_status']=='DONE' for x in rr),
                    halted=sum(x['research_status']=='HALT' for x in rr),actions=sum(x['action_success'] is True for x in rr),
                    harm=sum(x['harm'] for x in rr),measurement_cost=sum(x['cost'] for x in rr),
                    search_nodes=sum(x['search_nodes'] for x in rr),cache_hits=sum(x['cache_hit'] for x in rr))
             for p in policies for rr in [[x for x in rows if x['policy']==p]]}
    (out/'results.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2),encoding='utf-8')
    print(json.dumps(summary));print(out)
if __name__=='__main__':main()
