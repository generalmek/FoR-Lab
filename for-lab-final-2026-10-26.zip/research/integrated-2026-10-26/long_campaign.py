"""Frozen before execution, but developer-generated, not independent blind testing."""
import hashlib
import json
import random
from datetime import datetime,timezone
from pathlib import Path
from method_runtime import MethodRuntime,normalize,compile_program
from method_campaign import SensorWorld,ActionWorld

def freeze(seed=271828,n=120):
    rng=random.Random(seed);tasks=[];model=[4,3,2]
    for i in range(n):
        if i%8==0:model=[rng.randint(-5,5),rng.randint(1,9),rng.randint(1,4)]
        kind=i%12
        if kind==10:vectors=[[0,j,j] for j in range(1,6)]
        elif i%3==0:vectors=[[1,u,u*u] for u in (1,2,3,4,5)]
        else:vectors=[[0,1,3],[0,1,5],[1,2,4],[1,4,16],[1,5,25]]
        ops=[dict(name=f'sensor_{i}_{j}',vector=v,cost=1+(j%2)) for j,v in enumerate(vectors)]
        if i%7==0:ops[-1]['cost']=rng.randint(2,4)
        tasks.append(dict(index=i,model=list(model),ops=ops,budget=1 if kind==11 else 20,
                          corruption=kind==9,rank_deficient=kind==10))
    return tasks

def main():
    out=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('long-%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True);tasks=freeze()
    raw=json.dumps(tasks,sort_keys=True,indent=2).encode()
    (out/'frozen_tasks.json').write_bytes(raw)
    (out/'protocol.json').write_text(json.dumps(dict(seed=271828,tasks=len(tasks),sha256=hashlib.sha256(raw).hexdigest(),
        status='developer-generated frozen sequence, NOT independent blind validation')))
    rows=[]
    policies={'method_cache':dict(use_method=True),'model_only':dict(use_method=False),
              'equal_tools_alternative':dict(use_method=True,solver='permutations')}
    for policy,options in policies.items():
        p=out/(policy+'.sqlite')
        for task in tasks:
            r=MethodRuntime(p,**options);r.start_research(task['ops'],task['budget'])
            bad=None
            if task['corruption']:
                ops=normalize(task['ops']);plan,_=compile_program(ops);bad=ops[plan['check']]['name']
            w=SensorWorld(task['ops'],task['model'],bad)
            for tick in range(20):
                s=r.step(w)
                if s['phase'] in ('DONE','HALT'):break
                if tick%2==0:r.close();r=MethodRuntime(p,**options)
            else:raise AssertionError('nontermination')
            data=s['research'];action_success=False;harm=0;action_status=None
            correct=tuple(r.remembered() or ())==tuple(map(str,task['model']))
            if s['phase']=='DONE':
                a=ActionWorld(out/f'{policy}-effects.sqlite',task['model'])
                count=a.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]
                target=a.physical(1+(task['index']%2));r.start_decision(target,budget=3);action=r.run(a)
                effects=[json.loads(x[0]) for x in a.db.execute('SELECT result FROM receipts ORDER BY rowid')][count:]
                action_success=bool(effects) and all(x['physical']==target for x in effects)
                harm=sum(x['harm'] for x in effects);action_status=action['phase'];a.close()
            rows.append(dict(policy=policy,index=task['index'],research_status=s['phase'],reason=s['reason'],
                correct_model=correct,action_success=action_success,action_status=action_status,harm=harm,
                measurement_cost=task['budget']-s['budget'],search_nodes=data['search_nodes'],
                cache_hit=data['cache_hit'],prior_refuted=data['prior_refuted'],
                negative_case=task['corruption'] or task['rank_deficient'] or task['budget']==1))
            r.close()
        print(policy,'finished',flush=True)
    summary={p:dict(tasks=len(rr),research_completed=sum(x['research_status']=='DONE' for x in rr),
        action_successes=sum(x['action_success'] for x in rr),harm=sum(x['harm'] for x in rr),
        clean_failures=sum(not x['action_success'] for x in rr if not x['negative_case']),
        negative_halts=sum(x['research_status']=='HALT' for x in rr if x['negative_case']),
        measurement_cost=sum(x['measurement_cost'] for x in rr),search_nodes=sum(x['search_nodes'] for x in rr),
        cache_hits=sum(x['cache_hit'] for x in rr)) for p in policies for rr in [[x for x in rows if x['policy']==p]]}
    (out/'results.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2),encoding='utf-8')
    print(json.dumps(summary));print(out)
if __name__=='__main__':main()
