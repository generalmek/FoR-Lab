"""Open development transfer series; no claim of independent held-out validation."""
import json
from pathlib import Path
from datetime import datetime,timezone
from learning_runtime import LearningRuntime
from durable_runtime import ReceiptWorkshop

def main():
    out=Path(__file__).resolve().parent/'runs'/datetime.now(timezone.utc).strftime('learning-%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True);rows=[]
    policies={'memory':dict(use_memory=True),'no_memory_full_check':dict(use_memory=False),
              'direct_no_memory':dict(use_memory=False,direct=True)}
    for policy,options in policies.items():
        for g in (4,7,11):
            for b in (-4,0,4):
                for action in (1,2):
                    for budget in (3,6):
                        name=f'{policy}-{g}-{b}-{action}-{budget}'
                        p=out/(name+'.sqlite');wp=out/(name+'-world.sqlite')
                        r=LearningRuntime(p,**options);w=ReceiptWorkshop(wp,gain=g,bias=b)
                        r.start_decision(g,budget=6);r.run(w)
                        train_probes=len(r.state()['evidence']);r.close()
                        r=LearningRuntime(p,**options);r.start_decision(g*action,budget=budget)
                        before=w.db.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]
                        state=r.run(w)
                        receipts=[json.loads(x[0]) for x in w.db.execute('SELECT result FROM receipts ORDER BY rowid')][before:]
                        rows.append(dict(policy=policy,gain=g,bias=b,target=g*action,budget=budget,
                                         training_probes=train_probes,probes=len(state['evidence']),
                                         status=state['phase'],success=bool(receipts) and all(x['physical']==g*action for x in receipts),
                                         harm=sum(x['harm'] for x in receipts),evidence=state['evidence']))
                        r.close();w.close()
    summary={p:{'episodes':len(rr),'successes':sum(r['success'] for r in rr),
                'probes':sum(r['probes'] for r in rr),'harm':sum(r['harm'] for r in rr),
                'budget3_successes':sum(r['success'] for r in rr if r['budget']==3)}
             for p in policies for rr in [[r for r in rows if r['policy']==p]]}
    (out/'results.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2),encoding='utf-8')
    print(json.dumps(summary));print(out)
if __name__=='__main__':main()
