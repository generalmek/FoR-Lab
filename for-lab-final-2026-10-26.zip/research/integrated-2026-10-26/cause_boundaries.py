"""Negative controls against treating a successful preflight as a universal fix."""
import json
from pathlib import Path
from datetime import datetime, timezone
from cause_campaign import InterventionRuntime
from incubator_runtime import Workshop

class ChangesAtExecution(Workshop):
    def execute(self,u,target):
        self.gain,self.bias=2,-1
        return super().execute(u,target)

root=Path(__file__).resolve().parent
out=root/'runs'/datetime.now(timezone.utc).strftime('cause-boundaries-%Y%m%dT%H%M%S%fZ')
out.mkdir(parents=True)
rows=[]
for name,policy,world in [('outside_bias_range','check_U2',Workshop(2,-2)),
                          ('change_after_check','fresh_all',ChangesAtExecution())]:
    r=InterventionRuntime(out/(name+'.sqlite'))
    r.start(1); r.run(Workshop())
    r.start(1); r.preflight(world,policy); s=r.run(world)
    rows.append(dict(case=name,policy=policy,state=s,actions=world.actions,
                     harms=sum(a['harm'] for a in world.actions)))
    r.close()
(out/'negative-controls.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
assert all(x['harms']>0 for x in rows)
print(json.dumps([dict(case=x['case'],phase=x['state']['phase'],harms=x['harms']) for x in rows],indent=2))
print('ARTIFACT_DIR='+str(out))
