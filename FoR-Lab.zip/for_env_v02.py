"""FoR Lab continuation: deterministic, partially observed diagnostic world.
This is a small synthetic engineering test, not a model of general reason.
"""
from dataclasses import dataclass
import random

ACTIONS = ('inspect_primary', 'inspect_reference', 'audit_provenance', 'repair_sensor', 'repair_process', 'abstain')
COST = {'inspect_primary': 1, 'inspect_reference': 2, 'audit_provenance': 2, 'repair_sensor': 2, 'repair_process': 2, 'abstain': 0}

@dataclass(frozen=True)
class Observation:
    symptom: str
    primary: str | None = None
    reference: str | None = None
    provenance: str | None = None
    budget_left: int = 0
    last_action: str | None = None

class DiagnosticWorld:
    """Hidden fault and reference provenance. No truth exposed in observations/info."""
    def __init__(self, seed=0, budget=7, scenario=None):
        self.seed, self.initial_budget, self.scenario = seed, budget, scenario
        self.reset()

    def reset(self):
        self.rng = random.Random(self.seed)
        self._fault = self.rng.choice(('sensor', 'process'))
        self._shared = self.rng.choice((False, True)) if self.scenario is None else self.scenario == 'shared'
        self.budget = self.initial_budget
        self.done = False
        self.history = []
        return Observation('abnormal_reading', budget_left=self.budget)

    def step(self, action):
        if self.done:
            raise RuntimeError('Episode completed; call reset()')
        if action not in ACTIONS:
            raise ValueError('Unknown action')
        cost = COST[action]
        if cost > self.budget:
            raise ValueError('Insufficient budget')
        self.budget -= cost
        self.history.append((action, cost))
        kw = {'symptom': 'abnormal_reading', 'budget_left': self.budget, 'last_action': action}
        if action == 'inspect_primary':
            kw['primary'] = 'abnormal'  # same under both causes
        elif action == 'inspect_reference':
            # Shared calibration makes the reference misleading for sensor faults.
            kw['reference'] = 'abnormal' if self._fault == 'process' or self._shared else 'normal'
        elif action == 'audit_provenance':
            kw['provenance'] = 'shared' if self._shared else 'independent'
        elif action in ('repair_sensor', 'repair_process'):
            matched = action == 'repair_' + self._fault
            self.done = True
            kw['symptom'] = 'restored' if matched else 'still_abnormal'
            return Observation(**kw), -(cost + (0 if matched else 10)), True, {}
        elif action == 'abstain':
            self.done = True
        return Observation(**kw), -cost, self.done, {}

    def evaluator_truth(self):
        """Evaluator-only: never pass this to an agent."""
        return {'fault': self._fault, 'shared': self._shared}
