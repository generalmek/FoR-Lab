@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B "research\integrated-2026-10-23\run_integrated.py"
if errorlevel 1 echo TESTS FAILED - inspect saved logs.
pause
