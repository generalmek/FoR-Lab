@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B "research\audit-0.3a-2026-10-23\run_checks.py"
if errorlevel 1 echo AUDIT FAILED - inspect saved test logs.
pause
