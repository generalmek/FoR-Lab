"""FoR-Lab 0.3: explicit limited B2/T demonstration on the SAME finite hypothesis engine.
Not a proof of FoR, not general intelligence, not a preregistered comparison.
"""
from dataclasses import dataclass, asdict
from functools import lru_cache
from collections import Counter
from pathlib import Path
import hashlib, json, sys, time
from for_env_v02 import DiagnosticWorld, COST
from inquiry_core import HYPOTHESES, predict, filter_models

TESTS = ('inspect_primary','inspect_reference','audit_provenance')
REPAIRS = ('repair_sensor','repair_process')

@dataclass
class Counters:
    prediction_calls: int = 0
    search_nodes: int = 0
    max_depth: int = 0


def optimal_plan(models, budget, used=(), horizon=3, counters=None):
    """Exact finite-horizon expected-loss policy, uniform posterior over compatible models.
    Diagnostic tests and repair actions are evaluated with same cost model for B2/T.
    A failed repair has cost 12; success 2. Abstain costs 9 (experimental design choice).
    """
    c = counters if counters is not None else Counters()
    cache={}
    def solve(ms, cash, spent, depth):
        c.search_nodes+=1; c.max_depth=max(c.max_depth,depth)
        key=(ms,cash,spent,depth)
        if key in cache: return cache[key]
        if not ms: raise ValueError('empty posterior')
        options=[(9.0,'abstain')]
        for a in REPAIRS:
            expected=sum(2 if a=='repair_'+m.fault else 12 for m in ms)/len(ms)
            if COST[a]<=cash: options.append((expected,a))
        if depth>0:
            for a in TESTS:
                if a in spent or COST[a]>cash:continue
                outcomes={}
                for m in ms:
                    c.prediction_calls+=1
                    outcomes.setdefault(predict(m,a),[]).append(m)
                expected=COST[a]
                for subset in outcomes.values():
                    value,_=solve(tuple(subset),cash-COST[a],tuple(sorted(spent+(a,))),depth-1)
                    expected+=len(subset)/len(ms)*value
                options.append((expected,a))
        result=min(options,key=lambda x:(round(x[0],10),x[1])); cache[key]=result
        return result
    return solve(tuple(models),budget,tuple(sorted(used)),horizon)


def run_agent(kind='B2',seed=1,scenario='independent',budget=7,horizon=3, log_path=None):
    if kind not in ('B2','T'):raise ValueError(kind)
    env=DiagnosticWorld(seed=seed, scenario=scenario, budget=budget)
    obs=env.reset()
    models=tuple(HYPOTHESES); used=[]; trace=[]; counters=Counters()
    basis_version=0; dependent_decisions=['repair_sensor','repair_process']
    status='STEP_LIMIT'; evidence_sufficient=False
    for step_num in range(8):
        if not models:
            status='MODEL_CLASS_INADEQUATE'; break
        repairs={'repair_'+m.fault for m in models}
        significant=len(repairs)>1
        choice_value, action=optimal_plan(models,env.budget,tuple(used),horizon,counters)
        event={'step':step_num,'controller':kind,'observation':asdict(obs),
               'models':len(models),'budget':env.budget,'action':action,
               'expected_total_loss':round(choice_value,6),'decision_disagreement':significant}
        if kind=='T':
            event['foundation_gap']={'status':'CANDIDATE' if significant else 'NO_DECISION_DISAGREEMENT',
                                      'dependent_decisions':dependent_decisions if significant else [],
                                      'basis_version':basis_version}
            if action in TESTS:
                groups={}
                for m in models:groups.setdefault(predict(m,action),set()).add(m.fault)
                event['required_distinction']={'test':action,'possible_outcomes':sorted(groups),
                                                'outcome_fault_options':{k:sorted(v) for k,v in groups.items()}}
        trace.append(event)
        if action=='abstain':
            # Keeping stop cause distinct from evidence sufficiency.
            affordable_unused=[a for a in TESTS if a not in used and COST[a]<=env.budget]
            status='NO_POSITIVE_VALUE' if affordable_unused else 'BUDGET_EXHAUSTED'
            evidence_sufficient=False; event['stop_reason']='abstain selected under declared loss model'
            break
        previous=models
        obs,reward,done,info=env.step(action)
        if info:raise AssertionError('unexpected environment metadata')
        event['realized_reward']=reward
        event['result_observation']=asdict(obs)
        if action in TESTS:
            value=getattr(obs,{'inspect_primary':'primary','inspect_reference':'reference','audit_provenance':'provenance'}[action])
            models=filter_models(models,action,value); used.append(action)
            event['evidence']={'action':action,'value':value,'source':'selected_environment_action'}
            event['belief_update']={'from':len(previous),'to':len(models)}
            if kind=='T':
                basis_version+=1
                event['revision_transaction']={'old_version':basis_version-1,'new_version':basis_version,
                       'evidence_ref':step_num, 'commit':bool(models),
                       'invalidated_decisions':dependent_decisions if len(models)!=len(previous) else []}
            continue
        status='RESOLVED' if obs.symptom=='restored' else 'FAILED_REPAIR'
        # Physical repair success is separate from epistemic sufficiency.
        evidence_sufficient=len(repairs)==1
        break
    else:status='STEP_LIMIT'
    payload={'schema':'for-lab-v0.3','kind':kind,'seed':seed,'scenario_label_for_evaluator_only':scenario,
       'budget_initial':budget,'horizon':horizon,'status':status,
       'epistemic_sufficiency':evidence_sufficient,'gap_open':not evidence_sufficient,
       'counters':asdict(counters),'actions':[e['action'] for e in trace],
       'trace':trace,'scope':'bounded model / same policy substrate; T tracing NOT proven advantage'}
    if log_path:
        p=Path(log_path);p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    return payload


def run_suite(out_dir='logs',seeds=range(12)):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    trials=[]
    for scenario in ('independent','shared'):
        for seed in seeds:
            for agent in ('B2','T'):
                result=run_agent(agent,seed,scenario,7,3)
                trials.append(result)
                (out/f'v03_{scenario}_{seed}_{agent}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    paired=[]
    for scenario in ('independent','shared'):
        for seed in seeds:
            b=next(t for t in trials if t['kind']=='B2' and t['seed']==seed and t['scenario_label_for_evaluator_only']==scenario)
            t=next(t for t in trials if t['kind']=='T' and t['seed']==seed and t['scenario_label_for_evaluator_only']==scenario)
            paired.append({'scenario':scenario,'seed':seed,'actions_equal':b['actions']==t['actions'],
                           'statuses_equal':b['status']==t['status']})
    summary={'version':'0.3','executed_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
             'episodes':len(trials),'pairs':len(paired),'matching_action_traces':sum(p['actions_equal'] for p in paired),
             'matching_statuses':sum(p['statuses_equal'] for p in paired),
             'status_counts':dict(Counter((t['kind'],t['status']) for t in trials)),
             'evidence_level':'engineering smoke/integration tests only',
             'note':'B2 and T intentionally share optimal planner; T logging does not establish advantage.'}
    summary['status_counts']={f'{k[0]}:{k[1]}':v for k,v in Counter((t['kind'],t['status']) for t in trials).items()}
    (out/'v03_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    # Append-only human research note for this actual run (not a claim about prior user runs).
    with (out/'research_runs.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(summary,ensure_ascii=False)+'\n')
    return summary

if __name__=='__main__':
    print(json.dumps(run_suite(),ensure_ascii=False,indent=2))
