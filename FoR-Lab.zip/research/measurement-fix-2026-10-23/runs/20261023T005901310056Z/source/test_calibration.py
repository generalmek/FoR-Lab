import unittest,tempfile
from pathlib import Path
from calibration import *

class Tests(unittest.TestCase):
    def test_old_failure_fixed(self):
        r=Calibrator().run(World().api());self.assertEqual(r['estimate'],2)
        self.assertEqual(r['model'],'affine');self.assertTrue(r['validated'])
    def test_affine_grid_and_baseline(self):
        for a in (-3,0.5,1,2):
            for b in (-2,0,4):
                for x in (0.25,1.5,2):
                    r=Calibrator().run(World(x=x,scale=a,bias=b).api())
                    q=baseline(World(x=x,scale=a,bias=b).api())
                    self.assertAlmostEqual(r['estimate'],x);self.assertAlmostEqual(q['estimate'],x)
    def test_simple_model_selected(self):
        self.assertEqual(Calibrator().run(World(scale=1).api())['model'],'identity')
        self.assertEqual(Calibrator().run(World(scale=1,bias=2).api())['model'],'offset')
    def test_nonlinearity_rejected_before_object(self):
        w=World(curve=1);r=Calibrator().run(w.api())
        self.assertEqual(r['status'],'MODEL_CLASS_INADEQUATE');self.assertEqual(len(w.log),3)
        self.assertFalse(any(e['kind']=='object' for e in w.log))
    def test_budget_missing_and_unidentifiable(self):
        for args,status in [(dict(budget=3),'BUDGET_EXHAUSTED'),(dict(scale=0),'UNIDENTIFIABLE'),(dict(refs=(0,1)),'INSUFFICIENT_REFERENCES')]:
            self.assertEqual(Calibrator().run(World(**args).api())['status'],status)
    def test_saved_scheme_reestimates_parameters(self):
        a=Calibrator();a.run(World().api())
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as d:
            a.save(Path(d)/'a.json');a=Calibrator.load(Path(d)/'a.json')
        self.assertEqual(a.run(World(x=1.5,scale=-3,bias=7).api())['estimate'],1.5)
    def test_ablation_and_undetectable_counterexample(self):
        r=Calibrator().run(World(curve=1).api(),validate=False)
        self.assertNotEqual(r['estimate'],2)
        r=Calibrator().run(World(spoof=1).api())
        self.assertEqual(r['status'],'READY');self.assertNotEqual(r['estimate'],2)
    def test_invalid_action_does_not_spend_budget(self):
        w=World()
        with self.assertRaises(ValueError):w.query('invalid')
        self.assertEqual(w.remaining,4)

if __name__=='__main__':unittest.main()
