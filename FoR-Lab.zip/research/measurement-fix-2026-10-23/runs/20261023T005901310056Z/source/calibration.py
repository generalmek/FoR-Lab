import json
from pathlib import Path

class BudgetExceeded(Exception):pass

class IO:
    __slots__=('query','available')
    def __init__(self,query,available):self.query=query;self.available=available

class World:
    def __init__(self,x=2,scale=2,bias=0,curve=0,spoof=0,budget=4,refs=(0,1,3)):
        self.x=x;self.scale=scale;self.bias=bias;self.curve=curve;self.spoof=spoof
        self.remaining=budget;self.refs=refs;self.log=[]
    def sensor(self,x):return self.scale*x+self.bias+self.curve*x*x+self.spoof*x*(x-1)*(x-3)
    def query(self,kind,value=None):
        if kind not in ('reference','object'):raise ValueError('unknown action')
        if kind=='reference' and value not in self.refs:raise ValueError('unavailable reference')
        if self.remaining<1:raise BudgetExceeded()
        self.remaining-=1;y=self.sensor(value if kind=='reference' else self.x)
        self.log.append({'kind':kind,'reference':value,'observed':y,'cost':1});return y
    def api(self):return IO(self.query,tuple(self.refs))

class Calibrator:
    def __init__(self):self.method='select_then_validate';self.history=[]
    def save(self,path):Path(path).write_text(json.dumps({'method':self.method,'history':self.history}),encoding='utf-8')
    @classmethod
    def load(cls,path):
        data=json.loads(Path(path).read_text(encoding='utf-8'));obj=cls();obj.method=data['method'];obj.history=data['history'];return obj
    def run(self,api,validate=True):
        if not isinstance(api,IO):raise TypeError('IO required')
        trace=[]
        def done(status,**extra):return {'status':status,'trace':trace,**extra}
        if any(r not in api.available for r in (0,1,3)):return done('INSUFFICIENT_REFERENCES')
        try:
            y0=api.query('reference',0);y1=api.query('reference',1)
            candidates=[('identity',1.,0.),('offset',1.,y0),('affine',y1-y0,y0)]
            fits=[m for m in candidates if abs(m[2]-y0)<1e-9 and abs(m[1]+m[2]-y1)<1e-9]
            name,a,b=fits[0];trace.append({'selected_before_validation':name,'scale':a,'bias':b,'fit_points':[0,1]})
            if abs(a)<1e-9:return done('UNIDENTIFIABLE')
            if validate:
                y3=api.query('reference',3);residual=abs(a*3+b-y3)
                trace.append({'held_out_reference':3,'residual':residual})
                if residual>1e-9:return done('MODEL_CLASS_INADEQUATE')
            y=api.query('object');estimate=(y-b)/a
            self.history.append({'model':name,'scale':a,'bias':b,'validated':validate})
            return done('READY',estimate=estimate,model=name,validated=validate)
        except BudgetExceeded:return done('BUDGET_EXHAUSTED')

def baseline(api):
    if any(r not in api.available for r in (0,1,3)):return {'status':'INSUFFICIENT_REFERENCES'}
    try:
        zero=api.query('reference',0);one=api.query('reference',1)
        span=one-zero
        if abs(span)<1e-9:return {'status':'UNIDENTIFIABLE'}
        check=api.query('reference',3)
        if abs((check-zero)/span-3)>1e-9:return {'status':'MODEL_CLASS_INADEQUATE'}
        return {'status':'READY','estimate':(api.query('object')-zero)/span}
    except BudgetExceeded:return {'status':'BUDGET_EXHAUSTED'}

def experiments(folder):
    rows=[];agent=Calibrator()
    cases=[('old_failure',dict()),('offset',dict(scale=1,bias=4,x=2)),
           ('transfer',dict(scale=-3,bias=7,x=1.5)),('nonlinear',dict(curve=1)),
           ('zero_sensitivity',dict(scale=0)),('budget',dict(budget=3)),
           ('missing_reference',dict(refs=(0,1))),('undetectable_on_refs',dict(spoof=1))]
    for name,args in cases:
        w=World(**args);r=agent.run(w.api());bworld=World(**args);b=baseline(bworld.api())
        agent.save(Path(folder)/'method.json');agent=Calibrator.load(Path(folder)/'method.json')
        rows.append({'case':name,'T':r,'B2':b,'T_error':abs(r['estimate']-w.x) if r['status']=='READY' else None,
                     'B2_error':abs(b['estimate']-w.x) if b['status']=='READY' else None,'observations':w.log,'B2_observations':bworld.log})
    w=World(curve=1);r=Calibrator().run(w.api(),validate=False)
    rows.append({'case':'validation_disabled','T':r,'T_error':abs(r['estimate']-w.x),'observations':w.log})
    return rows
