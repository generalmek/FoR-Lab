"""Open bounded polynomial expansion control. Not discovery of arbitrary causes."""
import itertools, json
import numpy as np

THRESHOLD=0.05  # fixed engineering MSE tolerance, not a statistical significance test

def matrix(points, powers):
    return np.array([[x**a*z**b for a,b in powers] for x,z in points],dtype=float)

def expand(train_x,train_y,valid_x,valid_y,enabled=True):
    # A general polynomial grammar generates monomials; no scenario label is input.
    pool=[(a,b) for a in range(3) for b in range(3) if 0<a+b<=2]
    initial=((0,0),(1,0))
    coeff=np.linalg.lstsq(matrix(train_x,initial),train_y,rcond=None)[0]
    mse=float(np.mean((matrix(valid_x,initial)@coeff-valid_y)**2))
    trace=[{'basis':initial,'validation_mse':mse}]
    if mse<=THRESHOLD:return {'status':'REFIT_WITHIN_CLASS','basis':initial,'mse':mse,'trace':trace}
    if not enabled:return {'status':'GAP_OPEN','mse':mse,'trace':trace}
    for count in range(1,4):
        candidates=[]
        for terms in itertools.combinations(pool,count):
            basis=((0,0),)+terms
            A=matrix(train_x,basis)
            if np.linalg.matrix_rank(A)<len(basis):continue
            w=np.linalg.lstsq(A,train_y,rcond=None)[0]
            error=float(np.mean((matrix(valid_x,basis)@w-valid_y)**2))
            trace.append({'basis':basis,'validation_mse':error})
            if error<=THRESHOLD:candidates.append((error,basis))
        if candidates:
            error,basis=min(candidates)
            return {'status':'BOUNDED_CLASS_EXPANDED','basis':basis,'mse':error,'trace':trace}
    return {'status':'GAP_OPEN','mse':mse,'trace':trace}

def datasets():
    train=list(itertools.product((-2.,-1.,1.,2.),repeat=2))
    valid=list(itertools.product((-1.5,-.5,.5,1.5),repeat=2))
    for name in ('known','parameter_drift','interaction','noise'):
        def values(points):
            result=[]
            for i,(x,z) in enumerate(points):
                value=x if name in ('known','noise') else 1.7*x if name=='parameter_drift' else x*z
                result.append(value + (0.8*(-1)**i if name=='noise' else 0))
            return np.array(result)
        yield name,train,values(train),valid,values(valid)

def experiment():
    rows=[]
    for name,tx,ty,vx,vy in datasets():
        before=float(np.mean((np.array([x for x,z in vx])-vy)**2))
        for enabled in (False,True):
            chosen=expand(tx,ty,vx,vy,enabled)
            # Third set is consumed only AFTER model selection; never passed to expand.
            hold=list(itertools.product((-3.,-.25,.75,3.),repeat=2))
            hold_mse=None
            if 'basis' in chosen and name!='noise':
                w=np.linalg.lstsq(matrix(tx,chosen['basis']),ty,rcond=None)[0]
                target=np.array([x if name=='known' else 1.7*x if name=='parameter_drift' else x*z for x,z in hold])
                hold_mse=float(np.mean((matrix(hold,chosen['basis'])@w-target)**2))
            rows.append({'evaluator_case':name,'expansion_enabled':enabled,
                         'frozen_model_mse':before,'result':chosen,
                         'post_selection_holdout_mse':hold_mse,
                         'holdout_scope':'open deterministic points, includes extrapolation; not blinded confirmatory study'})
    return rows

if __name__=='__main__':print(json.dumps(experiment(),indent=2))
