"""Audited finite pilot; API separation is NOT a security sandbox."""
from dataclasses import dataclass, asdict
from itertools import product
import json

TESTS=('read_a','read_b')
MODELS=tuple(product((0,1),repeat=2))
COST={'read_a':1,'read_b':1,'repair_0':2,'repair_1':2,'abstain':0}
ABSTAIN_LOSS=9

def outcome(model, action):
    return model[TESTS.index(action)]

def terminal_loss(model, action):
    if action=='abstain':return ABSTAIN_LOSS
    return 2 if int(action[-1])==(model[0]^model[1]) else 12

@dataclass(frozen=True)
class Observation:
    budget_left:int
    outcome:int|None=None
    restored:bool|None=None

class World:
    def __init__(self,model,budget=4):
        if model not in MODELS:raise ValueError('model')
        self._model=model;self.initial=budget
        self.reset()
    def reset(self):
        self.budget=self.initial;self.done=False;self.actions=[]
        return Observation(self.budget)
    def step(self,action):
        if self.done:raise RuntimeError('terminal')
        if action not in COST:raise ValueError('action')
        if COST[action]>self.budget:raise ValueError('budget')
        self.budget-=COST[action];self.actions.append(action)
        if action in TESTS:
            return Observation(self.budget,outcome(self._model,action)),-COST[action],False
        self.done=True;loss=terminal_loss(self._model,action)
        return Observation(self.budget,restored=None if action=='abstain' else loss==2),-loss,True

class Operations:
    def __init__(self):self.predictions=0;self.nodes=0
    def predict(self,m,a):
        self.predictions+=1
        return outcome(m,a)

class Agent:
    # No constructor access to world, seed, scenario, evaluator logs or hidden cause.
    def __init__(self,kind='B2',horizon=3,dummy_calls=0):
        if kind not in ('B2','T'):raise ValueError(kind)
        self.kind=kind;self.horizon=horizon;self.dummy_calls=dummy_calls
        self.models=MODELS;self.used=();self.ops=Operations();self.trace=[]
    def plan(self,budget):
        def solve(ms,cash,used,depth):
            self.ops.nodes+=1
            options=[(ABSTAIN_LOSS,'abstain')]
            for a in ('repair_0','repair_1'):
                if COST[a]<=cash:options.append((sum(terminal_loss(m,a) for m in ms)/len(ms),a))
            if depth:
                for a in TESTS:
                    if a in used or COST[a]>cash:continue
                    groups={}
                    for m in ms:groups.setdefault(self.ops.predict(m,a),[]).append(m)
                    value=COST[a]+sum(len(sub)/len(ms)*solve(tuple(sub),cash-COST[a],used+(a,),depth-1)[0] for sub in groups.values())
                    options.append((value,a))
            return min(options)
        return solve(self.models,budget,self.used,self.horizon)
    def act(self,obs):
        value,action=self.plan(obs.budget_left)
        for _ in range(self.dummy_calls):self.ops.predict(self.models[0],TESTS[0])
        row={'action':action,'expected_loss':value,'model_count':len(self.models)}
        if self.kind=='T':
            row['gap_open']=len({m[0]^m[1] for m in self.models})>1
            if action in TESTS:
                row['predictions']=[self.ops.predict(m,action) for m in self.models]
        self.trace.append(row)
        return action
    def observe(self,action,obs,reward,done):
        if action in TESTS:
            self.models=tuple(m for m in self.models if self.ops.predict(m,action)==obs.outcome)
            self.used+= (action,)
        self.trace[-1]['reward']=reward

def run(model,kind='B2',horizon=3,budget=4,dummy_calls=0):
    env=World(model,budget);agent=Agent(kind,horizon,dummy_calls);obs=env.reset();loss=0
    while not env.done:
        action=agent.act(obs)
        obs,reward,done=env.step(action);loss-=reward
        agent.observe(action,obs,reward,done)
    return {'loss':loss,'actions':env.actions,'restored':obs.restored,
            'counts':{'prediction_calls':agent.ops.predictions,'search_nodes':agent.ops.nodes},
            'agent_trace':agent.trace,'scope':'finite XOR chain diagnostic fixture; T logging only'}

if __name__=='__main__':
    print(json.dumps([{'model_for_evaluator':m,'H1':run(m,horizon=1),'H3':run(m,horizon=3)} for m in MODELS],indent=2))
