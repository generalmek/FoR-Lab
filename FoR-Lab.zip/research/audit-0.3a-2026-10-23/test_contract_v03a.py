import unittest
from contract_v03a import *

class ContractTests(unittest.TestCase):
    def test_chain_has_strict_value_and_changes_action(self):
        shallow=[run(m,horizon=1) for m in MODELS]
        deep=[run(m,horizon=3) for m in MODELS]
        self.assertEqual(sum(r['loss'] for r in shallow)/4,7)
        self.assertEqual(sum(r['loss'] for r in deep)/4,4)
        self.assertNotEqual(shallow[0]['actions'][0],deep[0]['actions'][0])
        self.assertTrue(all(r['restored'] for r in deep))
    def test_forecast_matches_exhaustive_mean(self):
        for h in range(4):
            for cash in range(7):
                value,_=Agent(horizon=h).plan(cash)
                actual=sum(run(m,horizon=h,budget=cash)['loss'] for m in MODELS)/4
                self.assertAlmostEqual(value,actual)
    def test_abstain_really_terminates_and_costs_nine(self):
        for m in MODELS:
            r=run(m,budget=0)
            self.assertEqual(r['actions'],['abstain']);self.assertEqual(r['loss'],9)
            w=World(m,0);_,reward,done=w.step('abstain')
            self.assertEqual(reward,-9);self.assertTrue(done)
            with self.assertRaises(RuntimeError):w.step('abstain')
    def test_counter_detects_dummy_and_T_work(self):
        b=run(MODELS[0]);t=run(MODELS[0],'T');d=run(MODELS[0],dummy_calls=5)
        self.assertEqual(b['actions'],t['actions'])
        self.assertEqual(d['counts']['prediction_calls']-b['counts']['prediction_calls'],5*len(b['actions']))
        self.assertGreater(t['counts']['prediction_calls'],b['counts']['prediction_calls'])
    def test_repeat_and_order(self):
        first={m:run(m) for m in MODELS}
        second={m:run(m) for m in reversed(MODELS)}
        self.assertEqual(first,second)
    def test_public_observations_same_before_measurement(self):
        observations=[World(m).reset() for m in MODELS]
        self.assertTrue(all(o==observations[0] for o in observations))
        self.assertEqual(set(asdict(observations[0])),{'budget_left','outcome','restored'})
        # All constant initial decisions can solve only half this balanced fixture.
        self.assertEqual(max(sum(terminal_loss(m,a)==2 for m in MODELS) for a in ('repair_0','repair_1')),2)
    def test_reject_without_mutation_and_reset(self):
        w=World(MODELS[0],0)
        with self.assertRaises(ValueError):w.step('read_a')
        self.assertEqual(w.actions,[]);self.assertEqual(w.budget,0)
        w.step('abstain');w.reset();self.assertFalse(w.done)
    def test_all_budget_kind_combinations(self):
        for m in MODELS:
            for cash in range(7):
                b=run(m,budget=cash);t=run(m,'T',budget=cash)
                self.assertEqual(b['actions'],t['actions']);self.assertEqual(b['loss'],t['loss'])
if __name__=='__main__':unittest.main(verbosity=2)
