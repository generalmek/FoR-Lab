"""Open engineering audit. Not a held-out scientific experiment."""
import sys, json, random, itertools, tempfile, unittest
from pathlib import Path
from datetime import datetime, timezone
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'baseline'))
import for_agents_v03 as agents
from inquiry_core import HYPOTHESES
from for_env_v02 import DiagnosticWorld

def main():
    out = ROOT / 'runs' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out.mkdir(parents=True)
    temp = out / 'tmp'; temp.mkdir()
    tempfile.tempdir = str(temp)
    with (out / 'regression.txt').open('w', encoding='utf-8') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT/'baseline')))
    grid=[]
    for scenario, seed, budget, horizon in itertools.product(('independent','shared'),range(16),range(9),range(4)):
        b=agents.run_agent('B2',seed,scenario,budget,horizon)
        t=agents.run_agent('T',seed,scenario,budget,horizon)
        grid.append(dict(scenario=scenario,seed=seed,budget=budget,horizon=horizon,
                         actions=b['actions'],status=b['status'],sufficient=b['epistemic_sufficiency'],
                         equal=b['actions']==t['actions'] and b['status']==t['status']))
    (out/'grid.json').write_text(json.dumps(grid,indent=2),encoding='utf-8')
    horizon_results=[dict(horizon=h,value=agents.optimal_plan(HYPOTHESES,7,horizon=h)) for h in range(4)]
    # Exhaust all nonempty finite posterior subsets and budgets, not just random seeds.
    gains=[]
    for mask in range(1,16):
        models=tuple(m for i,m in enumerate(HYPOTHESES) if mask & (1<<i))
        for budget in range(9):
            v1,a1=agents.optimal_plan(models,budget,horizon=1)
            v3,a3=agents.optimal_plan(models,budget,horizon=3)
            if v3 < v1-1e-9:gains.append(dict(mask=mask,budget=budget,v1=v1,v3=v3,a1=a1,a3=a3))
    # Deliberately prohibited seed policy: demonstrates why seed must be evaluator-only.
    cheat=0; worlds=set()
    for seed in range(256):
        env=DiagnosticWorld(seed); truth=env.evaluator_truth()
        worlds.add((truth['fault'],truth['shared']))
        action='repair_'+random.Random(seed).choice(('sensor','process'))
        obs,_,_,_=env.step(action); cheat+=obs.symptom=='restored'
    actual={}
    original=agents.predict
    def counted(*args):
        actual['calls']+=1
        return original(*args)
    agents.predict=counted
    counts={}
    try:
        for kind in ('B2','T'):
            actual['calls']=0
            run=agents.run_agent(kind,1,'independent')
            counts[kind]={'observed_calls_in_agent_module':actual['calls'],'reported_calls':run['counters']['prediction_calls']}
    finally: agents.predict=original
    env=DiagnosticWorld(); _,reward,done,_=env.step('abstain')
    summary=dict(scope='open finite engineering audit, NOT theory confirmation',
       regression={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)},
       pairs=len(grid),matching_pairs=sum(r['equal'] for r in grid),unique_worlds=len(worlds),
       seed_cheater={'correct':cheat,'total':256,'access':'prohibited evaluator seed; interface threat demonstration, not evidence current policy cheats'},
       horizon_results=horizon_results,strict_lookahead_improvements=gains,predict_counts=counts,
       abstain={'planner_loss':9,'environment_loss':-reward,'terminal':done},
       limits=['same policy B2/T','four fixed worlds','not process-isolated','prediction instrumentation excludes filter_models imported binding'])
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (ROOT/'research_runs.jsonl').open('a',encoding='utf-8') as f:
        f.write(json.dumps({'time':out.name,'summary':summary})+'\n')
    print(json.dumps({'output':str(out),'summary':summary},indent=2))
    return summary
if __name__=='__main__':main()
