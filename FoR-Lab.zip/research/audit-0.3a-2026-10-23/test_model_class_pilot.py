import unittest
from model_class_pilot import *

class ExpansionTests(unittest.TestCase):
    def test_post_selection_holdout(self):
        for row in experiment():
            if row['post_selection_holdout_mse'] is not None:
                self.assertLess(row['post_selection_holdout_mse'],1e-20)
    def test_outside_grammar_stays_open(self):
        _,tx,_,vx,_=next(datasets())
        result=expand(tx,np.array([x**3 for x,z in tx]),vx,np.array([x**3 for x,z in vx]))
        self.assertEqual(result['status'],'GAP_OPEN')
    def test_controls_and_ablation(self):
        rows={(r['evaluator_case'],r['expansion_enabled']):r for r in experiment()}
        for enabled in (False,True):
            for name in ('known','parameter_drift'):
                self.assertEqual(rows[name,enabled]['result']['status'],'REFIT_WITHIN_CLASS')
            self.assertEqual(rows['noise',enabled]['result']['status'],'GAP_OPEN')
        self.assertEqual(rows['interaction',False]['result']['status'],'GAP_OPEN')
        self.assertEqual(rows['interaction',True]['result']['status'],'BOUNDED_CLASS_EXPANDED')
        self.assertEqual(tuple(rows['interaction',True]['result']['basis']),((0,0),(1,1)))
    def test_held_points_distinct(self):
        for _,tx,ty,vx,vy in datasets():self.assertFalse(set(tx)&set(vx))
    def test_order_invariance(self):
        for _,tx,ty,vx,vy in datasets():
            a=expand(tx,ty,vx,vy);b=expand(tx[::-1],ty[::-1],vx[::-1],vy[::-1])
            self.assertEqual(a['status'],b['status']);self.assertAlmostEqual(a['mse'],b['mse'])
if __name__=='__main__':unittest.main(verbosity=2)
