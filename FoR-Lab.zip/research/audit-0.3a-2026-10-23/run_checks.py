"""Reproducible audit entry point, unique run folders and append-only index."""
import json, hashlib, sys, unittest
from pathlib import Path
from datetime import datetime, timezone
import audit_v03
from contract_v03a import MODELS, run
from model_class_pilot import experiment

ROOT=Path(__file__).resolve().parent
def main():
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out=ROOT/'runs'/('contract_'+stamp);out.mkdir(parents=True)
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
              for p in list(ROOT.glob('*.py'))+list((ROOT/'baseline').glob('*.py'))}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (out/'before.json').write_text(json.dumps({'phase':'open engineering control, not preregistration',
        'expected':'H1 mean loss7, H3 mean loss4 in four XOR worlds; T same actions with additional measured work',
        'models':MODELS,'python':sys.version},indent=2),encoding='utf-8')
    with (out/'tests.txt').open('w',encoding='utf-8') as f:
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py'))
    rows=[{'evaluator_model':m,'kind':kind,'horizon':h,'result':run(m,kind,h)}
          for m in MODELS for kind in ('B2','T') for h in range(4)]
    (out/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    (out/'model_expansion.json').write_text(json.dumps(experiment(),indent=2),encoding='utf-8')
    summary={'time':stamp,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
             'episodes':len(rows),'conclusion':'chain control only; no T advantage or open-world claim'}
    (out/'after.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (ROOT/'research_runs.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(summary)+'\n')
    audit_summary=audit_v03.main()
    print('Contract checks:',summary)
    return 0 if result.wasSuccessful() and not (audit_summary['regression']['failures'] or audit_summary['regression']['errors']) else 1
if __name__=='__main__':raise SystemExit(main())
