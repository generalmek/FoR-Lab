import unittest
from for_env_v02 import DiagnosticWorld
from inquiry_core import run_inquiry, filter_models, HYPOTHESES

class LabTests(unittest.TestCase):
    def test_reset_after_terminal(self):
        e=DiagnosticWorld(seed=1,scenario='independent'); a=e.reset()
        e.step('repair_sensor')
        b=e.reset()
        self.assertEqual(a,b)
        self.assertFalse(e.done)
        self.assertEqual(e.budget,e.initial_budget)
    def test_budget_rejects_action_without_mutation(self):
        e=DiagnosticWorld(seed=0,budget=0)
        before=(e.budget,list(e.history))
        with self.assertRaises(ValueError): e.step('audit_provenance')
        self.assertEqual((e.budget,e.history),before)
    def test_no_hidden_truth_in_observation(self):
        e=DiagnosticWorld(seed=1); obs=e.reset()
        self.assertNotIn('fault',obs.__dict__)
        self.assertNotIn('shared',obs.__dict__)
        _,_,_,info=e.step('inspect_primary')
        self.assertEqual(info,{})
    def test_uniform_wrong_class_not_called_resolved(self):
        self.assertEqual(len(filter_models(HYPOTHESES,'inspect_primary','impossible')),0)
    def test_trace_deterministic(self):
        for scenario in ('independent','shared'):
            self.assertEqual(run_inquiry(1,scenario),run_inquiry(1,scenario))
    def test_shared_reference_is_not_independent_proof(self):
        # 'abnormal' reference also occurs with fault=sensor under shared calibration.
        remaining=filter_models(HYPOTHESES,'inspect_reference','abnormal')
        self.assertTrue(any(h.fault=='sensor' and h.shared for h in remaining))
        self.assertTrue(any(h.fault=='process' for h in remaining))
    def test_no_unjustified_success_on_shared(self):
        r=run_inquiry(seed=1,scenario='shared',budget=7)
        events=[x for x in r['trace'] if x['event']=='decision']
        if events: self.assertEqual(events[-1]['status'],'RESOLVED')
    def test_budget_stop_is_not_identifiability(self):
        r=run_inquiry(seed=1,scenario='shared',budget=0)
        stop=r['trace'][-1]
        self.assertEqual(stop['status'],'BUDGET_EXHAUSTED')
        self.assertFalse(stop['epistemic_sufficiency'])
        self.assertFalse(stop['proof_of_unidentifiability'])
        self.assertTrue(stop['gap_open'])
    def test_non_budget_stop_not_called_proof(self):
        r=run_inquiry(seed=1,scenario='shared',budget=7)
        stop=r['trace'][-1]
        if stop['event']=='stop':
            self.assertNotEqual(stop['status'],'UNIDENTIFIABLE')
            self.assertFalse(stop.get('epistemic_sufficiency',False))
    def test_insufficient_budget_is_not_resolved(self):
        r=run_inquiry(seed=1,scenario='shared',budget=0)
        self.assertNotEqual(r['trace'][-1].get('status'),'RESOLVED')

if __name__=='__main__': unittest.main(verbosity=2)
