import unittest, tempfile
from pathlib import Path
from for_agents_v03 import optimal_plan, run_agent, run_suite
from inquiry_core import HYPOTHESES

class AgentV03Tests(unittest.TestCase):
    def test_equal_actions_same_world(self):
        for s in ('shared','independent'):
            for seed in range(10):
                a=run_agent('B2',seed,s);b=run_agent('T',seed,s)
                self.assertEqual(a['actions'],b['actions'])
                self.assertEqual(a['status'],b['status'])
    def test_repeatability(self):
        self.assertEqual(run_agent('T',2,'shared'),run_agent('T',2,'shared'))
    def test_budget_zero_kept_open(self):
        for name in ('B2','T'):
            x=run_agent(name,1,'shared',budget=0)
            self.assertNotEqual(x['status'],'RESOLVED')
            self.assertFalse(x['epistemic_sufficiency'])
    def test_no_oracle(self):
        x=run_agent('T',1,'shared')
        for row in x['trace']:
            self.assertNotIn('fault',row['observation'])
            self.assertNotIn('shared',row['observation'])
    def test_lookahead_changes_choice(self):
        v1,a1=optimal_plan(HYPOTHESES,7,horizon=1)
        v3,a3=optimal_plan(HYPOTHESES,7,horizon=3)
        self.assertLessEqual(v3,v1+1e-9)
    def test_outputs_logs(self):
        with tempfile.TemporaryDirectory() as d:
            s=run_suite(d,range(2))
            self.assertEqual(s['episodes'],8)
            self.assertTrue((Path(d)/'v03_summary.json').exists())
            self.assertTrue((Path(d)/'research_runs.jsonl').exists())
if __name__=='__main__':unittest.main(verbosity=2)
