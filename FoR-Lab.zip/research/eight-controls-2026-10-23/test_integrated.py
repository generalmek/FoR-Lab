import unittest
from copy import deepcopy
from integrated_pilot import *

class IntegrationTests(unittest.TestCase):
    def test_observational_equivalence_and_different_intervention(self):
        a=World('actuator');b=World('upstream')
        self.assertEqual(a.public_scene(),b.public_scene())
        self.assertNotEqual(a.probe(('a',0)).value,b.probe(('a',0)).value)
    def test_closed_chain_changes_dependent_not_independent(self):
        r=episode('upstream')
        self.assertTrue(r['success']);self.assertEqual(r['final']['decision'],('u',0))
        tx=r['worldview']['transactions'][0]
        self.assertEqual(tx['invalidated'],['target','second'])
        self.assertEqual(tx['before']['independent'],tx['after']['independent'])
        self.assertEqual(tx['new']['source'],'e1')
    def test_names_and_order_not_solution_key(self):
        for names in (('a','u','y'),('q9','r2','m8'),('y','a','u')):
            for parent in ('actuator','upstream'):
                for reverse in (False,True):self.assertTrue(episode(parent,names=names,reverse=reverse)['success'])
    def test_s3_same_capabilities(self):
        for parent in ('actuator','upstream'):
            a=episode(parent,'ST');b=episode(parent,'S3')
            self.assertEqual(a['final'],b['final']);self.assertEqual(a['success'],b['success'])
            self.assertEqual(a['prediction_calls'],b['prediction_calls'])
    def test_necessary_ablation_and_restoration(self):
        self.assertFalse(episode('upstream',invalidate=False)['success'])
        self.assertTrue(episode('upstream',invalidate=True)['success'])
        self.assertEqual(episode(binding=False)['final']['status'],'SEMANTIC_UNRESOLVED')
        self.assertEqual(episode(search=False)['final']['status'],'SEARCH_DISABLED_OR_EMPTY')
    def test_binding_sham_exposes_success_without_correct_model(self):
        full=episode('upstream');sham=episode('upstream',swap_binding=True)
        self.assertTrue(sham['success'])
        self.assertNotEqual(full['initial']['action'],sham['initial']['action'])
        self.assertNotEqual(full['worldview']['basis']['parent'],sham['worldview']['basis']['parent'])
        self.assertEqual(sham['worldview']['basis']['parent'],'actuator')
        self.assertTrue(all(x['correct'] for x in full['evaluator_only_post_run_predictions']))
        self.assertFalse(all(x['correct'] for x in sham['evaluator_only_post_run_predictions']))
        # Negative finding: current goal can be reached despite wrong semantic binding.
    def test_nonseparating_tests_keep_gap_open(self):
        r=episode(allowed_probes=[('upstream',0),('actuator',1)])
        self.assertEqual(r['final']['status'],'NO_DISTINGUISHING_PROBE')
        self.assertEqual(r['worldview']['transactions'],[])
    def test_graph_composition_new_chain(self):
        graph={'upstream':None,'actuator':'upstream','middle':'actuator','outcome':'middle'}
        self.assertEqual(evaluate_graph(graph,{'actuator':0}),0)
        self.assertEqual(evaluate_graph(graph,{'middle':1,'actuator':0}),1)
    def test_budget_not_sufficiency(self):
        r=episode(budget=0)
        self.assertEqual(r['final']['status'],'BUDGET_EXHAUSTED');self.assertTrue(r['final']['gap_open'])
        self.assertEqual(r['worldview']['transactions'],[])
    def test_forged_or_mismatched_evidence_no_mutation(self):
        c=ResearchController();c.start(World().public_scene());before=deepcopy(c.store.__dict__)
        for e in (Evidence('fake',('actuator',0),0,'language_model'),Evidence('wrong',('upstream',0),0)):
            self.assertEqual(c.receive(e)['status'],'EVIDENCE_REJECTED');self.assertEqual(c.store.__dict__,before)
    def test_outside_class_no_false_revision(self):
        w=World(outside=True);c=ResearchController();p=c.start(w.public_scene())
        self.assertEqual(c.receive(w.probe(p['action']))['status'],'MODEL_CLASS_INADEQUATE')
        self.assertEqual(c.store.version,0)
    def test_ambiguous_role_does_not_guess(self):
        s=World().public_scene();s['entities'].append({'id':'extra','type':'actuator'})
        self.assertEqual(ResearchController().start(s)['status'],'SEMANTIC_UNRESOLVED')
    def test_negative_analogue_requires_new_evidence(self):
        old=episode('actuator');new=episode('upstream',names=('q','r','s'))
        self.assertNotEqual(old['final']['decision'],new['final']['decision'])
        self.assertEqual(new['research_trace'][1]['event'],'probe_requested')
        # This is re-investigation, NOT learned transfer.
    def test_association_is_not_promoted_to_known_cause(self):
        r=episode()
        constructed=r['semantic_trace'][1]
        self.assertEqual(constructed['associations_not_promoted'][0]['type'],'STATISTICAL')
        self.assertTrue(all(m['status']=='CANDIDATE' for m in constructed['candidates']))
if __name__=='__main__':unittest.main(verbosity=2)
