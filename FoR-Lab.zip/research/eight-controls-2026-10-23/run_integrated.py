import hashlib, json, sys, unittest
from pathlib import Path
from datetime import datetime,timezone
from integrated_pilot import episode
from eight_controls import controls

ROOT=Path(__file__).resolve().parent
def main():
    out=ROOT/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')}
    (out/'before.json').write_text(json.dumps({'scope':'open integration control, post-development checks',
        'predictions':['full and S3 same success','no invalidation fails for upstream graph',
                       'binding sham may succeed with false model; goal success is insufficient'],
        'hashes':manifest,'python':sys.version},indent=2),encoding='utf-8')
    with (out/'tests.txt').open('w',encoding='utf-8') as f:
        tests=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py'))
    rows=[]
    for p in ('actuator','upstream'):
        for kind in ('ST','S3'):
            for tag,kwargs in [('full',{}),('no_invalidation',{'invalidate':False}),('binding_sham',{'swap_binding':True}),
                               ('budget_zero',{'budget':0}),('nonseparating',{'allowed_probes':[('upstream',0)]})]:
                rows.append({'variant':tag,'result':episode(p,kind,**kwargs)})
    (out/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    (out/'eight_controls.json').write_text(json.dumps(controls(),indent=2),encoding='utf-8')
    summary={'tests':tests.testsRun,'failures':len(tests.failures),'errors':len(tests.errors),'episodes':len(rows),
       'conclusion':'selected integration functions exercised; no full Intellect/Core or architecture advantage established',
       'negative_finding':'role corruption may preserve goal success while corrupting inferred model',
       'remaining':'goal-specific research necessity, learned transfer, rollback, complete CL-v0, independent implementations'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (ROOT/'research_runs.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'run':out.name,**summary})+'\n')
    print(json.dumps({'folder':str(out),**summary},indent=2))
    return 0 if tests.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
