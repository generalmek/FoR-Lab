"""Additional finite engineering fixtures for §24S.16. Not the full specification."""
from collections import deque
from copy import deepcopy

def plan(edges,start,goal,limit=100):
    queue=deque([(start,[])]);seen={start};expanded=0
    while queue:
        if expanded>=limit:return {'status':'SEARCH_INCOMPLETE','expanded':expanded}
        node,path=queue.popleft();expanded+=1
        if node==goal:return {'status':'FOUND','path':path,'expanded':expanded}
        for a,b in edges:
            if a==node and b not in seen:
                seen.add(b);queue.append((b,path+[(a,b)]))
    return {'status':'SEARCH_EXHAUSTED_IN_CLASS','expanded':expanded}

def acquire_procedure(successful_path,role_binding):
    """Abstract an observed successful path by supplied roles; no inferred role meaning."""
    inverse={value:role for role,value in role_binding.items()}
    return tuple((inverse[a],inverse[b]) for a,b in successful_path)

def transfer(procedure,new_binding,available_edges):
    candidate=tuple((new_binding[a],new_binding[b]) for a,b in procedure)
    if any(edge not in available_edges for edge in candidate):return {'status':'PRECONDITION_FAILED'}
    return {'status':'APPLICABLE','path':candidate}

def proto_predicate(samples):
    """Learn one feature equality from labelled examples; bounded concept candidate."""
    candidates=[]
    for feature in sorted(samples[0][0]):
        for value in sorted({features[feature] for features,_ in samples}):
            if all((features[feature]==value)==label for features,label in samples):
                candidates.append((feature,value))
    if len(candidates)!=1:return {'status':'AMBIGUOUS_OR_UNREPRESENTABLE','candidates':candidates}
    return {'status':'CANDIDATE','predicate':candidates[0],'source':'labelled_training_examples'}

class ActionModel:
    def __init__(self,gain=1.):self.gain=gain;self.version=0;self.history=[]
    def predict(self,x,u):return x+self.gain*u
    def repair(self,samples):
        denom=sum(u*u for x,u,y in samples)
        if denom==0:return 'UNIDENTIFIABLE'
        gain=sum(u*(y-x) for x,u,y in samples)/denom
        if any(abs(x+gain*u-y)>1e-9 for x,u,y in samples):return 'CLASS_INADEQUATE'
        self.history.append({'gain':self.gain,'version':self.version,'source':deepcopy(samples)})
        self.gain=gain;self.version+=1;return 'UPDATED'

class ProcedureStore:
    def __init__(self):self.version=0;self.gain=1.;self.target=6.;self.command=6.;self.history=[];self.ids=set()
    def revise(self,gain,evidence_id,expected_version,fail=False):
        if evidence_id in self.ids:return 'DUPLICATE'
        if expected_version!=self.version:return 'STALE'
        if gain==0:return 'REJECTED'
        candidate={'gain':gain,'command':self.target/gain,'version':self.version+1}
        if fail:return 'ROLLED_BACK' # staged candidate never committed
        self.history.append({'gain':self.gain,'command':self.command,'version':self.version})
        self.gain=candidate['gain'];self.command=candidate['command'];self.version=candidate['version'];self.ids.add(evidence_id)
        return 'COMMITTED'

def controls():
    edges=[('s','a'),('a','g')]
    p=plan(edges,'s','g')
    learned=acquire_procedure(p['path'],{'source':'s','middle':'a','goal':'g'})
    binding={'source':'n1','middle':'n2','goal':'n3'}
    samples=[({'material':0,'stiff':0},False),({'material':1,'stiff':0},False),
             ({'material':0,'stiff':1},True),({'material':1,'stiff':1},True)]
    proto=proto_predicate(samples)
    model=ActionModel();before=model.predict(3,4);repair=model.repair([(0,1,2),(1,2,5)])
    store=ProcedureStore();rolled=store.revise(2,'e0',0,True);committed=store.revise(2,'e1',0)
    return {'class1_composition':p,'class3_revision':{'rollback':rolled,'commit':committed,'command':store.command},
       'class4_transfer':{'positive':transfer(learned,binding,[('n1','n2'),('n2','n3')]),
                          'negative':transfer(learned,binding,[('n1','n2')])},
       'class5_boundary':{'exhaustive':plan(edges,'s','unreachable'),'limited':plan(edges,'s','g',1),
                          'limit':'finite graph exhaustion is NOT a general RepresentationGap diagnosis'},
       'class6_proto':proto,'class7_action_model':{'before':before,'repair':repair,'after':model.predict(3,4),'target':11},
       'class8_paths':{'unique_removed':plan([('s','a')],'s','g'),
                       'redundant_removed':plan([('s','b'),('b','c'),('c','g')],'s','g')},
       'scope':'handcrafted open fixtures; no new primitive invention; no independent architecture comparison'}
