"""Open integration fixture: typed roles, candidate graphs, intervention, revision.
This implements a small subset, NOT full CL-v0/Intellect/Core or confirmation.
"""
from dataclasses import dataclass, asdict
from copy import deepcopy
import itertools, json

def evaluate_graph(parents, interventions, root_value=1):
    """Compose copy-relations in a DAG; do() overrides a structural equation."""
    values={}
    def visit(node,stack=()):
        if node in interventions:return interventions[node]
        if node in values:return values[node]
        if node in stack:raise ValueError('cyclic graph')
        parent=parents[node]
        values[node]=root_value if parent is None else visit(parent,stack+(node,))
        return values[node]
    return visit('outcome')

@dataclass(frozen=True)
class Evidence:
    id:str
    action:tuple
    value:int
    source:str='environment_intervention'

class World:
    def __init__(self,parent='actuator',names=('a','u','y'),outside=False):
        self.parent=parent;self.names=names;self.outside=outside;self.probes=0
    def public_scene(self,reverse=False):
        a,u,y=self.names
        entities=[{'id':a,'type':'actuator'},{'id':u,'type':'upstream'},{'id':y,'type':'outcome'}]
        return {'entities':list(reversed(entities)) if reverse else entities,
                'relations':[{'type':'STATISTICAL','subject':a,'object':y,'source':'observed_cooccurrence'}],
                'observed':{a:1,u:1,y:1},'goal':{'target':y,'value':0}}
    def probe(self,action):
        self.probes+=1
        entity,value=action
        role=dict(zip(self.names,('actuator','upstream','outcome'))).get(entity)
        if role not in ('actuator','upstream') or value not in (0,1):raise ValueError('action')
        # SCM: actuator=upstream naturally; do(actuator) cuts that arrow.
        u=value if role=='upstream' else 1
        a=value if role=='actuator' else u
        y=(a if self.parent=='actuator' else u) if not self.outside else 2
        return Evidence(f'e{self.probes}',action,y)
    def evaluate(self,decision):
        return self.probe(decision).value==0

class SemanticIntellect:
    def __init__(self,binding=True,search=True):
        self.binding=binding;self.search=search;self.trace=[];self.predictions=0
    def bind(self,scene):
        if not self.binding:return None
        roles={}
        for role in ('actuator','upstream','outcome'):
            matches=[e['id'] for e in scene['entities'] if e['type']==role]
            if len(matches)!=1:return None
            roles[role]=matches[0]
        if scene['goal']['target']!=roles['outcome']:return None
        self.trace.append({'operation':'BIND','roles':roles,'source':'typed_input_not_language_understanding'})
        return roles
    def construct(self,scene):
        # Restricted grammar: choose an allowed parent for outcome; no label from World.
        candidates=tuple({'parent':p,'status':'CANDIDATE','source':'grammar_parent_choice'} for p in ('actuator','upstream')) if self.search else ()
        self.trace.append({'operation':'CONSTRUCT','candidates':deepcopy(candidates),
                           'associations_not_promoted':deepcopy(scene['relations'])})
        return candidates
    def predict(self,model,action):
        self.predictions+=1
        role,value=action
        return evaluate_graph({'upstream':None,'actuator':'upstream','outcome':model['parent']},{role:value})
    def choose_probe(self,models):
        scored=[]
        for action in itertools.product(('actuator','upstream'),(0,1)):
            distinct=len({self.predict(m,action) for m in models})
            scored.append((-distinct,action))
        score,action=min(scored)
        return action if score < -1 else None

class Worldview:
    def __init__(self):
        self.version=0
        self.basis={'parent':'actuator','status':'UNVERIFIED_PRIOR','source':'declared_initial_assumption'}
        self.expressions={'target':('from_basis','mechanism',0),
                          'second':('from_basis','mechanism',1),
                          'independent':('literal',('lamp',1))}
        self.decisions={key:self.compute(expr) for key,expr in self.expressions.items()}
        self.evidence=[];self.transactions=[]
    def compute(self,expr):
        reads=[]
        if expr[0]=='from_basis':
            reads.append(expr[1]);action=(self.basis['parent'],expr[2])
        else:action=expr[1]
        return {'action':action,'depends':reads,'valid':True}
    def commit(self,model,evidence,invalidate=True,full_recompute=False):
        # Does not certify arbitrary evidence: orchestrator verifies pending request first.
        previous=deepcopy(self.basis);before=deepcopy(self.decisions)
        self.basis={**model,'status':'SUPPORTED_IN_FINITE_CLASS','source':evidence.id}
        self.version+=1;self.evidence.append(asdict(evidence))
        changed=[];recomputed=[]
        if invalidate:
            for key,d in self.decisions.items():
                if 'mechanism' in d['depends']:
                    changed.append(key);d['valid']=False
                if not d['valid'] or full_recompute:
                    self.decisions[key]=self.compute(self.expressions[key]);recomputed.append(key)
        self.transactions.append({'old':previous,'new':deepcopy(self.basis),'evidence':evidence.id,
                                  'invalidated':changed,'recomputed':recomputed,'before':before,'after':deepcopy(self.decisions)})

class ResearchController:
    def __init__(self,kind='ST',binding=True,search=True,invalidate=True,budget=1,allowed_probes=None,swap_binding=False):
        if kind not in ('ST','S3'):raise ValueError(kind)
        self.kind=kind;self.intellect=SemanticIntellect(binding,search);self.store=Worldview()
        self.invalidate=invalidate;self.budget=budget;self.pending=None;self.models=();self.trace=[]
        self.allowed_probes=allowed_probes;self.swap_binding=swap_binding
    def start(self,scene):
        roles=self.intellect.bind(scene)
        if roles is None:return {'status':'SEMANTIC_UNRESOLVED'}
        if self.swap_binding:roles['actuator'],roles['upstream']=roles['upstream'],roles['actuator']
        self.roles=roles
        self.models=self.intellect.construct(scene)
        if not self.models:return {'status':'SEARCH_DISABLED_OR_EMPTY'}
        choices={m['parent'] for m in self.models}
        self.trace.append({'event':'decision_gap','alternatives':sorted(choices),
                           'representation':'FoundationGap' if self.kind=='ST' else 'belief_disagreement'})
        if self.budget<=0:return {'status':'BUDGET_EXHAUSTED','gap_open':True}
        action=self.intellect.choose_probe(self.models)
        if self.allowed_probes is not None:
            options=[a for a in self.allowed_probes if len({self.intellect.predict(m,a) for m in self.models})>1]
            action=min(options) if options else None
        if action is None:return {'status':'NO_DISTINGUISHING_PROBE','gap_open':True}
        action=(roles[action[0]],action[1]);self.pending=action
        self.trace.append({'event':'probe_requested','action':action,'basis_version':self.store.version})
        return {'status':'PENDING','action':action}
    def receive(self,evidence):
        if self.pending is None or evidence.action!=self.pending or evidence.source!='environment_intervention':
            return {'status':'EVIDENCE_REJECTED','gap_open':True}
        self.budget-=1;self.pending=None
        inverse={v:k for k,v in self.roles.items()}
        semantic_action=(inverse[evidence.action[0]],evidence.action[1])
        survivors=tuple(m for m in self.models if self.intellect.predict(m,semantic_action)==evidence.value)
        self.trace.append({'event':'evidence','data':asdict(evidence),'survivors':deepcopy(survivors)})
        if not survivors:return {'status':'MODEL_CLASS_INADEQUATE','gap_open':True}
        if len(survivors)!=1:return {'status':'GAP_OPEN','gap_open':True}
        self.store.commit(survivors[0],evidence,self.invalidate,self.kind=='S3')
        role,value=self.store.decisions['target']['action']
        return {'status':'REVISED','gap_open':False,'decision':(self.roles[role],value)}

def episode(parent='actuator',kind='ST',names=('a','u','y'),reverse=False,**kwargs):
    world=World(parent,names);agent=ResearchController(kind,**kwargs)
    first=agent.start(world.public_scene(reverse));final=first;success=None
    if first['status']=='PENDING':
        final=agent.receive(world.probe(first['action']))
        if final['status']=='REVISED':success=world.evaluate(final['decision'])
    prediction_checks=[]
    if final['status']=='REVISED':
        inverse={v:k for k,v in agent.roles.items()}
        for entity,value in itertools.product(names[:2],(0,1)):
            model=agent.store.basis
            predicted=evaluate_graph({'upstream':None,'actuator':'upstream','outcome':model['parent']},{inverse[entity]:value})
            actual=World(parent,names).probe((entity,value)).value
            prediction_checks.append({'action':(entity,value),'predicted':predicted,'actual':actual,'correct':predicted==actual})
    return {'kind':kind,'evaluator_parent':parent,'initial':first,'final':final,'success':success,
            'evaluator_only_post_run_predictions':prediction_checks,
            'semantic_trace':agent.intellect.trace,'research_trace':agent.trace,
            'worldview':{'basis':agent.store.basis,'decisions':agent.store.decisions,'evidence':agent.store.evidence,'transactions':agent.store.transactions},
            'prediction_calls':agent.intellect.predictions,
            'scope':'open finite integration; typed symbolic input, not full semantic Intellect or Core'}

if __name__=='__main__':print(json.dumps([episode(p,k) for p in ('actuator','upstream') for k in ('ST','S3')],indent=2))
