import unittest
from copy import deepcopy
from eight_controls import *

class EightControls(unittest.TestCase):
    def test_compose_execute(self):
        edges=[('s','a'),('a','g')];r=plan(edges,'s','g');node='s'
        for a,b in r['path']:self.assertEqual(node,a);node=b
        self.assertEqual(node,'g')
    def test_search_limit_not_representation_gap(self):
        self.assertEqual(plan([('s','a'),('a','g')],'s','g',1)['status'],'SEARCH_INCOMPLETE')
        self.assertEqual(plan([('s','a')],'s','g')['status'],'SEARCH_EXHAUSTED_IN_CLASS')
    def test_transfer_and_false_analogy(self):
        p=acquire_procedure([('s','a'),('a','g')],{'start':'s','tool':'a','goal':'g'})
        bindings={'start':'7','tool':'2','goal':'4'}
        self.assertEqual(transfer(p,bindings,[('7','2'),('2','4')])['status'],'APPLICABLE')
        self.assertEqual(transfer(p,bindings,[('7','2'),('4','2')])['status'],'PRECONDITION_FAILED')
    def test_proto_needs_counterexamples(self):
        ambiguous=[({'m':0,'r':0},False),({'m':1,'r':1},True)]
        self.assertEqual(proto_predicate(ambiguous)['status'],'AMBIGUOUS_OR_UNREPRESENTABLE')
        learned=proto_predicate(ambiguous+[({'m':0,'r':1},True)])
        self.assertEqual(learned['predicate'],('r',1))
        # Unused combination checks learned feature, rather than training-row lookup.
        self.assertFalse({'m':1,'r':0}[learned['predicate'][0]]==learned['predicate'][1])
        contradictory=ambiguous+[({'m':0,'r':0},True)]
        self.assertNotEqual(proto_predicate(contradictory)['status'],'CANDIDATE')
    def test_model_learning_and_negative_controls(self):
        m=ActionModel();self.assertNotEqual(m.predict(3,4),11)
        self.assertEqual(m.repair([(0,1,2),(1,2,5)]),'UPDATED');self.assertEqual(m.predict(3,4),11)
        before=deepcopy(m.__dict__)
        self.assertEqual(m.repair([(0,0,0)]),'UNIDENTIFIABLE');self.assertEqual(m.__dict__,before)
        self.assertEqual(m.repair([(0,1,2),(0,2,9)]),'CLASS_INADEQUATE');self.assertEqual(m.__dict__,before)
    def test_revision_transaction_failure_duplicate_stale(self):
        s=ProcedureStore();before=deepcopy(s.__dict__)
        self.assertEqual(s.revise(2,'e0',0,True),'ROLLED_BACK');self.assertEqual(s.__dict__,before)
        self.assertEqual(s.revise(2,'e1',0),'COMMITTED');self.assertEqual(2*s.command,s.target)
        after=deepcopy(s.__dict__)
        self.assertEqual(s.revise(3,'e1',1),'DUPLICATE');self.assertEqual(s.__dict__,after)
        self.assertEqual(s.revise(3,'e2',0),'STALE');self.assertEqual(s.__dict__,after)
    def test_unique_and_redundant_paths(self):
        full=[('s','a'),('a','g'),('s','b'),('b','c'),('c','g')]
        original=plan(full,'s','g');removed=plan(full[2:],'s','g')
        self.assertEqual(removed['status'],'FOUND');self.assertGreater(len(removed['path']),len(original['path']))
        self.assertEqual(plan([('s','a')],'s','g')['status'],'SEARCH_EXHAUSTED_IN_CLASS')
if __name__=='__main__':unittest.main(verbosity=2)
