import hashlib,json,sys,unittest,shutil
from datetime import datetime,timezone
from pathlib import Path
from pilot import series9,series10,series11

ROOT=Path(__file__).resolve().parent
def main():
    out=ROOT/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
    (out/'source').mkdir()
    for p in ROOT.iterdir():
        if p.suffix in ('.py','.md'):shutil.copy2(p,out/'source'/p.name)
    (out/'manifest.json').write_text(json.dumps({'python':sys.version,'command':sys.argv,
        'scope':'three new open pilot series, plan items 9-11',
        'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.iterdir() if p.suffix in ('.py','.md')}},indent=2),encoding='utf-8')
    with (out/'tests.txt').open('w',encoding='utf-8') as f:
        t=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py'))
    outputs={'cycle9':series9(),'cycle10':series10(out),'cycle11':series11()}
    for key,result in outputs.items():
        (out/(key+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    summary={'tests':t.testsRun,'failures':len(t.failures),'errors':len(t.errors),'folder':str(out)}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    return int(not t.wasSuccessful())
if __name__=='__main__':raise SystemExit(main())
