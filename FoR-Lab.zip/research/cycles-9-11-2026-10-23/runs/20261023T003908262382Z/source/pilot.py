"""Open finite component experiments. Normative weights are supplied, not learned."""
import json
from copy import deepcopy
from itertools import product
from pathlib import Path

ACTIONS = ('produce', 'safe', 'abstain')

def outcome(action, danger):
    return {'benefit': {'produce':10, 'safe':4, 'abstain':0}[action],
            'irreversible': int(action == 'produce' and danger)}

def utility(action, danger, weight):
    o = outcome(action, danger)
    return o['benefit'] - weight * o['irreversible']

class Budget:
    def __init__(self): self.probes=0; self.evals=0
    def evaluate(self):
        if self.evals >= 100: raise RuntimeError('MODEL_BUDGET')
        self.evals += 1
    def probe(self):
        if self.probes >= 1: raise RuntimeError('PROBE_BUDGET')
        self.probes += 1

def compass_policy(candidates, cost, weight, budget):
    def score(a, d):
        budget.evaluate(); return utility(a,d,weight)
    direct = [(sum(score(a,d) for d in candidates)/len(candidates),a) for a in ACTIONS]
    best_score,best = max(direct)
    branches = {d:max((score(a,d),a) for a in ACTIONS)[1] for d in candidates}
    probe_score = sum(score(branches[d],d) for d in candidates)/len(candidates)-cost
    return ('probe',branches) if probe_score>best_score else ('direct',best)

def baseline_policy(candidates, cost, weight, budget):
    # Independently enumerate full contingent policies; same supplied loss function.
    policies=[('direct',a) for a in ACTIONS]
    policies += [('probe',dict(zip((False,True),p))) for p in product(ACTIONS,repeat=2)]
    ranked=[]
    for policy in policies:
        total=0
        for state in candidates:
            budget.evaluate()
            act=policy[1] if policy[0]=='direct' else policy[1][state]
            o=outcome(act,state)
            total += o['benefit']-weight*o['irreversible']
        ranked.append((total/len(candidates)-(cost if policy[0]=='probe' else 0),policy))
    return max(ranked,key=lambda p:p[0])[1]

def compass_episode(danger,cost,agent,weight=20,candidates=(False,True)):
    b=Budget()
    if agent=='T': policy=compass_policy(candidates,cost,weight,b)
    elif agent=='B2': policy=baseline_policy(candidates,cost,weight,b)
    else: policy=('direct','produce' if agent=='local' else 'abstain')
    if policy[0]=='probe':
        b.probe(); action=policy[1][danger]
    else: action=policy[1]
    return {'world_danger':danger,'cost':cost,'agent':agent,'weight':weight,
            'candidates':candidates,'policy':policy,'action':action,**outcome(action,danger),
            'net':utility(action,danger,weight)-cost*b.probes,'probes':b.probes,'evals':b.evals}

class Dynamics:
    def __init__(self,gain): self._gain=gain; self.probes=0
    def observe(self,u):
        self.probes+=1
        return {'id':f'e{self.probes}', 'u':u,'y':self._gain*u,'source':'sensor'}
    def change(self,gain): self._gain=gain
    def result(self,u): return self._gain*u

class Store:
    def __init__(self):
        self.state={'version':0,'gain':1.,'plans':{'six':6.,'nine':9.},
                    'independent':{'lamp':True},'seen':[],'history':[]}
    @classmethod
    def load(cls,path):
        obj=cls(); obj.state=json.loads(Path(path).read_text(encoding='utf-8')); return obj
    def save(self,path,fail=False):
        path=Path(path); tmp=path.with_suffix('.pending')
        tmp.write_text(json.dumps(self.state,sort_keys=True),encoding='utf-8')
        if fail: raise OSError('injected pre-replace failure')
        tmp.replace(path)
    def revise(self,e,expected,invalidate=True):
        s=self.state
        if e['id'] in s['seen']: return 'DUPLICATE'
        if expected != s['version']: return 'STALE'
        if not e['u'] or not e['y']: return 'UNIDENTIFIABLE'
        old=deepcopy(s); gain=e['y']/e['u']
        s['history'].append({'version':old['version'],'gain':old['gain'],
                             'plans':old['plans'],'evidence':deepcopy(e)})
        s['gain']=gain;s['version']+=1;s['seen'].append(e['id'])
        if invalidate: s['plans']={'six':6/gain,'nine':9/gain}
        return 'COMMITTED'

def series9():
    rows=[compass_episode(d,c,a) for c in (1,5,20) for d in (False,True)
          for a in ('T','B2','local','refuse')]
    wrong=[compass_episode(True,1,a,candidates=(False,)) for a in ('T','B2')]
    # Explicit conflicting normative choices, not a claim weights can be inferred.
    conflict=[]
    for weights in ((1,1),(3,1),(1,3)):
        losses={'protect_A':(0,1),'protect_B':(1,0),'abstain':(1,1)}
        scores={a:sum(w*l for w,l in zip(weights,loss)) for a,loss in losses.items()}
        best=min(scores.values())
        conflict.append({'weights':weights,'losses':losses,'best_actions':[a for a,v in scores.items() if v==best]})
    return {'rows':rows,'wrong_model':wrong,'conflicts':conflict}

def series10(folder):
    path=Path(folder)/'memory.json'; s=Store(); s.save(path); world=Dynamics(2)
    trace=[]
    for stage,gain,corrupt in [('learn',2,False),('drift',3,False),('bad_revision',3,True),('refutation',3,False)]:
        world.change(gain); e=world.observe(1)
        if corrupt: e['y']=4 # agent receives no corruption label
        result=s.revise(e,s.state['version']);s.save(path);s=Store.load(path)
        trace.append({'stage':stage,'evidence':e,'status':result,'state':deepcopy(s.state),
                      'actual':world.result(s.state['plans']['six']),
                      'error':abs(world.result(s.state['plans']['six'])-6)})
    frozen=deepcopy(s.state)
    duplicate=s.revise(e,s.state['version'])
    stale=s.revise({'id':'future','u':1,'y':7},0)
    unchanged=s.state==frozen
    s.revise({'id':'uncommitted','u':1,'y':9},s.state['version'])
    try: s.save(path,fail=True)
    except OSError: pass
    restored=Store.load(path)
    return {'trace':trace,'duplicate':duplicate,'stale':stale,'rejected_unchanged':unchanged,
            'restart_recovers_committed':restored.state==frozen,
            'independent_preserved':all(t['state']['independent']=={'lamp':True} for t in trace),
            'limitation':'pre-replace exception only; not power-loss durability or arbitrary corruption recovery'}

def series11():
    rows=[]
    for mode in ('full','no_invalidation','sham','restored'):
        for agent in ('T','B2'):
            world=Dynamics(2); evidence=[world.observe(1)]
            s=Store();s.revise(evidence[0],0)
            world.change(3);e=world.observe(1)
            if mode=='sham': e['y']=4
            evidence.append(e)
            if agent=='T':
                s.revise(e,s.state['version'],invalidate=mode not in ('no_invalidation','restored'))
                before_restore=world.result(s.state['plans']['six'])
                if mode=='restored':
                    s.state['plans']={'six':6/s.state['gain'],'nine':9/s.state['gain']}
                command=s.state['plans']['six']; calculations=4 # two targets at each revision, except disabled
                if mode=='no_invalidation': calculations=2
            else:
                # no cached procedure or T revision implementation
                command=6*evidence[-1]['u']/evidence[-1]['y'];calculations=1
            rows.append({'mode':mode,'agent':agent,'observations':evidence,'command':command,
                         'actual':world.result(command),'error':abs(world.result(command)-6),
                         'probes':world.probes,'plan_calculations':calculations,
                         'before_restore':before_restore if agent=='T' and mode=='restored' else None})
    return rows
