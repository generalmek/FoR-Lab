import tempfile, unittest
from pathlib import Path
from pilot import *

class CompassTests(unittest.TestCase):
    def test_cheap_probe_changes_decision(self):
        for agent in ('T','B2'):
            safe=compass_episode(False,1,agent);danger=compass_episode(True,1,agent)
            self.assertEqual(safe['action'],'produce');self.assertEqual(danger['action'],'safe')
            self.assertEqual(danger['probes'],1)
    def test_expensive_probe_not_required(self):
        for agent in ('T','B2'):
            row=compass_episode(True,20,agent)
            self.assertEqual(row['probes'],0);self.assertEqual(row['action'],'safe')
    def test_no_architecture_advantage(self):
        for d in (False,True):
            for c in (1,5,20):
                a=compass_episode(d,c,'T');b=compass_episode(d,c,'B2')
                self.assertEqual((a['net'],a['action'],a['probes']),(b['net'],b['action'],b['probes']))
                self.assertLessEqual(max(a['evals'],b['evals']),100)
    def test_wrong_model_is_not_detected_magically(self):
        for a in ('T','B2'):
            row=compass_episode(True,1,a,candidates=(False,))
            self.assertEqual(row['irreversible'],1);self.assertEqual(row['probes'],0)
    def test_normative_weight_changes_result(self):
        self.assertEqual(compass_episode(True,1,'T',weight=0)['action'],'produce')
        self.assertEqual(compass_episode(True,1,'T',weight=20)['action'],'safe')
    def test_probe_budget_enforced(self):
        b=Budget();b.probe()
        with self.assertRaises(RuntimeError): b.probe()
    def test_conflicts_remain_weight_dependent(self):
        rows=series9()['conflicts']
        self.assertEqual(set(rows[0]['best_actions']),{'protect_A','protect_B'})
        self.assertEqual(rows[1]['best_actions'],['protect_A'])
        self.assertEqual(rows[2]['best_actions'],['protect_B'])
    def test_hard_gate_cannot_be_bought_by_large_reward(self):
        for r in series9()['hard_gate']:
            self.assertEqual(r['irreversible'],0)
            self.assertEqual(r['action'],r['baseline_action'])
            self.assertEqual(r['probe'],r['baseline_probe'])

class StabilityTests(unittest.TestCase):
    def test_drift_bad_revision_refutation_and_restart(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as d:
            result=series10(d)
        self.assertEqual([t['error'] for t in result['trace']],[0,0,1.5,0])
        self.assertTrue(result['restart_recovers_committed'])
        self.assertTrue(result['independent_preserved'])
        self.assertTrue(result['rejected_unchanged'])
        self.assertEqual(result['duplicate'],'DUPLICATE');self.assertEqual(result['stale'],'STALE')
        self.assertEqual(result['trace'][-1]['status'],'ROLLED_BACK')
        self.assertEqual([t['state']['version'] for t in result['trace']],[1,2,3,4])
        self.assertEqual(result['trace'][-1]['state']['history'][-1]['rollback_target'],2)
    def test_rollback_requires_supporting_evidence(self):
        s=Store();s.revise({'id':'a','u':1,'y':2},0)
        old=deepcopy(s.state)
        self.assertEqual(s.rollback(0,{'id':'b','u':1,'y':3}),'CONTRADICTED_ROLLBACK')
        self.assertEqual(s.state,old)
    def test_without_excitation_no_model(self):
        s=Store();old=deepcopy(s.state)
        self.assertEqual(s.revise({'id':'x','u':0,'y':0},0),'UNIDENTIFIABLE')
        self.assertEqual(s.state,old)
    def test_same_format_false_evidence_is_accepted(self):
        s=Store();s.revise({'id':'x','u':1,'y':4,'source':'sensor'},0)
        self.assertEqual(s.state['gain'],4)

class CausalTests(unittest.TestCase):
    def test_ablation_and_actual_restoration(self):
        rows={(r['mode'],r['agent']):r for r in series11()}
        self.assertEqual(rows['full','T']['error'],0)
        self.assertEqual(rows['no_invalidation','T']['error'],3)
        self.assertEqual(rows['restored','T']['before_restore'],9)
        self.assertEqual(rows['restored','T']['error'],0)
    def test_independent_baseline_matches_and_sham_hurts_both(self):
        rows={(r['mode'],r['agent']):r for r in series11()}
        for mode in ('full','sham','restored'):
            self.assertEqual(rows[mode,'T']['error'],rows[mode,'B2']['error'])
            self.assertEqual(rows[mode,'T']['observations'],rows[mode,'B2']['observations'])
        self.assertEqual(rows['sham','T']['error'],1.5)

if __name__=='__main__': unittest.main()
