import json
from copy import deepcopy
from pathlib import Path

class BudgetExceeded(Exception):pass

class AgentIO:
    """Narrow API contract, NOT a sandbox against Python introspection."""
    __slots__=('catalog','_query','trace','remaining')
    def __init__(self,catalog,query,remaining):
        self.catalog=deepcopy(catalog);self._query=query;self.trace=[];self.remaining=remaining
    def interface(self):return deepcopy(self.catalog)
    def query(self,n,kind):
        value=self._query(n,kind)
        cost=next(c['read_cost'] for c in self.catalog if c['id']==n)
        self.remaining-=cost
        self.trace.append({'id':len(self.trace),'channel':n,'kind':kind,'value':value,'cost':cost})
        return value

class World:
    def __init__(self,x=0,bias=(1,1,0),names=('a','b','c'),budget=12,reference=True,scale=1):
        self.x=x;self.bias=dict(zip(names,bias));self.names=names
        self.cost=dict(zip(names,(1,1,4)));self.remaining=budget;self.reference=reference
        self.scale=scale;self.trace=[]
    def interface(self):
        return [{'id':n,'read_cost':self.cost[n],'reference':self.reference} for n in reversed(self.names)]
    def query(self,n,kind):
        if n not in self.bias or kind not in ('read','reference'):raise ValueError('unknown action')
        if kind=='reference' and not self.reference:raise ValueError('unavailable')
        cost=self.cost[n]
        if cost>self.remaining:raise BudgetExceeded('budget')
        self.remaining-=cost
        value=self.bias[n]+(self.scale*self.x if kind=='read' else 0)
        event={'id':len(self.trace),'channel':n,'kind':kind,'value':value,'cost':cost}
        self.trace.append(event);return value
    def api(self):return AgentIO(self.interface(),self.query,self.remaining)

class Knowledge:
    def __init__(self,coefficients=(1,2)):
        self.values={'x':0,'z':7};self.version=0;self.history=[];self.dependencies={}
        self.expressions={'first':('scale','x',coefficients[0]),'second':('scale','x',coefficients[1]),'other':('scale','z',3)}
        self.plans={k:self.compute(k) for k in self.expressions}
    def compute(self,k):
        _,basis,factor=self.expressions[k];self.dependencies[k]={basis}
        return self.values[basis]*factor
    def revise(self,value,evidence,invalidate=True):
        changed={k for k,v in value.items() if self.values[k]!=v}
        self.history.append({'version':self.version,'values':deepcopy(self.values),'evidence':deepcopy(evidence)})
        self.values.update(value);self.version+=1
        affected={k for k,deps in self.dependencies.items() if deps & changed}
        if invalidate:
            for k in affected:self.plans[k]=self.compute(k)
        return sorted(affected)

class Agent:
    def __init__(self,method='consensus'):self.method=method;self.method_history=[]
    def save(self,path):Path(path).write_text(json.dumps({'method':self.method,'history':self.method_history}),encoding='utf-8')
    @classmethod
    def load(cls,path):
        data=json.loads(Path(path).read_text(encoding='utf-8'));a=cls(data['method']);a.method_history=data['history'];return a
    def run(self,world,coefficients=(1,2),learn=True,invalidate=True):
        if not isinstance(world,AgentIO):raise TypeError('Agent requires AgentIO')
        knowledge=Knowledge(coefficients);cache={};catalog=world.interface()
        ordered=sorted(catalog,key=lambda c:(c['read_cost'],c['id']))
        def get(n,kind):
            key=(n,kind)
            if key not in cache:cache[key]=world.query(n,kind)
            return cache[key]
        def finish(status,affected=()):
            return {'status':status,'method':self.method,'trace':deepcopy(world.trace),
                    'plans':deepcopy(knowledge.plans),'values':deepcopy(knowledge.values),
                    'affected':list(affected),'history':knowledge.history,'remaining':world.remaining,
                    'coefficients':coefficients}
        # Relevance is computed from the goal expressions under candidate states,
        # not an environment-supplied instruction to investigate.
        possibilities=[sum(abs(factor*(x-knowledge.values[basis])) for _,basis,factor in knowledge.expressions.values() if basis=='x') for x in (-1,0,1)]
        if max(possibilities)==0:return finish('IRRELEVANT')
        try:
            if self.method=='consensus':
                initial=[get(c['id'],'read') for c in ordered[:2]]
                provisional=initial[0]
                knowledge.revise({'x':provisional},world.trace)
                accessible=[c for c in ordered if c['reference']]
                if not accessible:return finish('INSUFFICIENT_EVIDENCE')
                channel=accessible[0]['id'];ref=get(channel,'reference')
                if ref!=0 or initial[0]!=initial[1]:
                    if not learn:return finish('METHOD_UNSUPPORTED')
                    # Synthesize from an explicit finite expression grammar.
                    candidates=[]
                    for op in ('raw','subtract_reference'):
                        predicted_zero=ref if op=='raw' else ref-ref
                        if predicted_zero==0:
                            candidates.append((1 if op=='raw' else 2,op))
                    if not candidates:return finish('NO_METHOD')
                    self.method=min(candidates)[1]
                    self.method_history.append({'from':'consensus','to':self.method,'evidence':deepcopy(world.trace)})
                estimate=get(channel,'read')-ref
            else:
                available=[c for c in ordered if c['reference']]
                if not available:return finish('INSUFFICIENT_EVIDENCE')
                channel=available[0]['id'];ref=get(channel,'reference')
                if self.method=='raw' and ref!=0:
                    if not learn:return finish('METHOD_UNSUPPORTED')
                    self.method_history.append({'from':'raw','to':'subtract_reference','evidence':deepcopy(world.trace)})
                    self.method='subtract_reference'
                estimate=get(channel,'read')-(ref if self.method=='subtract_reference' else 0)
            affected=knowledge.revise({'x':estimate},world.trace,invalidate=invalidate)
            return finish('READY',affected)
        except BudgetExceeded:return finish('BUDGET_EXHAUSTED')

def baseline(world,coefficients=(1,2)):
    if not isinstance(world,AgentIO):raise TypeError('Baseline requires AgentIO')
    if all(c==0 for c in coefficients):return {'status':'IRRELEVANT','plans':{'first':0,'second':0,'other':21},'trace':[]}
    candidates=sorted((c for c in world.interface() if c['reference']),key=lambda c:(c['read_cost'],c['id']))
    if not candidates:return {'status':'INSUFFICIENT_EVIDENCE','trace':[]}
    try:
        c=candidates[0]['id'];zero=world.query(c,'reference');value=world.query(c,'read')
    except BudgetExceeded:return {'status':'BUDGET_EXHAUSTED','trace':world.trace}
    x=value-zero
    return {'status':'READY','plans':{'first':coefficients[0]*x,'second':coefficients[1]*x,'other':21},'trace':world.trace,'coefficients':coefficients}

def evaluate(result,x):
    c=result.get('coefficients',(1,2))
    return {'executed':result['status']=='READY',
            'error':abs(result['plans']['first']-c[0]*x)+abs(result['plans']['second']-c[1]*x) if result['status']=='READY' else None,
            'cost':sum(e['cost'] for e in result['trace'])}

def experiments(folder):
    rows=[];a=Agent()
    configs=[('learn',dict(x=0)),('transfer',dict(x=5,bias=(-2,-2,0),names=('q','r','s'))),
             ('no_drift',dict(x=2,bias=(0,0,0))),('outside_class',dict(x=2,bias=(0,0,0),scale=2))]
    for label,config in configs:
        w=World(**config);r=a.run(w.api());a.save(Path(folder)/'method.json');a=Agent.load(Path(folder)/'method.json')
        b=baseline(World(**config).api())
        rows.append({'case':label,'T':r,'T_outcome':evaluate(r,w.x),'B2':b,'B2_outcome':evaluate(b,w.x)})
    for label,config,kwargs in [('irrelevant',{},dict(coefficients=(0,0))),('no_reference',dict(reference=False),{}),
            ('budget',dict(budget=2),{}),('no_method_change',{},dict(learn=False)),
            ('no_invalidation',{},dict(invalidate=False)),('restored',{},dict(invalidate=True))]:
        w=World(**config);r=Agent().run(w.api(),**kwargs)
        rows.append({'case':label,'T':r,'T_outcome':evaluate(r,w.x)})
    reset=Agent().run(World(x=5,bias=(-2,-2,0),names=('q','r','s')).api())
    rows.append({'case':'reset_method','T':reset,'T_outcome':evaluate(reset,5)})
    for label,bias in [('different_offsets',(1,-1,0)),('all_channels_biased',(1,1,1))]:
        w=World(x=2,bias=bias);r=Agent().run(w.api());b=baseline(World(x=2,bias=bias).api())
        rows.append({'case':label,'T':r,'T_outcome':evaluate(r,2),'B2':b,'B2_outcome':evaluate(b,2)})
    return rows
