import hashlib,json,sys,unittest,shutil
from datetime import datetime,timezone
from pathlib import Path
from recovery import experiments
ROOT=Path(__file__).resolve().parent
def main():
    out=ROOT/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
    (out/'source').mkdir()
    files=[p for p in ROOT.iterdir() if p.suffix in ('.py','.md')]
    for p in files:shutil.copy2(p,out/'source'/p.name)
    (out/'manifest.json').write_text(json.dumps({'python':sys.version,'command':sys.argv,
       'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}},indent=2),encoding='utf-8')
    with (out/'tests.txt').open('w',encoding='utf-8') as f:
        t=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py'))
    rows=experiments(out)
    (out/'episodes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    summary={'tests':t.testsRun,'failures':len(t.failures),'errors':len(t.errors),'run':str(out),
             'outcomes':[{k:r[k] for k in ('case','T_outcome','B2_outcome') if k in r} for r in rows]}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2))
    return int(not t.wasSuccessful())
if __name__=='__main__':raise SystemExit(main())
