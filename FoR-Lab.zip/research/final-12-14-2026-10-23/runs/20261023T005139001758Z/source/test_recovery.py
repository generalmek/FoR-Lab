import tempfile,unittest
from pathlib import Path
from recovery import *

class Tests(unittest.TestCase):
    def test_api_and_invalid_actions(self):
        w=World();api=w.api()
        self.assertFalse(hasattr(api,'x'));self.assertFalse(hasattr(api,'bias'))
        with self.assertRaises(TypeError):Agent().run(w)
        before=w.remaining
        with self.assertRaises(ValueError):api.query('a','typo')
        self.assertEqual(w.remaining,before)
    def test_internal_error_not_reported_as_budget(self):
        def broken(n,k):raise RuntimeError('actual implementation defect')
        api=AgentIO(World().interface(),broken,12)
        with self.assertRaises(RuntimeError):Agent().run(api)
    def test_evaluator_uses_actual_goal(self):
        r=Agent().run(World(x=5).api(),coefficients=(3,-2))
        self.assertEqual(evaluate(r,5)['error'],0)
    def test_saved_raw_method_can_be_repaired_again(self):
        a=Agent('raw');r=a.run(World(x=5,bias=(2,2,0)).api())
        self.assertEqual(a.method,'subtract_reference');self.assertEqual(evaluate(r,5)['error'],0)
        r=Agent('raw').run(World().api(),learn=False)
        self.assertEqual(r['status'],'METHOD_UNSUPPORTED')
    def test_initiative_depends_on_decision(self):
        a=Agent();zero=a.run(World().api(),coefficients=(0,0));important=a.run(World().api())
        self.assertEqual(zero['trace'],[])
        self.assertEqual(important['status'],'READY')
        self.assertEqual(important['plans']['first'],0)
    def test_method_is_changed_and_saved_not_answer(self):
        a=Agent();r=a.run(World().api())
        self.assertEqual(a.method,'subtract_reference');self.assertTrue(a.method_history)
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            p=Path(folder)/'memory.json';a.save(p);a=Agent.load(p)
        r=a.run(World(x=5,bias=(-2,-2,0),names=('q','r','s')).api())
        self.assertEqual(r['plans']['first'],5);self.assertEqual(len(r['trace']),2)
    def test_no_method_change_refuses_not_fake_resolved(self):
        r=Agent().run(World().api(),learn=False)
        self.assertEqual(r['status'],'METHOD_UNSUPPORTED')
    def test_localizes_read_dependencies_without_list(self):
        r=Agent().run(World().api())
        self.assertEqual(r['affected'],['first','second'])
        self.assertEqual(r['plans']['other'],21)
        self.assertEqual(r['history'][-1]['values']['x'],1)
    def test_actual_ablation_has_wrong_external_result(self):
        bad=Agent().run(World().api(),invalidate=False);good=Agent().run(World().api())
        self.assertEqual(evaluate(bad,0)['error'],3)
        self.assertEqual(evaluate(good,0)['error'],0)
    def test_budget_and_missing_reference(self):
        self.assertEqual(Agent().run(World(budget=2).api())['status'],'BUDGET_EXHAUSTED')
        self.assertEqual(Agent().run(World(reference=False).api())['status'],'INSUFFICIENT_EVIDENCE')
    def test_outside_additive_class_failure_is_preserved(self):
        w=World(x=2,bias=(0,0,0),scale=2);r=Agent().run(w.api())
        self.assertEqual(evaluate(r,2)['error'],6)
        self.assertEqual(evaluate(baseline(World(x=2,bias=(0,0,0),scale=2).api()),2)['error'],6)
    def test_enumerated_additive_worlds_baseline_not_inferior(self):
        for x in (-3,0,5):
            for bias in (-2,0,1):
                r=Agent().run(World(x=x,bias=(bias,bias,0)).api())
                b=baseline(World(x=x,bias=(bias,bias,0)).api())
                self.assertEqual(evaluate(r,x)['error'],0)
                self.assertEqual(evaluate(b,x)['error'],0)
                self.assertLessEqual(evaluate(b,x)['cost'],evaluate(r,x)['cost'])
    def test_read_only_method_transfer_no_new_knowledge_given(self):
        r=Agent('subtract_reference').run(World(x=5,bias=(-2,-2,0),names=('new3','new1','new2')).api())
        self.assertEqual(evaluate(r,5)['error'],0)
        self.assertEqual({e['kind'] for e in r['trace']},{'reference','read'})
    def test_no_privileged_unbiased_channel(self):
        for bias in ((1,-1,0),(1,1,1)):
            r=Agent().run(World(x=2,bias=bias).api())
            self.assertEqual(evaluate(r,2)['error'],0)

if __name__=='__main__':unittest.main()

