@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B research\final-12-14-2026-10-23\run.py
pause

