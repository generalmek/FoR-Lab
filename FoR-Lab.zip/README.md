# FoR-Lab

Research prototypes for Foundations of Reason by Mihail Tkalic. Publication snapshot: 23 October 2026.

## Status and limits

This is an open engineering laboratory, not evidence that artificial Reason, AGI, consciousness or autonomous value formation has been created. Finite symbolic environments test restricted inquiry, evidence provenance, model revision, dependent-decision updates and transfer of a saved measurement procedure. General semantic understanding and the full Core/Compass architecture are not implemented or validated.

No scientific advantage over a strong independent baseline is established. In the final pilots B2 is equal or cheaper. Successful unit tests are software checks, not independent confirmations of the theory. Earlier invalid procedures, failures and negative cases remain in the historical runs.

A calibration correction detects some distortions but an adversarial nonlinear mapping agrees on the calibration/check points and still fails elsewhere. The measurement-fix report preserves this counterexample. An earlier integration experiment also reached its goal despite a wrong model: it did not demonstrate that inquiry was necessary.

## Setup

Use Python 3.11 or newer. From the repository root on Windows:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -B -m unittest discover -s . -p "test_*.py" -v
```

The legacy GUI additionally needs Tkinter (included in normal Windows Python installations). NumPy supports the legacy numerical environment. The newer research pilots use the standard library.

## Run a pilot

Windows launchers `Start_FoR_*.bat` use the local `.venv` and pause at completion. For the latest measurement correction:

```powershell
.\.venv\Scripts\python.exe -B research/measurement-fix-2026-10-23/run.py
```

On Linux/macOS create the environment with `python3 -m venv .venv` and use `.venv/bin/python` instead. Run each research suite separately; root test discovery does not cover all research folders. Read each suite's protocol and launcher for its entry point.

## Contents

- Root: initial environment, inquiry and finite-hypothesis controllers, tests and launchers.
- `research/audit-0.3a-2026-10-23`: audit and invalid-procedure history.
- `research/integrated-2026-10-23`: integrated symbolic pilot.
- `research/eight-controls-2026-10-23`: control conditions.
- `research/cycles-9-11-2026-10-23`: subsequent engineering cycles.
- `research/final-12-14-2026-10-23`: saved-method transfer and dependent updates.
- `research/measurement-fix-2026-10-23`: calibration correction and remaining counterexample.
- `runs`, `logs`, `backup_originals`: historical source snapshots, traces, test outcomes and previous implementations. Old failures are intentional records, not a claim that all historical versions pass.

Read `PROTOCOL.md`, `RESULTS_RU.md`, `RESULTS_AND_AMENDMENT_RU.md` and research journals alongside the raw results. A new run writes a timestamped directory; keep historical runs for comparison.

## Publication preparation

The original lab was not changed. Virtual environments, caches, screenshots and raw browser/chat captures were excluded. Personal user-directory components and email addresses were redacted. `RELEASE_MANIFEST.json` records original and publication hashes and exclusions. Historical hashes may therefore differ from sanitized release files; they refer to original local artifacts. References to excluded chat captures remain historical references, not bundled evidence.

No experiments were rerun for publication. Python source was syntax-parsed; file inventory and common credential patterns were checked. This is not an independent scientific replication or an exhaustive security audit.
