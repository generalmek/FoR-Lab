@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B research\measurement-fix-2026-10-23\run.py
pause

