@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Existing Python environment not found in this directory.
 echo Place these files next to .venv and try again.
 pause
 exit /b 1
)
echo === FoR LAB RESEARCH PILOT - TESTS ===
".venv\Scripts\python.exe" -m unittest -v test_inquiry
if errorlevel 1 (
 echo TESTS FAILED. Logs are not a scientific result.
 pause
 exit /b 1
)
echo.
echo === RUN DIAGNOSTIC INQUIRY ===
".venv\Scripts\python.exe" inquiry_core.py
if errorlevel 1 echo ERROR: see output above.
echo.
echo Logs saved in logs folder. Current status: FUNCTIONAL PILOT ONLY.
pause
