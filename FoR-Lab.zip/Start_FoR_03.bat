@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Missing existing .venv next to launcher.
 pause
 exit /b 1
)
echo === FoR LAB 0.3 - TESTS ===
".venv\Scripts\python.exe" -m unittest -v test_inquiry test_agents_v03
if errorlevel 1 (
 echo TESTS FAILED - see details above.
 pause
 exit /b 1
)
echo.
echo === RUN MATCHED B2/T PILOT ===
".venv\Scripts\python.exe" for_agents_v03.py
if errorlevel 1 (
 echo RUN FAILED.
 pause
 exit /b 1
)
echo.
echo Complete. See logs\v03_summary.json and logs\research_runs.jsonl
pause
