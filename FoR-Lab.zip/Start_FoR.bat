@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Python virtual environment not found in .venv
  pause
  exit /b 1
)
if not exist "for_lab.py" (
  echo ERROR: for_lab.py not found in this folder
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "for_lab.py"
if errorlevel 1 pause
