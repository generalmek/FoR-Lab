@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B research\eight-controls-2026-10-23\run_integrated.py
pause

