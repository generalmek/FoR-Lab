"""FoR-Lab preliminary environment. No intelligent controllers or FoR results here."""
from dataclasses import dataclass
import random

@dataclass(frozen=True)
class Observation:
    symptom: str
    battery_voltage: float | None = None
    signal_level: float | None = None

class SensorWorld:
    """Tiny hidden-cause world; observations never contain the cause."""
    def __init__(self, seed: int):
        self.rng = random.Random(seed)
        self._cause = self.rng.choice(('power', 'signal'))
        self.steps = 0
        self.total_cost = 0
        self.done = False

    def reset(self) -> Observation:
        return Observation(symptom='device_offline')

    def step(self, action: str):
        if self.done:
            raise RuntimeError('Episode already completed')
        if action not in ('measure_voltage','measure_signal','repair_power','repair_signal'):
            raise ValueError('Invalid action')
        self.steps += 1
        if action == 'measure_voltage':
            self.total_cost += 1
            return Observation('device_offline', battery_voltage=2.0 if self._cause=='power' else 5.0), -1, False, {}
        if action == 'measure_signal':
            self.total_cost += 1
            return Observation('device_offline', signal_level=0.0 if self._cause=='signal' else 1.0), -1, False, {}
        success = ((action=='repair_power' and self._cause=='power') or
                   (action=='repair_signal' and self._cause=='signal'))
        self.total_cost += 2 if success else 12
        self.done = True
        return Observation('device_online' if success else 'device_offline'), -(2 if success else 12), True, {}

def smoke_test():
    completed = 0
    for seed in range(256):
        env = SensorWorld(seed)
        first = env.reset()
        assert first.symptom == 'device_offline'
        assert 'cause' not in first.__dict__
        obs, _, done, info = env.step('measure_voltage')
        assert not done and not info
        assert obs.battery_voltage in (2.0, 5.0)
        action = 'repair_power' if obs.battery_voltage == 2.0 else 'repair_signal'
        result, _, done, info = env.step(action)
        assert done and not info and result.symptom == 'device_online'
        completed += 1
    return completed
