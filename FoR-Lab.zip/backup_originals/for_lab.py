import tkinter as tk
from tkinter import ttk
import sys
from for_env import smoke_test

app = tk.Tk()
app.title('FoR LAB 0.1 — Первый рубеж')
app.geometry('800x525')
app.minsize(700, 470)
frame = ttk.Frame(app, padding=18)
frame.pack(fill='both', expand=True)
ttk.Label(frame, text='FoR LAB 0.1 — Старт экспериментальной архитектуры Разума',
          font=('Segoe UI', 15, 'bold'), wraplength=760).pack(anchor='w')
ttk.Label(frame, text='Первый инженерный рубеж: подготовка вычислительного контура и испытательного мира.',
          wraplength=760).pack(anchor='w', pady=(7, 10))
log = tk.Text(frame, height=18, wrap='word', font=('Consolas', 10))
log.pack(fill='both', expand=True)

def write(line):
    log.insert('end', line + '\n')
    log.see('end')

def check_core():
    write('=== ТЕСТ ПРОГРАММНОГО ЯДРА ===')
    write('Python: ' + sys.version.split()[0])
    ready = True
    for name in ('numpy', 'scipy', 'networkx', 'pytest', 'matplotlib'):
        try:
            module = __import__(name)
            write(f'{name}: OK ({getattr(module, "__version__", "версия не указана")})')
        except Exception as exc:
            ready = False
            write(f'{name}: ОШИБКА ({exc})')
    if ready:
        write('ЯДРО ЛАБОРАТОРИИ: ИНИЦИАЛИЗАЦИЯ УСПЕШНА')
    else:
        write('ЯДРО ЛАБОРАТОРИИ: ПРОВЕРКА НЕ ПРОЙДЕНА')
    write('')

def check_environment():
    write('=== ТЕСТ ИСПЫТАТЕЛЬНОЙ СРЕДЫ ===')
    try:
        count = smoke_test()
        if count == 256:
            write(f'СРЕДА: {count}/256 КОНТРОЛЬНЫХ СЦЕНАРИЕВ ПРОЙДЕНО')
            write('СТАТУС: ПЕРВЫЙ ТЕХНИЧЕСКИЙ РУБЕЖ ДОСТИГНУТ')
        else:
            write(f'СРЕДА: {count}/256 — ПРОВЕРКА НЕ ПОДТВЕРЖДЕНА')
    except Exception as exc:
        write('СРЕДА: ОШИБКА — ' + repr(exc))
    write('ГРАНИЦА РЕЗУЛЬТАТА: проверены инструменты и демонстрационная среда;')
    write('Ядро Разума FoR и агенты B2/T пока не созданы и не испытаны.')
    write('')

buttons = ttk.Frame(frame)
buttons.pack(fill='x', pady=(10, 0))
ttk.Button(buttons, text='Тест Ядра', command=check_core).pack(side='left', padx=(0, 10))
ttk.Button(buttons, text='Тест Среды', command=check_environment).pack(side='left')
write('ЛАБОРАТОРИЯ ИНИЦИАЛИЗИРОВАНА')
write('Начните с теста программного ядра, затем проверьте испытательную среду.')
write('')
app.mainloop()
