"""Restricted, explicitly incomplete inquiry cycle over finite hypotheses.
No LLM, no hidden oracle. Hypothesis probabilities are uniform in this pilot.
"""
from dataclasses import dataclass, asdict
import json
from pathlib import Path
from for_env_v02 import DiagnosticWorld, ACTIONS

@dataclass(frozen=True)
class Hypothesis:
    fault: str
    shared: bool

HYPOTHESES = tuple(Hypothesis(f,s) for f in ('sensor','process') for s in (False,True))

def predict(h, action):
    if action == 'inspect_primary': return 'abnormal'
    if action == 'inspect_reference': return 'abnormal' if h.fault == 'process' or h.shared else 'normal'
    if action == 'audit_provenance': return 'shared' if h.shared else 'independent'
    raise ValueError('Not a diagnostic action')

def filter_models(models, action, outcome):
    return tuple(h for h in models if predict(h,action) == outcome)

def possible_repair_actions(models):
    return {'repair_' + h.fault for h in models}

def one_step_distinction(models, available, budget):
    """Find an affordable test that partitions models by dependent repair choice.
    Deterministic selection: maximize number of pairs separated, tie break lower cost.
    This is NOT full expected-value planning.
    """
    from for_env_v02 import COST
    options = []
    for action in available:
        if COST[action] > budget: continue
        separated = 0
        for i, a in enumerate(models):
            for b in models[i+1:]:
                if a.fault != b.fault and predict(a,action) != predict(b,action):
                    separated += 1
        if separated: options.append((-separated, COST[action], action))
    return min(options)[2] if options else None

def run_inquiry(seed=0, scenario='independent', budget=7, log_path=None):
    env = DiagnosticWorld(seed, budget, scenario)
    obs = env.reset()
    models = HYPOTHESES
    trace = [{'event':'reset','observation':asdict(obs),'remaining_models':len(models)}]
    observed = []
    for _ in range(5):
        repairs = possible_repair_actions(models)
        if len(repairs) == 1:
            action = next(iter(repairs))
            obs, reward, done, info = env.step(action)
            trace.append({'event':'decision','action':action,'observation':asdict(obs),'reward':reward,'status':'RESOLVED' if obs.symptom=='restored' else 'FAILED', 'epistemic_sufficiency':len(repairs)==1})
            break
        used = {a for a,_ in observed}
        action = one_step_distinction(models, [a for a in ('inspect_reference','audit_provenance','inspect_primary') if a not in used], env.budget)
        if action is None:
            # An unaffordable potentially discriminating test is a resource stop,
            # NOT proof of observational unidentifiability.
            all_unused = [a for a in ('inspect_reference','audit_provenance','inspect_primary') if a not in used]
            counterfactual = one_step_distinction(models, all_unused, 10**9)
            if counterfactual is not None:
                status = 'BUDGET_EXHAUSTED'
                reason = 'Potentially discriminating test exists but is unaffordable.'
            else:
                # This bounded greedy search has not proved no multi-step sequence exists.
                status = 'NO_POSITIVE_VALUE'
                reason = 'No one-step decision-separating test found by current search; multi-step identifiability unproven.'
            trace.append({'event':'stop','status':status,
                          'epistemic_sufficiency':False,'gap_open':True,
                          'stop_reason':reason,'remaining_models':len(models),'budget':env.budget,
                          'proof_of_unidentifiability':False})
            break
        obs, reward, done, info = env.step(action)
        value = getattr(obs, {'inspect_reference':'reference','audit_provenance':'provenance','inspect_primary':'primary'}[action])
        before = len(models)
        models = filter_models(models, action, value)
        observed.append((action,value))
        trace.append({'event':'test','action':action,'value':value,'cost':-reward,'models_before':before,'models_after':len(models),'models':[asdict(m) for m in models], 'budget':env.budget})
        if not models:
            trace.append({'event':'stop','status':'MODEL_CLASS_INADEQUATE','epistemic_sufficiency':False,'gap_open':True})
            break
    else:
        trace.append({'event':'stop','status':'STEP_LIMIT','epistemic_sufficiency':False,'gap_open':True})
    result = {'seed':seed,'scenario':scenario,'initial_budget':budget,'trace':trace,'technical_scope':'restricted finite hypothesis diagnostic cycle, not B2/T or Reason'}
    if log_path:
        Path(log_path).parent.mkdir(parents=True,exist_ok=True)
        Path(log_path).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result

if __name__ == '__main__':
    for scenario in ('independent','shared'):
        r=run_inquiry(seed=1,scenario=scenario,log_path=f'logs/pilot_{scenario}.json')
        print(scenario, '=>', r['trace'][-1].get('status'), 'events', len(r['trace']))
