@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B research\cycles-9-11-2026-10-23\run.py
pause

